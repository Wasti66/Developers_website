				 <div class="card shadow-sm border-0 rounded-0">
				    <div class="card border-0 rounded-0 overflow-hidden">
					  <img src="<?php echo $baseurl; ?>images/v_c.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
					  <div class="card-img-overlay d-flex align-items-end justify-content-between">
						 <div class="d-flex bg-goldren-300 text-light align-items-center px-1 position-relative">
						   <p class="mb-0"><small>$16.000 / month</small></p>
						 </div>
					  </div>
				    </div>
					<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
					    <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle shadow-sm">
					</div>
					<div class="card-body pt-0">
					   <h6 class="text-uppercase fw-bolder mb-0 mt-2">
						 <a href="#" class="nav-link text-goldren-300-hover transition-400">Spacious Office Space</a>
					   </h6>
					   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-secondary">
						 <small>Coconut Grove,</small>
					   </a>
					   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">
						 <small>Miami</small>
					   </a>
					   <ul class="list-group list-group-horizontal justify-content-md-center mt-3">
						  <li class="list-group-item border-0 ps-0">
							<p class="mb-0 fs-6 text-body-tertiary fw-semibold">2 <small>bedrooms</small></p>
						  </li>
						  <li class="list-group-item border-0 fw-semibold">
							<p class="mb-0 fs-6 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></p>
						  </li>
					   </ul>
					</div>
				 </div>