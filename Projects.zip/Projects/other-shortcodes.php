<?php include('header.php'); ?>
	<main>
		<!-- === Testimonial Type 1 === -->
	    <section class="bg-sky-50 pt-3">
		  <div class="container-lg">
		    <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-5">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Other Shortcodes</small></a>
				</li>
			   </ol>
			</nav>
		    <div class="row justiy-content-center mt-5 g-4">
			    <h1 class="text-capitalize fw-bolder opacity-75 text-center mb-4">Testimonial Type 1</h1>
				<div class="col-12">
				  <div class="card card-body shadow-sm border-0 mb-3">
				    <p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s.</small></p>
				  </div>
				  <div class="d-flex align-items-center">
					<div class="flex-shrink-0">
					   <img src="<?php echo $baseurl; ?>images/agent1.png" class="rounded-circle" style="height:60px;">
					</div>
					<div class="flex-grow-1 ms-3">
					   <a href="<?php echo $baseurl; ?>#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
					   <p class="text-body-tertiary mb-0">Happy buyer</p>
					</div>
				  </div>
				</div>
			</div>
		  </div>
		</section>
		<!-- === Testimonial Slider Type 1 === -->
		<section>
		  <div class="container-lg">
		    <div class="row justiy-content-center mb-5">
			    <h1 class="text-capitalize fw-bolder text-center">Testimonial Slider Type 1</h1>
			</div>
		  </div>
		  <div id="testimonials" class="carousel slide" data-bs-ride="carousel">
			<button class="carousel-control-prev opacity-100" type="button" data-bs-target="#testimonials" data-bs-slide="prev">
				<i class="fa-solid fa-chevron-left text-body-tertiary h-3 w-3 border d-flex align-items-center justify-content-center rounded-circle"></i>
			</button>
			<button class="carousel-control-next opacity-100" type="button" data-bs-target="#testimonials" data-bs-slide="next">
				<i class="fa-solid fa-chevron-right text-body-tertiary h-3 w-3 border d-flex align-items-center justify-content-center rounded-circle"></i>
			</button>
			<!-- === Testimonials carousel-inner === -->
			<div class="carousel-inner">
			  <!-- === Testimonials information-1 === -->
			  <div class="carousel-item active">
				<div class="container">
				  <div class="row justify-content-center">
				    <div class="col-md-10 col-sm-12 col-11">
					  <div class="card mb-md-5 mb-4 border-0">
						<p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</small></p>
					  </div>
					  <div class="d-flex align-items-center">
						<div class="flex-shrink-0">
						   <img src="<?php echo $baseurl; ?>images/agent1.png" class="rounded-circle" style="height:60px;">
						</div>
						<div class="flex-grow-1 ms-3">
						   <a href="<?php echo $baseurl; ?>#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
						   <p class="text-body-tertiary mb-0">Happy buyer</p>
						</div>
					  </div>
					</div>
				  </div>
				</div>	
			  </div>
			  <!-- === Testimonials information-2 === -->
			  <div class="carousel-item">
				<div class="container">
				  <div class="row justify-content-center">
				    <div class="col-md-10 col-sm-12 col-11">
					  <div class="card mb-md-5 mb-4 border-0">
						<p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</small></p>
					  </div>
					  <div class="d-flex align-items-center">
						<div class="flex-shrink-0">
						   <img src="<?php echo $baseurl; ?>images/agent1.png" class="rounded-circle" style="height:60px;">
						</div>
						<div class="flex-grow-1 ms-3">
						   <a href="<?php echo $baseurl; ?>#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
						   <p class="text-body-tertiary mb-0">Happy buyer</p>
						</div>
					  </div>
					</div>
				  </div>
				</div>  
			  </div>
			</div>
			<!-- === Testimonials indicators === -->
			<div class="carousel-indicators position-static mt-5 mb-0 testimonials-carousel">
				<button type="button" data-bs-target="#testimonials" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1" class="text-light"></button>
				<button type="button" data-bs-target="#testimonials" data-bs-slide-to="1" aria-label="Slide 2" class="text-light"></button>
			</div>
		  </div>
		</section>
		<!-- === Testimonial Type 2 === -->
	    <section class="bg-sky-50">
		  <div class="container-lg">
		    <div class="row justify-content-center text-center g-4">
			    <h1 class="text-capitalize fw-bolder opacity-75 mb-4">Testimonial Type 2</h1>
				<div class="col-lg-10 col-md-11">
				  <a href="<?php echo $baseurl; ?>#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
				  <p class="text-body-tertiary">Happy buyer</p>
				  <img src="<?php echo $baseurl; ?>images/agent1.png" class="rounded-circle mb-3" style="height:60px;">
				  <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s.</small></p>
				</div>
			</div>
		  </div>
		</section>
		<!-- === Testimonial Slider Type 2 === -->
		<section>
		  <div class="container-lg">
		    <div class="row justiy-content-center mb-5">
			    <h1 class="text-capitalize fw-bolder text-center">Testimonial Slider Type 2</h1>
			</div>
		  </div>
		  <div id="testimonials2" class="carousel slide" data-bs-ride="carousel">
			<button class="carousel-control-prev opacity-100" type="button" data-bs-target="#testimonials2" data-bs-slide="prev">
				<i class="fa-solid fa-chevron-left text-body-tertiary h-3 w-3 border d-flex align-items-center justify-content-center rounded-circle"></i>
			</button>
			<button class="carousel-control-next opacity-100" type="button" data-bs-target="#testimonials2" data-bs-slide="next">
				<i class="fa-solid fa-chevron-right text-body-tertiary h-3 w-3 border d-flex align-items-center justify-content-center rounded-circle"></i>
			</button>
			<!-- === Testimonials carousel-inner === -->
			<div class="carousel-inner">
			  <!-- === Testimonials information-1 === -->
			  <div class="carousel-item active">
				<div class="container">
				  <div class="row justify-content-center text-center g-4">
					<div class="col-lg-10 col-md-11">
					  <a href="<?php echo $baseurl; ?>#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
					  <p class="text-body-tertiary">Happy buyer</p>
					  <img src="<?php echo $baseurl; ?>images/agent1.png" class="rounded-circle mb-3" style="height:60px;">
					  <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s.</small></p>
					</div>
				 </div>
				</div>	
			  </div>
			  <!-- === Testimonials information-2 === -->
			  <div class="carousel-item">
				<div class="container">
				  <div class="row justify-content-center text-center g-4">
					<div class="col-lg-10 col-md-11">
					  <a href="<?php echo $baseurl; ?>#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
					  <p class="text-body-tertiary">Happy buyer</p>
					  <img src="<?php echo $baseurl; ?>images/agent1.png" class="rounded-circle mb-3" style="height:60px;">
					  <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s.</small></p>
					</div>
				 </div>
				</div>  
			  </div>
			</div>
		  </div>
		</section>
		<!-- === Testimonial Type 3 === -->
	    <section class="bg-sky-50">
		  <div class="container-lg">
		    <div class="row justify-content-center g-4">
			    <h1 class="text-capitalize fw-bolder opacity-75 mb-4 text-center">Testimonial Type 3</h1>
				<div class="col-12">
					<div class="card border-0 rounded-0 mt-5">
					  <div class="row g-0 align-items-center">
						<div class="col-md-4 col-5">
						  <div class="background-size-cover background-repeat-no-repeat background-position-center position-relative custom-shadow" style="background-image:url(images/home.jpg);
						  height:300px; top:-30px;left:-30px;"></div>
						</div>
						<div class="col-md-8 col-7">
						  <span class="opacity-50"><i class="fa-solid fa-quote-left fa-3x"></i></span>
						  <p class="text-muted fw-semibold opacity-75 mt-3"><small>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</small></p>
						  <h6 class="fs-6 text-uppercase fw-bold mb-0">john moxley</h6>
						  <p class="text-muted fw-semibold opacity-75"><small>real estate developer</small></p>
						</div>
					  </div>
					</div>
				</div>
			</div>
		  </div>
		</section>
		<!-- === Testimonial Slider Type 3 === -->
		<section>
		   <div class="container-lg">
		      <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-10">
			      <h1 class="text-capitalize fw-bolder opacity-75 mb-4 text-center">Testimonial Type 3</h1>
			   </div>
			  </div>
			 <!-- === Testimonials carousel start === -->
			 <div id="testimonials3" class="carousel slide">
				  <button class="carousel-control-prev bottom-100 left-auto justify-content-end py-3 mt-5" type="button" data-bs-target="#testimonials3" data-bs-slide="prev" style="right: 25px;">
					<i class="fa-solid fa-chevron-left text-dark fs-5 opacity-50"></i>
				  </button>
				  <button class="carousel-control-next bottom-100 justify-content-end py-3 mt-5 me-2" type="button" data-bs-target="#testimonials3" data-bs-slide="next">
					<i class="fa-solid fa-chevron-right text-dark fs-5 opacity-50"></i>
				  </button>
				  <!-- === Testimonials carousel-inner === -->
				  <div class="carousel-inner mt-5">
				    <!-- === Testimonials information-1 === -->
					<div class="carousel-item active">
					  <div class="col-12">
						<div class="card border-0 rounded-0 bg-light mt-5">
						  <div class="row g-0 align-items-center">
							<div class="col-md-4 col-5">
							  <div class="background-size-cover background-repeat-no-repeat background-position-center position-relative custom-shadow" style="background-image:url(images/home.jpg);
							  height:300px; top:-30px;left:-30px;"></div>
							</div>
							<div class="col-md-8 col-7">
							  <span class="opacity-50"><i class="fa-solid fa-quote-left fa-3x"></i></span>
							  <p class="text-muted fw-semibold opacity-75 mt-3"><small>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</small></p>
							  <h6 class="fs-6 text-uppercase fw-bold mb-0">john moxley</h6>
							  <p class="text-muted fw-semibold opacity-75"><small>real estate developer</small></p>
							</div>
						  </div>
						</div>
					  </div>
					</div>
					<!-- === Testimonials information-2 === -->
					<div class="carousel-item">
					  <div class="col-12">
						<div class="card border-0 rounded-0 bg-light mt-5">
						  <div class="row g-0 align-items-center">
							<div class="col-md-4 col-5">
							  <div class="background-size-cover background-repeat-no-repeat background-position-center position-relative custom-shadow" style="background-image:url(images/card_4.jpg);
							  height:300px; top:-30px;left:-30px;"></div>
							</div>
							<div class="col-md-8 col-7">
							  <span class="opacity-50"><i class="fa-solid fa-quote-left fa-3x"></i></span>
							  <p class="text-muted fw-semibold opacity-75 mt-3"><small>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</small></p>
							  <h6 class="fs-6 text-uppercase fw-bold mb-0">john moxley</h6>
							  <p class="text-muted fw-semibold opacity-75"><small>real estate developer</small></p>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
			 </div>
		   </div>
		</section>
		<!-- === login,registration form === -->
	    <section class="bg-sky-50">
		   <div class="container-lg">
		     <div class="row justify-content-center g-4">
			   <!-- === login === -->
			   <div class="col-md-4 col-sm-6">
			     <h1 class="text-capitalize fw-bolder mb-4 text-center">login</h1>
			     <form action="" method="post">
				    <div class="mb-3">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="text" placeholder="User Name">
					</div>
					<div class="mb-3">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="password" name="password" placeholder="Password">
					</div>
					<input type="submit" class="form-control rounded-0 fw-bold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 py-2 mb-2" value="Login">
					<small>
					  <a href="#" class="text-decoration-none fw-semibold text-body-tertiary text-goldren-300-hover">Register Now | </a>
					  <a href="#" class="text-decoration-none fw-semibold text-body-tertiary text-goldren-300-hover">Forgot Password?</a>
					</small>
				 </form>
			   </div>
			   <!-- === register === -->
			   <div class="col-md-4 col-sm-6">
			     <h1 class="text-capitalize fw-bolder mb-4 text-center">register</h1>
			     <form action="" method="post">
				    <div class="mb-3">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="text" placeholder="User Name">
					</div>
					<div class="mb-3">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="email" name="" placeholder="Email">
					</div>
					<div class="mb-3">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="password" name="password" placeholder="Password">
					</div>
					<div class="mb-3">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="repassword" name="password" placeholder="Re Type Password">
					</div>
					<small>
					  <input class="form-check-input shadow-none rounded-0 me-1" type="checkbox" value=""style="margin-top:6px;">
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fw-semibold text-body-tertiary text-goldren-300-hover">I agree with  terms & conditions</a>
					</small>
					<input type="submit" class="form-control rounded-0 fw-bold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 py-2 mt-3" value="Register">
				 </form>
			   </div>
			   <!-- === === -->
			   <div class="col-md-4 col-sm-6">
				 <p class="text-body-tertiary fw-semibold mt-md-5"><small>In publishing and graphic design, Lorem ipsum is a placeholder text commonly.</small></p>
				 <p class="text-body-tertiary fw-semibold"><small><span class="fw-bold">1. FREE</span> In publishing and graphic design, Lorem ipsum is a placeholder text commonly.</small></p>
				 <p class="text-body-tertiary fw-semibold"><small><span class="fw-bold">2. PAID</span> In publishing and graphic design, Lorem ipsum is a placeholder text commonly.In publishing and graphic design, Lorem ipsum is a placeholder text commonly.</small></p>
				 <p class="text-body-tertiary fw-semibold"><small><span class="fw-bold">3. MEMBERSHIP</span> In publishing and graphic design, Lorem ipsum is a placeholder text commonly.In publishing and graphic design, Lorem ipsum is a placeholder text commonly.Lorem ipsum is a placeholder text commonly.Lorem ipsum is a placeholder text commonly.</small></p>				
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === === -->
		<section> 
		   <div class="container-lg">
		     <div class="row justify-content-center text-center">
			   <h1 class="text-capitalize fw-bolder opacity-75 mb-5 text-center">Testimonial Type 3</h1> 
			   <div class="col-lg-10 col-md-11">
			      <form class="row bg-light justify-content-center g-3" action="" method="post">
					 <div class="col-lg-3 col-md-4">
					   <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							   <option value="">All action</option>
							   <option value="1">One</option>
							   <option value="2">Two</option>
							   <option value="3">Three</option>
							</select>
					 </div>
					 <div class="col-lg-3 col-md-4">
						<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							<option value="">All action</option>
							<option value="1">One</option>
							<option value="2">Two</option>
							<option value="3">Three</option>
						</select>
					 </div>
					 <div class="col-lg-3 col-md-4">
						<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							<option value="">All action</option>
							<option value="1">One</option>
							<option value="2">Two</option>
							<option value="3">Three</option>
						</select>
					 </div>
					 <div class="col-lg-3 col-md-4">
						<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							<option value="">All action</option>
							<option value="1">One</option>
							<option value="2">Two</option>
							<option value="3">Three</option>
						</select>
					 </div>
					 <div class="col-lg-3 col-md-4">
						<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
					 </div>
					 <div class="col-lg-3 col-md-4">
						<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
					 </div>
					 <div class="col-lg-3 col-md-4">
						<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					 </div>
					 <div class="col-lg-3 col-md-4 mb-2">
						<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Max. Price">
					 </div>
				  </form>
			   </div>
			 </div>
		   </div>
		</section> 
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>