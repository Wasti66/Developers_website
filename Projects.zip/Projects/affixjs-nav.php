	<script>
		window.onscroll = function(){
			var scroll = window.scrollY;
			if(scroll > 200){
				document.querySelector('#affix-nav').classList.add('sticky-top','shadow-sm','bg-white');
			}else{
				document.querySelector('#affix-nav').classList.remove('sticky-top','shadow-sm','bg-white');
			}
		}
	</script>