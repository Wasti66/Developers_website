<?php include('header.php'); ?>
	<main>
	    <style>
		  .form-control-focus:focus{
			 border-color: #B186D7;
			-webkit-box-shadow: inset 0 1px 1px rgb(0 0 0 / 8%), 0 0 8px #B186D7!important;
		  }
		  .bg-parple-500{
			  background-color:#B186D7;
		  }
		  .text-parple-500{
			  color:#B186D7;
		  }
		</style>
		<!-- === berlin banar === -->
		<section class="background-size-cover background-repeat-no-repeat background-position-center d-flex align-items-end" style="background-image:url(images/berlin-header21.jpg); height:350px;">
		  <div class="container-lg">
		    <div class="row justify-content-center">
			  <div class="col-lg-11">
			    <div class="card border-0 rounded-0 py-3 px-3" style="background-color:#44444496;">
				  <div class="row g-3">
				    <div class="col-md-8">
					  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type address, state, city or area">
					</div>
					<div class="col-md-2">
					  <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/parple.svg)">
						 <option value="">All action</option>
						 <option value="1">One</option>
						 <option value="2">Two</option>
						 <option value="3">Three</option>
					  </select>
					</div>
					<div class="col-md-2 d-flex">
						<a class="btn bg-parple-500 text-white rounded-0 me-2 bg-hover-dark-600 border-0" data-bs-toggle="collapse" href="#form" role="button" aria-expanded="false" aria-controls="collapseExample">
							<i class="fa-solid fa-list"></i>
						</a>
						<button type="submit" class="form-control text-uppercase bg-parple-500 fw-semibold text-white rounded-0 shadow-none bg-hover-dark-600 border-0">search</button>
					</div>
				  </div>
				</div>
				<!-- === === -->
				<div class="collapse" id="form">
				   <form class="row mb-4 g-3 align-items-center"> 
					  <!-- === 1 === -->
					  <div class="col-md-4 col-sm-6">
						  <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/parple.svg)">
							 <option value="">All action</option>
							 <option value="1">One</option>
							 <option value="2">Two</option>
							 <option value="3">Three</option>
						  </select>
					  </div>
					  <!-- === 2 === -->
					  <div class="col-md-4 col-sm-6">
						<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/parple.svg)">
							 <option value="">All action</option>
							 <option value="1">One</option>
							 <option value="2">Two</option>
							 <option value="3">Three</option>
						  </select>
					  </div>
					  <!-- === 3 === -->
					  <div class="col-md-4 col-sm-6">
						 <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/parple.svg)">
							 <option value="">All action</option>
							 <option value="1">One</option>
							 <option value="2">Two</option>
							 <option value="3">Three</option>
						  </select>
					  </div>
					  <!-- === 4 === -->
					  <div class="col-md-4 col-sm-6">
						 <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/parple.svg)">
							 <option value="">All action</option>
							 <option value="1">One</option>
							 <option value="2">Two</option>
							 <option value="3">Three</option>
						  </select>
					  </div>
					  <!-- === 4 === -->
					  <div class="col-md-4 col-sm-6">
						 <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/parple.svg)">
							 <option value="">All action</option>
							 <option value="1">One</option>
							 <option value="2">Two</option>
							 <option value="3">Three</option>
						  </select>
					  </div>
					  <!-- === 4 === -->
					  <div class="col-md-4 col-sm-6">
						 <input type="range" class="form-range" id="customRange1">
					  </div>
				   </form>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		<!-- === Why use WP Estate? === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center mb-5">
			   <div class="col-lg-8 text-center">
				  <h1 class="text-capitalize">Why use WP Estate?</h1>
				  <span>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-heart text-muted fa-xl text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				  </span>
			   </div>
			 </div>
			 <div class="row gy-3">
			   <div class="col-md-4">
			     <div class="d-flex">
				  <div class="flex-shrink-0">
					<img src="images/sp.png" class="rounded-circle">
				  </div>
				  <div class="flex-grow-1 ms-3">
					<h3 class="mb-3" style="font-weight:300;">For Sellers</h3>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without.</p>
				  </div>
				 </div>
			   </div>
			   <div class="col-md-4">
			     <div class="d-flex">
				  <div class="flex-shrink-0">
					<img src="images/sp.png" class="rounded-circle">
				  </div>
				  <div class="flex-grow-1 ms-3">
					<h3 class="mb-3" style="font-weight:300;">For Sellers</h3>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without.</p>
				  </div>
				 </div>
			   </div>
			   <div class="col-md-4">
			     <div class="d-flex">
				  <div class="flex-shrink-0">
					<img src="images/sp.png" class="rounded-circle">
				  </div>
				  <div class="flex-grow-1 ms-3">
					<h3 class="mb-3" style="font-weight:300;">For Sellers</h3>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without.</p>
				  </div>
				 </div>
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === Best team in Berlin === -->
		<section class="bg-light pb-0">
		   <div class="container-lg">
		     <div class="row justify-content-center mb-5">
			   <div class="col-lg-8 text-center">
				  <h1 class="text-capitalize">Best team in Berlin</h1>
				  <span>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-star text-muted fa-xl text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				  </span>
			   </div>
			 </div>
			 <div class="row gy-3 justify-content-center">
			   <div class="col-md-4 mb-4">
			     <div class="d-flex mb-4">
				  <div class="flex-grow-1 ms-3">
					<h6 class="mb-3">For Sellers</h6>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.</p>
				  </div>
				  <div class="flex-shrink-0">
					<img src="images/agent1.png" class="rounded-circle" style="height:70px; width:70px;">
				  </div>
				 </div>
				 <div class="d-flex mb-4">
				  <div class="flex-grow-1 ms-3">
					<h6 class="mb-3">For Sellers</h6>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.</p>
				  </div>
				  <div class="flex-shrink-0">
					<img src="images/agent1.png" class="rounded-circle" style="height:70px; width:70px;">
				  </div>
				 </div>
				 <div class="d-flex mb-4">
				  <div class="flex-grow-1 ms-3">
					<h6 class="mb-3">For Sellers</h6>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.</p>
				  </div>
				  <div class="flex-shrink-0">
					<img src="images/agent1.png" class="rounded-circle" style="height:70px; width:70px;">
				  </div>
				 </div>
			   </div>
			   <div class="col-md-4 mt-5">
			     <img src="images/single_man.png" class="images-fluid">
			   </div>
			   <div class="col-md-4 mb-4">
			     <div class="d-flex mb-4">
				  <div class="flex-grow-1 ms-3">
					<h6 class="mb-3">For Sellers</h6>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.</p>
				  </div>
				  <div class="flex-shrink-0">
					<img src="images/agent1.png" class="rounded-circle" style="height:70px; width:70px;">
				  </div>
				 </div>
				 <div class="d-flex mb-4">
				  <div class="flex-grow-1 ms-3">
					<h6 class="mb-3">For Sellers</h6>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.</p>
				  </div>
				  <div class="flex-shrink-0">
					<img src="images/agent1.png" class="rounded-circle" style="height:70px; width:70px;">
				  </div>
				 </div>
				 <div class="d-flex mb-4">
				  <div class="flex-grow-1 ms-3">
					<h6 class="mb-3">For Sellers</h6>
					<p class="mb-0 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.</p>
				  </div>
				  <div class="flex-shrink-0">
					<img src="images/agent1.png" class="rounded-circle" style="height:70px; width:70px;">
				  </div>
				 </div>
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === Best team in Berlin === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center mb-5">
			   <div class="col-lg-8 text-center">
				  <h1 class="text-capitalize">Our Newest Offers</h1>
				  <span>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-home text-muted fa-xl text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				  </span>
			   </div>
			 </div>
			 <div class="row justify-content-center g-4">
			    <!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
			 </div>
		   </div>
		</section>
		<!-- === Best team in Berlin === -->
		<section class="bg-light">
		   <div class="container-lg">
		     <div class="row justify-content-center mb-5">
			   <div class="col-lg-8 text-center">
				  <h1 class="text-capitalize">Top Locations in Berlin</h1>
				  <span>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-building-columns text-muted fa-xl text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				  </span>
			   </div>
			 </div>
			 <div class="row mb-3 g-3">
				  <div class="col-lg-8 col-sm-7 mb-md-0 mb-3">
				    <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/1.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-parple-500 text-white rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-lg-4 col-sm-5">
				    <a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/2.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-parple-500 text-white rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
			   </div>
			   <div class="row g-3">
				  <div class="col-md-4 mb-md-0 mb-3">
				    <a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/3.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-parple-500 text-white rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
					<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/4.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-parple-500 text-white rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
					<a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/5.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-parple-500 text-white rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
			   </div>
		   </div>
		</section>
		<!-- === Featured Property Type 4 === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center mb-5">
			   <div class="col-lg-8 text-center">
				  <h1 class="text-capitalize">Listing of the day</h1>
				  <span>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-building-columns text-muted fa-xl text-black-50 opacity-75"></i>
				    <i class="fa-solid fa-window-minimize text-black-50 opacity-75"></i>
				  </span>
			   </div>
			 </div>
			 <!-- === Testimonials carousel start === -->
			 <div id="testimonials" class="carousel slide">
				<button class="carousel-control-prev bottom-100 left-auto justify-content-end py-3" type="button" data-bs-target="#testimonials" data-bs-slide="prev" style="right: 25px;">
					<i class="fa-solid fa-chevron-left text-dark fs-5"></i>
				</button>
				<div></div>
				<button class="carousel-control-next bottom-100 justify-content-end py-3 me-2" type="button" data-bs-target="#testimonials" data-bs-slide="next">
					<i class="fa-solid fa-chevron-right text-dark fs-5"></i>
				</button>
				<!-- === Testimonials carousel-inner === -->
				<div class="carousel-inner">
				  <!-- === Testimonials information-1 === -->
				  <div class="carousel-item active">
				    <div class="row align-items-center justify-content-between">
					   <div class="col-lg-5 mb-lg-0 mb-5">
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_1" style="background-image:url(images/card_6.jpg);"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_2" style="background-image:url(images/sider-img3.jpg); left: 225px;"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat position-relative shadow" style="background-image:url(images/card_5.jpg); width: 350px;height: 295px;top: 5px;left: 85px;"></div>
					   </div>
					   <div class="col-lg-6 mb-lg-0">
						 <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						   <h5 class="text-uppercase fw-bolder text-dark mb-2 text-goldren-300-hover transition-100">wonderful new villa</h5>
					     </a>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-3">$ 5.500.000 <span class="fs-6 fw-lighter"> \ month</span>
						 </h5>
						 <p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
					   </div>
					</div>	
				  </div>
				  <!-- === Testimonials information-2 === -->
				  <div class="carousel-item">
					<div class="row align-items-center justify-content-between">
					   <div class="col-lg-5 mb-lg-0 mb-5">
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_1" style="background-image:url(images/card_6.jpg);"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_2" style="background-image:url(images/sider-img3.jpg); left: 225px;"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat position-relative shadow" style="background-image:url(images/card_5.jpg); width: 350px;height: 295px;top: 5px;left: 85px;"></div>
					   </div>
					   <div class="col-lg-6 mb-lg-0">
						 <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						   <h5 class="text-uppercase fw-bolder text-dark mb-2 text-goldren-300-hover transition-100">wonderful new villa</h5>
					     </a>
						 <h5 class="text-uppercase fw-bolder text-parple-500 mb-3">$ 5.500.000 <span class="fs-6 fw-lighter"> \ month</span>
						 </h5>
						 <p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
					   </div>
					</div>  
				  </div>
				</div>
				<!-- === Testimonials indicators === -->
				<div class="carousel-indicators position-static mt-5 mb-0 testimonials-carousel">
				   <button type="button" data-bs-target="#testimonials" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1" class="text-light"></button>
				   <button type="button" data-bs-target="#testimonials" data-bs-slide-to="1" aria-label="Slide 2" class="text-light"></button>
				</div>
			 </div>
		   </div>
		</section>
		<!-- === === -->
		<section class="bg-light">
		   <div class="container-lg">
		     <div class="row g-4 justify-content-between">
			   <div class="col-md-7">
			     <h2 class="mb-3" style="font-weight:400;">Leave a message</h2>
				 <form action="" method="post">
				    <div class="mb-4">
					  <label class="form-label text-muted">Your Name (required)</label>
					  <input type="" class="form-control shadow-none rounded-0">
					</div>
					<div class="mb-4">
					  <label class="form-label text-muted">Your Name (required)</label>
					  <input type="" class="form-control shadow-none rounded-0">
					</div>
					<div class="mb-4">
					  <label class="form-label text-muted">Your Name (required)</label>
					  <textarea type="" class="form-control shadow-none rounded-0" rows="5"></textarea>
					</div>
					<input type="submit" class="btn px-4 rounded-0 fw-bold text-white bg-parple-500 border-0 bg-hover-dark-600" value="SEND">
				 </form>
			   </div>
			   <div class="col-md-4">
			     <h3 class="mb-3" style="font-weight:400;">Headquarters</h3>
				 <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</small></p>
				 <ul class="list-group mb-4">
				    <p class="mb-0 text-body-tertiary"><small>Business Park Theale C1, Center Berkshire RS1 5A1, England</small></p>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Phone :</span>
						  <small>(305) 555-4555</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Mobile :</span>
						  <small>(305) 555-4555</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Mobile :</span>
						  <small>305 445 4556</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Email :</span>
						  <small>08wasti@gmail.com</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Fax :</span>
						  <small>(305) 555-4555</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Skype :</span>
						  <small>wpestatetheme</small>
					   </span>
					</li>
				  </ul>
			   </div>
			 </div>
		   </div>
		</section>
	</main>
	<footer style="background-color: #483757;">
	    <section>
		  <div class="container-lg">
		    <div class="row justify-content-center text-center">
			  <div class="col-md-10">
			    <h5 class="mb-3 text-light">About Me</h5>
				<p class="text-light">
				   <small>WP ESTATE is committed to delivering a high level of expertise, customer service, and attention to detail to the marketing and sales of luxury real estate, and rental properties.  WP ESTATE is committed to delivering a high level of expertise, customer service, and attention to detail to the marketing and sales of luxury real estate, and rental properties. READ MORE</small>
				</p>
				<ul class="list-group list-group-horizontal justify-content-center">
				  <a href="#" class="nav-link h-3 w-3 text-primary bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
					<i class="fa-brands fa-facebook-f m-auto fa-lg"></i>
				  </a>
				  <a href="#" class="nav-link h-3 w-3 text-info bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
					<i class="fa-brands fa-twitter m-auto fa-lg"></i>
				  </a>
				  <a href="#" class="nav-link h-3 w-3 text-primary bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
					<i class="fa-brands fa-linkedin-in m-auto fa-lg"></i>
				  </a>
				  <a href="#" class="nav-link h-3 w-3 text-danger bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
					<i class="fa-brands fa-pinterest-p m-auto fa-lg"></i>
				  </a>
				</ul>
			  </div>
			</div>
		  </div>
		</section>
	</footer>
	<!-- Bootstrap js -->
    <script src="js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
  </body>
</html>