<?php include('header.php'); ?>
	<main>
	    <!-- === full width banar === -->
		<section class="pt-0 pb-0" id="full-width">
		   <div id="full-widthBanar" class="carousel slide carousel-fade" data-bs-ride="carousel">
			  <div class="carousel-indicators">
				<div data-bs-target="#full-widthBanar" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1">
				  <!-- === full width banar-sm-1 === -->
				  <img src="images/full-widthsm1.jpg" class="img-fluid border border-white border-2 shadow">
				</div>
				<div data-bs-target="#full-widthBanar" data-bs-slide-to="1" aria-label="Slide 2">
				  <!-- === full width banar-sm-2 === -->
				  <img src="images/full-widthsm2.jpg" class="img-fluid border border-white border-2 shadow">
				</div>
				<div data-bs-target="#full-widthBanar" data-bs-slide-to="2" aria-label="Slide 3">
				  <!-- === full width banar-sm-3 === -->
				  <img src="images/full-widthsm3.jpg" class="img-fluid border border-white border-2 shadow">
				</div>
				<div data-bs-target="#full-widthBanar" data-bs-slide-to="3" aria-label="Slide 4">
				  <!-- === full width banar-sm-4 === -->
				  <img src="images/full-widthsm4.jpg" class="img-fluid border border-white border-2 shadow">
				</div>
				<div data-bs-target="#full-widthBanar" data-bs-slide-to="4" aria-label="Slide 5">
				  <!-- === full width banar-sm-5 === -->
				  <img src="images/full-widthsm5.jpg" class="img-fluid border border-white border-2 shadow">
				</div>
			  </div>
			  <div class="carousel-inner z-0">
			    <!-- === full width banar-1 === -->
				<div class="carousel-item active">
				  <div class="background-size-cover background-repeat-no-repeat background-position-center fullwidth-banar" style="background-image:url(images/full-width1.jpg);"></div>
				</div>
				<!-- === full width banar-2 === -->
				<div class="carousel-item z-0">
				  <div class="background-size-cover background-repeat-no-repeat background-position-center fullwidth-banar" style="background-image:url(images/full-width2.jpg);"></div>
				</div>
				<!-- === full width banar-3 === -->
				<div class="carousel-item z-0">
				  <div class="background-size-cover background-repeat-no-repeat background-position-center fullwidth-banar" style="background-image:url(images/full-width3.jpg);"></div>
				</div>
				<!-- === full width banar-4 === -->
				<div class="carousel-item z-0">
				  <div class="background-size-cover background-repeat-no-repeat background-position-center fullwidth-banar" style="background-image:url(images/full-width4.jpg);"></div>
				</div>
				<!-- === full width banar-5 === -->
				<div class="carousel-item z-0">
				  <div class="background-size-cover background-repeat-no-repeat background-position-center fullwidth-banar" style="background-image:url(images/full-width5.jpg);"></div>
				</div>
			  </div>
			  <button class="carousel-control-prev w-auto opacity-100 align-items-md-end m-md-5" type="button" data-bs-target="#full-widthBanar" data-bs-slide="prev">
				<i class="fa-solid fa-chevron-left fa-2x ms-md-0 ms-3"></i>
			  </button>
			  <button class="carousel-control-next w-auto opacity-100 align-items-md-end m-md-5" type="button" data-bs-target="#full-widthBanar" data-bs-slide="next">
				<i class="fa-solid fa-chevron-right fa-2x me-md-0 me-3"></i>
			  </button>
			</div>
		</section>
	    <!-- === banar form === -->
		<section class="bg-light border-bottom pt-md-3 pb-md-4 pt-0 pb-2">
		  <?php include('form.php'); ?>
		</section>
		<section class="pt-2 pb-0 bg-sky-50">
		   <div class="container">
		     <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-0">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Linda Jackson</small></a>
				</li>
			   </ol>
			 </nav>
		   </div>
		</section>
		<!-- === linda-jackson profile === -->
		<section class="bg-sky-50 pt-3 pb-2">
		  <div class="container-lg">
		    <div class="row">
			  <!-- === === -->
			  <div class="col-lg-3 col-md-4 order-5 order-md-0">
			    <!-- ==== CHANGE YOUR CURRENCY card-1 ===== -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Change Your Currency</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						 <option value="">$</option>
						 <option value="1">EUR</option>
					  </select>
				   </form>
				</div>
				<!-- ==== advanced search card-2 ===== -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">advanced search</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Search">
				   </form>
				</div>
				<!-- ==== Mortgage Calculator card-3 ===== -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Mortgage Calculator</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Sale Price</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10000">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Percent Down</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Term (Years)</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="30">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Interest Rate in %</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="5">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Calculate">
				   </form>
				</div>
				<!-- ==== Spacious Office Space card-3 === -->
				<?php include('spacious-ofice.php'); ?>
			  </div>
			  <!-- === === -->
			  <div class="col-lg-9 col-md-8">
				<!-- === linda-jackson profile === -->
				<div class="card border-0 rounded-0 mb-3 shadow-sm text-md-start text-center">
				  <div class="card-body">
					<div class="d-md-flex justify-content-md-between align-items-md-center">
						<div class="d-md-flex">
						  <div class="flex-shrink-0">
							<img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="img-fluid rounded-circle border border-light-subtle border-5 mb-md-0 mb-3">
						  </div>
						  <div class="flex-grow-1 ms-md-3">
							<h2 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-capitalize text-goldren-300-hover">Daniel Taylor</a>	
							</h2>
							<p class="text-goldren-400 fw-semibold mb-1"><small>selling agent</small></p>
							<p class="text-secondary mb-0">
							  <small><span class="fw-semibold">Phone : </span>(305)555-4555</small>
							</p>
							<p class="text-secondary">
							  <small><span class="fw-semibold">Email : </span>linda@wpestatetheme.org</small>
							</p>
							<!-- === social media link === -->
							<ul class="list-group list-group-horizontal mb-3 justify-content-md-start justify-content-center">
							  <!-- === facebook === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-facebook-f fa-lg text-primary"></i>
							  </a> 
							  <!-- === twitter === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-twitter fa-lg text-info mx-2"></i>
							  </a>
							  <!-- === in === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-linkedin-in fa-lg text-primary"></i>
							  </a>
							  <!-- === pinterest === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-pinterest fa-lg text-danger mx-2"></i>
							  </a>
							</ul>
						  </div>
						</div>
						<div class="border border-1 rounded d-md-block d-none" style="height: 5rem;"></div>
						<div class="d-md-block d-none mb-0 text-center">
						  <h2 class="mb-0 text-body-tertiary">4</h2>
						  <p class="mb-0 fs-6 fw-semibold text-body-tertiary">listings</p>
						</div>
				    </div>
					<!-- === linda jackson btn === -->
					<div class="mt-3 mb-3">
						<a href="<?php echo $baseurl; ?>#" class="btn border-goldren-1 rounded-pill text-body-tertiary px-3 me-2 mb-md-0 mb-2">  
						   <small>residential</small>
						</a>
						<a href="<?php echo $baseurl; ?>#" class="btn border-goldren-1 rounded-pill text-body-tertiary px-3 me-2 mb-md-0 mb-2">  
						   <small>Commercial</small>
						</a>
						<a href="<?php echo $baseurl; ?>#" class="btn border-goldren-1 rounded-pill text-body-tertiary px-3 me-2 mb-md-0 mb-2">  
						   <small>miami</small>
						</a>
						<a href="<?php echo $baseurl; ?>#" class="btn border-goldren-1 rounded-pill text-body-tertiary px-3 me-2">  
						   <small>residential</small>
						</a>
						<a href="<?php echo $baseurl; ?>#" class="btn border-goldren-1 rounded-pill text-body-tertiary px-3 me-2">  
						   <small>florida</small>
						</a>
					</div>
				  </div>
				  <div class="row align-items-center text-center ms-0 me-0" style="background-color:#ebebebb0;">
					  <div class="col-md-3 col-6 border">
					    <div class="py-3">
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-decoration-none text-body-tertiary"><small>about me</small></a>
						</div>
					  </div>
					  <div class="col-md-3 col-6 border">
					    <div class="py-3">
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-decoration-none text-body-tertiary"><small>Contact Details</small></a>
						</div> 
					  </div>
					  <div class="col-md-3 col-6 border">
					    <div class="py-3">
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-decoration-none text-body-tertiary"><small>Contact Me</small></a>
						</div>
					  </div>
					  <div class="col-md-3 col-6 border">
					    <div class="py-3">
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-decoration-none text-body-tertiary"><small>My Listings</small></a>
						</div>
					  </div>
					</div>
				</div>
				<!-- === linda-jackson profile about me === -->
				<div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <h5 class="fs-6 text-uppercase fw-semibold mb-3">about me</h5>
					<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</small></p>
					<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</small></p>
					<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</small></p>
				</div>
			    <!-- === linda-jackson profile Contact Details === -->
				<div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <h5 class="fs-6 text-uppercase fw-semibold mb-3">Contact Details</h5>
					<div class="row align-items-center">
					  <div class="col-sm-6 mb-sm-0">
					    <p class="text-secondary">
						  <small><span class="fw-semibold">Phone : </span>(305)555-4555</small>
						</p>
						<p class="text-secondary">
						  <small><span class="fw-semibold">Email : </span>linda@wpestatetheme.org</small>
						</p>
						<p class="text-secondary">
						  <small>
						    <span class="fw-semibold">website : </span>
						    <a href="<?php echo $baseurl; ?>https://wasti66.tarikulsunny.com/" class="text-decoration-none text-secondary">wasti66.tarikulsunny.com</a>
						  </small>
						</p>
					  </div>
					  <div class="col-sm-6 mb-sm-0">
					    <p class="text-secondary">
						  <small><span class="fw-semibold">Mobile : </span>(305)555-4555</small>
						</p>
						<p class="text-secondary">
						  <small><span class="fw-semibold">Skype : </span>
						  Linda.Jackson</small>
						</p>
					  </div>
					</div>
				</div>
				<!-- === linda-jackson profile Contact me === -->
				<div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-md-5 mb-4">
				    <h5 class="fs-6 text-uppercase fw-semibold mb-3">Contact me</h5>
					<form action="" method="post">
					  <div class="row g-3">
					    <div class="col-md-4">
						  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Your Name">
						</div>
						<div class="col-md-4">
						  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Your Email">
						</div>
						<div class="col-md-4">
						  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Your Phone">
						</div>
					  </div>
					  <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus mt-3 mb-3" type="text" placeholder="Your Message" rows="5"></textarea>
					  <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
					</form>
				</div>
				<!-- === Similar Listings card === -->
				<h3 class="text-uppercase">Similar Listings</h3>
				<div class="card shadow-sm border-0 rounded-0 mb-3">
				  <div class="row g-0">
					<div class="col-lg-5">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
						<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/full-width2.jpg)">
						   <p class="py-5 my-5"></p>
						   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
						</div>
						<div class="card-img-overlay">
						  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
						  <p></p>
						</div>
					  </div>
					</div>
					<div class="col-lg-7">
					  <div class="card-body">
						<!-- === Serviced Business Apartment === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
						</h5>
						<div class=" mb-3">
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						</div>
						<div class="d-flex align-items-center mb-3">
						  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
						  <span class="mx-1 text-goldren-400">/</span>
						  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
						</div>
						<ul class="list-group list-group-horizontal text-center">
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
						  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						</ul>
					  </div>
					  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
							  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </div>
				</div>
				<!-- === === -->
				<div class="card shadow-sm border-0 rounded-0 mb-3">
				  <div class="row g-0">
					<div class="col-lg-5">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
						<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
						   <p class="py-5 my-5"></p>
						   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
						</div>
						<div class="card-img-overlay">
						  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
						  <p></p>
						</div>
					  </div>
					</div>
					<div class="col-lg-7">
					  <div class="card-body">
						<!-- === Serviced Business Apartment === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
						</h5>
						<div class=" mb-3">
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						</div>
						<div class="d-flex align-items-center mb-3">
						  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
						  <span class="mx-1 text-goldren-400">/</span>
						  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
						</div>
						<ul class="list-group list-group-horizontal text-center">
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
						  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						</ul>
					  </div>
					  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
							  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </div>
				</div>
				<!-- === === -->
				<div class="card shadow-sm border-0 rounded-0 mb-3">
				  <div class="row g-0">
					<div class="col-lg-5">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
						<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/full-width2.jpg)">
						   <p class="py-5 my-5"></p>
						   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
						</div>
						<div class="card-img-overlay">
						  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
						  <p></p>
						</div>
					  </div>
					</div>
					<div class="col-lg-7">
					  <div class="card-body">
						<!-- === Serviced Business Apartment === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
						</h5>
						<div class=" mb-3">
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						</div>
						<div class="d-flex align-items-center mb-3">
						  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
						  <span class="mx-1 text-goldren-400">/</span>
						  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
						</div>
						<ul class="list-group list-group-horizontal text-center">
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
						  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						</ul>
					  </div>
					  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
							  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </div>
				</div>
				<!-- === === -->
				<div class="card shadow-sm border-0 rounded-0 mb-3">
				  <div class="row g-0">
					<div class="col-lg-5">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
						<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
						   <p class="py-5 my-5"></p>
						   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
						</div>
						<div class="card-img-overlay">
						  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
						  <p></p>
						</div>
					  </div>
					</div>
					<div class="col-lg-7">
					  <div class="card-body">
						<!-- === Serviced Business Apartment === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
						</h5>
						<div class=" mb-3">
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
						   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						</div>
						<div class="d-flex align-items-center mb-3">
						  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
						  <span class="mx-1 text-goldren-400">/</span>
						  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
						</div>
						<ul class="list-group list-group-horizontal text-center">
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
						  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
						  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						</ul>
					  </div>
					  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
							  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>