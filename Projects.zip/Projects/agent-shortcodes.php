<?php include('header.php'); ?>
	<main>
		<!-- === === -->
		<section class="bg-light pt-3">
		  <div class="container-lg">
		    <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-5">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Agent Shortcodes</small></a>
				</li>
			   </ol>
			</nav>
		    <div class="row justiy-content-center mt-5 g-4">
			  <h1 class="text-capitalize fw-bolder opacity-75 text-center mb-5">Featured Agent</h1>
			  <!-- === Featured card-1 === -->
			  <div class="col-sm-6">
			    <div class="card custom-shadow border-0 rounded-0 h-100">
				  <div class="row g-0">
					<div class="col-lg-6">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
					    <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/person3-500x350.jpg)">
						   <p class="py-5 my-5 d-block d-lg-none"></p>
						   <a href="<?php echo $baseurl; ?>#" class="btn btn-sm border-0 rounded-0 text-light bg-goldren-300 bg-hover-dark-600 my-4 mx-md-4 mx-5">MY LISTINGS</a>
						</div>
					  </div>
					</div>
					<div class="col-lg-6">
					  <div class="card-body">
					    <!-- === team member name === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">daniel taylor</a>	
						</h5>
						<small class="text-goldren-400">real estate broker</small>
						<!-- === team member contact info === -->
						<ul class="list-group mt-3 mb-3">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					    </ul>
						<!-- === team member social media link === -->
						<div class="row g-0">
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-facebook-f m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border border-start-0 rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-twitter m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-linkedin-in m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-pinterest-p m-auto fa-sm flex-shrink-0"></i>
						  </a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- === Featured card-2 === -->
			  <div class="col-sm-6">
			    <div class="card custom-shadow border-0 rounded-0 h-100">
				  <div class="row g-0">
					<div class="col-lg-6">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
					    <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/member_1.jpg)">
						   <p class="py-5 my-5 d-block d-lg-none"></p>
						   <a href="<?php echo $baseurl; ?>#" class="btn btn-sm border-0 rounded-0 text-light bg-goldren-300 bg-hover-dark-600 my-4 mx-md-4 mx-5">MY LISTINGS</a>
						</div>
					  </div>
					</div>
					<div class="col-lg-6">
					  <div class="card-body">
					    <!-- === team member name === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">daniel taylor</a>	
						</h5>
						<small class="text-goldren-400">real estate broker</small>
						<!-- === team member contact info === -->
						<ul class="list-group mt-3 mb-3">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					    </ul>
						<!-- === team member social media link === -->
						<div class="row g-0">
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-facebook-f m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border border-start-0 rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-twitter m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-linkedin-in m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-pinterest-p m-auto fa-sm flex-shrink-0"></i>
						  </a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		<section>
		  <div class="container-lg">
		    <div class="row g-4 justify-content-center">
			    <h1 class="text-capitalize fw-bolder opacity-75 text-center mb-3">Listings per Agent</h1>
			    <!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-2 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-3 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_6.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class="mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
			</div>
		  </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>