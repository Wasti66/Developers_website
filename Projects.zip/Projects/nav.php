<?php
	include('baseurl.php');
?>
<!-- === nav bar === -->
<nav class="navbar navbar-expand-lg navbar-phone custom-nav">
  <div class="container-lg">
	<!-- === developers company logo === -->
	<a class="navbar-brand order-5 order-sm-0" href="index.php">
	  <img src="<?php echo $baseurl; ?>images/logomiami.png" class="img-fluid d-none d-sm-block">
	  <!-- === mobile device logo === -->
	  <img src="<?php echo $baseurl; ?>images/logo_mobile.png" class="d-sm-none d-block" style="height: 55px;">
	</a>
	<button class="navbar-toggler shadow-none border-0 custom-toggle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDark">
	  <i class="fa-solid fa-bars fa-xl"></i>
	</button>
	<div class="offcanvas offcanvas-start text-bg-dark" tabindex="-1" id="offcanvasDark" aria-labelledby="offcanvasDarkLabel">
	  <!-- ==== offcanvas header === -->
	  <div class="offcanvas-header justify-content-end">
		<button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	  </div>
	  <!-- ==== offcanvas body === -->
	  <div class="offcanvas-body">
		<ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
		   <!-- ==== home === -->
		   <li class="nav-item">
			  <a class="nav-link active text-uppercase fw-semibold text-goldren-400 mx-2" href="<?php echo $baseurl; ?>index.php">
				<small>Home</small>
			  </a>
		   </li>
		   <!-- === Properties === -->
		   <li class="nav-item hover-dropdown hover-dropdown-100">
			 <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
			   <small>Properties</small>
			   <i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
			 </a>
			 <div class="dropdown-menu end-0 border-0 p-0 mt-0 bg-transparent dropdown-menu-hover">
			   <div class="container bg-white border mx-auto w-75 p-3 border rounded-lg-0 rounded responsve-dropdown">
				 <div class="row gy-lg-0 gy-3">
				   <!-- === Property Page Slider Design === -->
				   <div class="col-lg-3 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>property pasge slider design</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>spacious-office-space.php">
						 <small>Slider Vertical</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>slider-horizontal.php">
						<small>Slider Horizontal</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>slider-gallery.php">
						<small>Slider Gallery</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>full-width.php">
						<small>Full Width</small>
					  </a>
				   </div>
				   <!-- === Property page header type === -->
				   <div class="col-lg-3 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>Property page header type</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>house-with-swimming-pool.php">
						 <small>No Header</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>villa-to-be-refurnished.php">
						<small>Google Map</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>house-with-garden-and-pool.php">
						<small>Revolution Slider</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>unique-house-in-miami.php">
						<small>Theme Slider Type 2</small>
					  </a>
				   </div>
				   <!-- === Properties Lists === -->
				   <div class="col-lg-3 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>Properties Lists</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>property-list-half-map.php">
						 <small>Half Map</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>properties-list.php">
						<small>Standard – No Sidebar</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>property-list-with-sidebar.php">
						<small>Standard – Sidebar Right</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>property-list-sidebar-left.php">
						<small>Standard – Sidebar Left</small>
					  </a>
				   </div>
				   <!-- === Properties by Type === -->
				   <div class="col-lg-3 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>Properties by Type</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>apartments.php">
						 <small>Category</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>sales.php">
						<small>Type</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>miami.php">
						<small>City</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>south-beach.php">
						<small>Area</small>
					  </a>
				   </div>
				 </div>
			   </div>
			 </div>	
		   </li>	
		   <!-- === our team === -->
		   <li class="nav-item hover-dropdown hover-dropdown-100">
			 <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
			   <small>our team</small>
			   <i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
			 </a>
			 <div class="dropdown-menu end-0 border-0 p-0 mt-0 bg-transparent dropdown-menu-hover">
			   <div class="container bg-white border mx-auto w-75 p-3 border rounded-lg-0 rounded responsve-dropdown">
				 <div class="row gy-lg-0 gy-3">
				   <!-- === Agent Page Header Type === -->
				   <div class="col-lg-4 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>Agent Page Header Type</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>linda-jackson.php">
						 <small>No Header</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>daniel-taylor.php">
						<small>Google Map</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>charles-miller.php">
						<small>Revolution Slider</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>susan-anderson.php">
						<small>Theme Slider Type 2</small>
					  </a>
				   </div>
				   <!-- === Agent Lists === -->
				   <div class="col-lg-4 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>Properties Lists</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-list-template.php">
						 <small>No Sidebar</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-list-sidebar-right.php">
						<small>Sidebar Right</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-list-sidebar-left.php">
						<small>Sidebar Left</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-shortcodes.php">
						<small>Agent Shortcodes</small>
					  </a>
				   </div>
				   <!-- === Agents by type === -->
				   <div class="col-lg-4 col-sm-6">
					  <p class="text-uppercase fw-bolder opacity-75 mb-2">
						<small>Agents by type</small>
					  </p>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent_listingsres-idential.php">
						 <small>Category</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-action-commercial.php">
						<small>Type</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-citymiami.php">
						<small>City</small>
					  </a>
					  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>agent-areacoconut-grove.php">
						<small>Area</small>
					  </a>
				   </div>
				 </div>
			   </div>
			 </div>	
		   </li>
		   <!-- === news === -->
		   <li class="nav-item hover-dropdown">
			  <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				<small>news</small>
				<i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
			  </a>
			  <ul class="dropdown-menu py-0 mt-0 rounded-0 left-auto dropdown-menu-hover">
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>full-width-post.php">
					<small>full width post</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>sidebar-on-the-right.php">
					<small>Sidebar Right Post</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>sidebar-on-the-left.php">
					<small>Sidebar Left Post</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>blog.php">
					<small>Blog List – No Sidebar</small>
				  </a>
				</li>
			  </ul>
		   </li>
		   <!-- === Features === -->
		   <li class="nav-item hover-dropdown">
			  <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				<small>Features</small>
				<i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
			  </a>
			  <ul class="dropdown-menu py-0 mt-0 rounded-0 left-auto dropdown-menu-hover">
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>contact-us.php">
					<small>contact us</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>property-shortcodes.php">
					<small>property shortcodes</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>featured-property-shortcodes.php">
					<small>fetured property shortcodes</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>post-shortcodes.php">
					<small>post shortcodes</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>agent-shortcode.php">
					<small>again shortcodes</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>other-shortcodes.php">
					<small>other shortcodes</small>
				  </a>
				</li>
			  </ul>
		   </li>
			<!-- === Demos === -->
			<li class="nav-item hover-dropdown">
			  <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				<small>Demos</small>
				<i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
			  </a>
			  <ul class="dropdown-menu py-0 mt-0 rounded-0 left-auto dropdown-menu-hover">
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>post-shortcodes.php">
					<small>post shortcodes</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>agent-shortcode.php">
					<small>again shortcodes</small>
				  </a>
				</li>
				<li><hr class="dropdown-divider m-0"></li>
				<li>
				  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>other-shortcodes.php">
					<small>other shortcodes</small>
				  </a>
				</li>
			  </ul>
			</li>
		</ul>
	  </div>
	</div>
  </div>
</nav>