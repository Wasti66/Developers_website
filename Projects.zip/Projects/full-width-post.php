<?php include('header.php'); ?>
	<main>
	    <!-- === nav === -->
		<section class="pt-2 pb-0 bg-sky-50">
		   <div class="container-lg">
		     <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-0">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				   <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Buying Properties</small></a>
				   <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Location</small></a>
				   <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Price</small></a>
				   <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Real Estate</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Full Width Post</small></a>
				</li>
			   </ol>
			 </nav>
		   </div>
		</section>
		<!-- === full width post === -->
		<section class="bg-sky-50 pt-3">
		  <div class="container-lg">
		    <div class="row">
			  <div class="col-12">
			    <!-- === post card === -->
				<div class="card card-body border-0 rounded-0 shdow-sm mb-4">
				  <h1 class="text-capitalize fw-lighter mb-4">full width post</h1>
				  <div class="d-flex align-items-center mb-4">
					<div class="flex-shrink-0">
					   <img src="<?php echo $baseurl; ?>images/post_img.jpeg" class="h-3 w-3 rounded-circle">
					</div>
					<div class="flex-grow-1 ms-2">
					   <p class="fs-6 text-secondary mb-0"><small> by admin on May 27, 2023</small></p>
					</div>
				  </div>
				  <img src="<?php echo $baseurl; ?>images/post_bg.jpg" class="img-fluid mb-2">
				  <div class="d-md-flex justify-content-md-between align-items-center mb-4">
				    <div class="d-flex align-items-center">
					  <i class="fa-regular fa-file fa-sm me-1"></i>
					  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Buying Properties,</small></a>
					  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Location,</small></a>
					  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Price,</small></a>
					  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Real Estate</small></a>
					</div> 
					<p class="text-secondary fw-semibold mb-0">
					  <small>Comments:0</small>
					</p>
				  </div>
				  <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
				  <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
				  <hr class="opacity-25">
				  <div class="card-footer bg-transparent border-0 d-flex align-items-center px-0">
				    <div class="flex-shrink-0">
					  <p class="text-secondary fw-bold mb-0">Share</p>
					</div>
					<ul class="list-group list-group-horizontal ms-2">
					  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 text-primary d-flex me-2 border text-decoration-none">
						<i class="fa-brands fa-facebook-f m-auto fa-sm"></i>
					  </a>
					  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 text-info d-flex me-2 border text-decoration-none">
						<i class="fa-brands fa-twitter m-auto fa-sm"></i>
					  </a>
					  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 text-primary d-flex me-2 border text-decoration-none">
						<i class="fa-brands fa-linkedin-in m-auto fa-sm"></i>
					  </a>
					  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 text-danger d-flex me-2 border text-decoration-none">
						<i class="fa-brands fa-pinterest-p m-auto fa-sm"></i>
					  </a>
					</ul>
				  </div>
				</div>
				<!-- === Related Posts === -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				  <h3 class="text-capitalize mb-4">Related Posts</h3>
				  <div class="row g-3 mb-4">
				    <!-- === Related Posts card-1 === -->
				    <div class="col-lg-3 col-md-4 col-sm-6">
						<div class="card h-100 rounded-top-0">
						  <img src="<?php echo $baseurl; ?>images/recent_post1.jpg" class="img-fluid">
						  <div class="card-body">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							  <h6 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">Sidebar on the Left</h6>
							</a>
							<p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
						  </div>
						</div>
					</div>
					<!-- === Related Posts card-2 === -->
					<div class="col-lg-3 col-md-4 col-sm-6">
						<div class="card h-100 rounded-top-0">
						  <img src="<?php echo $baseurl; ?>images/recent_post2.jpeg" class="img-fluid">
						  <div class="card-body">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							  <h6 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">Sidebar on the Right</h6>
							</a>
							<p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
						  </div>
						</div>
					</div>
				  </div>
				</div>
				<!-- === LEAVE A REPLY === -->
				<div class="card border-0 rounded-0 shadow-sm">
				  <div class="card-body">
				    <h6 class="text-uppercase mb-4">leave a perty</h6>
					<form action="" method="post">
					  <p class="fs-6 text-secondary mb-0"><small>Your email address will not be published. </small></p>
					  <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus mb-4" type="text" placeholder="Your Message" rows="5"></textarea>
					  <div class="row g-3">
					    <div class="col-md-4">
						  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Your Name">
						</div>
						<div class="col-md-4">
						  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Your Email">
						</div>
						<div class="col-md-4">
						  <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Website">
						</div>
					  </div>
					  <div class="form-check mt-3">
						<input class="form-check-input shadow-sm rounded-0" type="checkbox" value="">
						<label class="form-check-label text-secondary">
							<small>Save my name, email, and website in this browser for the next time I comment.</small>
						</label>
					  </div>
					  <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 mt-3" value="POST COMMENT">
				    </form>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>