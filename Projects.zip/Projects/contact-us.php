<?php include('header.php'); ?>
	<main>
	    <!-- === google map map === -->
		<section class="pt-0 pb-0">
		   <?php include('map.php'); ?>
		</section>
		<!-- === nav === -->
		<section class="pt-2 pb-0 bg-sky-50">
		   <div class="container-lg">
		     <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-0">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Contact US</small></a>
				</li>
			   </ol>
			 </nav>
		   </div>
		</section>
		<!-- === sidebar on the right post === -->
		<section class="bg-sky-50 pt-4">
		   <div class="container-lg">
		     <h3 class="text-capitalize mb-3">contact us</h3>
		     <div class="row">
			   <div class="col-md-6 mb-md-0 mb-4">
			      <img src="<?php echo $baseurl; ?>images/company-interior.jpg" class="img-fluid rounde shadow-sm mb-4">
				  <h5 class="text-uppercase mb-3">wpestate</h5>
				  <ul class="list-group mb-4">
				    <p class="mb-0 text-body-tertiary"><small>Business Park Theale C1, Center Berkshire RS1 5A1, England</small></p>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Phone :</span>
						  <small>(305) 555-4555</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Mobile :</span>
						  <small>(305) 555-4555</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Mobile :</span>
						  <small>305 445 4556</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Email :</span>
						  <small>08wasti@gmail.com</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Fax :</span>
						  <small>(305) 555-4555</small>
					   </span>
					</li>
					<li class="list-group-item border-0 p-0 bg-transparent">
					   <span class="text-body-tertiary d-flex align-items-center">
						  <span class="fw-semibold me-2 text-secondary">Skype :</span>
						  <small>wpestatetheme</small>
					   </span>
					</li>
				  </ul>
				  <hr class="opacity-25 text-secondary">
				  <!-- === social media link === -->
				  <ul class="list-group list-group-horizontal">
					  <!-- === facebook === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
						<i class="fa-brands fa-facebook-f fa-lg text-primary"></i>
					  </a> 
					  <!-- === twitter === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
						<i class="fa-brands fa-twitter fs-6 text-info"></i>
					  </a>
					  <!-- === instagram === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
						<i class="fa-brands fa-instagram fa-lg text-danger"></i>
					  </a>
					  <!-- === in === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
						<i class="fa-brands fa-linkedin-in fa-lg text-primary"></i>
					  </a>
					  <!-- === pinterest === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
						<i class="fa-brands fa-pinterest fa-lg text-danger"></i>
					  </a>
				  </ul>
			   </div>
			   <div class="col-md-6">
			     <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</small></p>
				 <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</small></p>
				 <form action="" method="post" class="mt-md-5 mt-4">
				    <!-- === name === -->
				    <div class="mb-4">
					   <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus border-0" type="text" placeholder="Your Name">
				    </div>
					<!-- === email === -->
					<div class="mb-4">
					   <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus border-0" type="text" placeholder="Your Email">
				    </div>
					<!-- === phone === -->
					<div class="mb-4">
					   <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus border-0" type="number" placeholder="Your Phone">
				    </div>
					<!-- === message textarea === -->
					<div class="mb-4">
					   <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus mb-4 border-0" type="text" placeholder="Your Message" rows="5"></textarea>
					</div>
					<input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
				 </form>
			   </div>
			 </div>
		   </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>