<?php include('header.php'); ?>
	<main>
	    <!-- === google map map === -->
		<section class="pt-0 pb-0">
		   <?php include('map.php'); ?>
		</section>
	    <!-- === banar form === -->
		<section class="bg-light border-bottom pt-md-3 pb-md-4 pt-0 pb-2">
		  <?php include('form.php'); ?>
		</section>
		<!-- === === -->
		<section class="pt-2 pb-0 bg-sky-50">
		   <div class="container-lg">
		     <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-0">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Agent List – Sidebar Right</small></a>
				</li>
			   </ol>
			 </nav>
		   </div>
		</section>
		<!-- === -->
		<section class="pt-3 bg-sky-50">
		  <div class="container-lg">
		    <div class="row">
			  <div class="col-lg-3 col-md-4 order-5 order-md-0">
			    <div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Change Your Currency</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						 <option value="">$</option>
						 <option value="1">EUR</option>
					  </select>
				   </form>
				</div> 
				<!-- === advance search === -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">advanced search</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Search">
				   </form>
				</div>
				<!-- ===  Mortgage Calculator === -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Mortgage Calculator</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Sale Price</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10000">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Percent Down</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Term (Years)</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="30">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Interest Rate in %</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="5">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Calculate">
				   </form>
				</div>
				<!-- ===  Spacious Office Space === -->
				<?php include('spacious-ofice.php'); ?>
			  </div>
			  <div class="col-lg-9 col-md-8">
			     <h1 class="text-capitalize fw-lighter mb-3">Agent List – Sidebar Right</h1>
			     <!-- === Agent List – Sidebar Right card === -->
			     <div class="row g-4">
				   <!-- ==== card-1 ==== -->
				   <div class="col-lg-6">
				      <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
						<div class="card border-0 rounded-0 overflow-hidden">
						  <img src="<?php echo $baseurl; ?>images/member_1.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
						  <div class="card-img-overlay d-flex align-items-end p-0">
							 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
							   <p class="mb-0"><small>real estate broker</small></p>
							 </div>
						  </div>
						</div>
						<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
						   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
							 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
						   </a>
						</div>
						<div class="card-body pt-0">
						   <h5 class="text-uppercase fw-bolder mb-2">
							 <a href="<?php echo $baseurl; ?>#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
						   </h5>
						   <ul class="list-group">
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
								   <small>08wasti@gmail.com</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
								   <small>Daniel.Taylor</small>
								</span>
							  </li>
						   </ul>
						</div>
						<!-- === === -->
						<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
							<ul class="list-group list-group-horizontal">
							  <!-- === facebook === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
							  </a> 
							  <!-- === twitter === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
							  </a>
							  <!-- === in === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
							  </a>
							  <!-- === pinterest === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
							  </a>
							</ul>
							<span class="badge bg-goldren-300 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
						</div>
					  </div>
				   </div>
				   <!-- ==== card-2 ==== -->
				   <div class="col-lg-6">
				      <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
						<div class="card border-0 rounded-0 overflow-hidden">
						  <img src="<?php echo $baseurl; ?>images/person3-500x350.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
						  <div class="card-img-overlay d-flex align-items-end p-0">
							 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
							   <p class="mb-0"><small>real estate broker</small></p>
							 </div>
						  </div>
						</div>
						<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
						   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
							 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
						   </a>
						</div>
						<div class="card-body pt-0">
						   <h5 class="text-uppercase fw-bolder mb-2">
							 <a href="<?php echo $baseurl; ?>#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
						   </h5>
						   <ul class="list-group">
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
								   <small>08wasti@gmail.com</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
								   <small>Daniel.Taylor</small>
								</span>
							  </li>
						   </ul>
						</div>
						<!-- === === -->
						<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
							<ul class="list-group list-group-horizontal">
							  <!-- === facebook === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
							  </a> 
							  <!-- === twitter === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
							  </a>
							  <!-- === in === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
							  </a>
							  <!-- === pinterest === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
							  </a>
							</ul>
							<span class="badge bg-goldren-300 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
						</div>
					  </div>
				   </div>
				   <!-- ==== card-3 ==== -->
				   <div class="col-lg-6">
				      <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
						<div class="card border-0 rounded-0 overflow-hidden">
						  <img src="<?php echo $baseurl; ?>images/team_member_3.png" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
						  <div class="card-img-overlay d-flex align-items-end p-0">
							 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
							   <p class="mb-0"><small>real estate broker</small></p>
							 </div>
						  </div>
						</div>
						<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
						   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
							 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
						   </a>
						</div>
						<div class="card-body pt-0">
						   <h5 class="text-uppercase fw-bolder mb-2">
							 <a href="<?php echo $baseurl; ?>#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
						   </h5>
						   <ul class="list-group">
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
								   <small>08wasti@gmail.com</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
								   <small>Daniel.Taylor</small>
								</span>
							  </li>
						   </ul>
						</div>
						<!-- === === -->
						<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
							<ul class="list-group list-group-horizontal">
							  <!-- === facebook === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
							  </a> 
							  <!-- === twitter === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
							  </a>
							  <!-- === in === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
							  </a>
							  <!-- === pinterest === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
							  </a>
							</ul>
							<span class="badge bg-goldren-300 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
						</div>
					  </div>
				   </div>
				   <!-- ==== card-4 ==== -->
				   <div class="col-lg-6">
				      <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
						<div class="card border-0 rounded-0 overflow-hidden">
						  <img src="<?php echo $baseurl; ?>images/team_member_4.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
						  <div class="card-img-overlay d-flex align-items-end p-0">
							 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
							   <p class="mb-0"><small>real estate broker</small></p>
							 </div>
						  </div>
						</div>
						<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
						   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
							 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
						   </a>
						</div>
						<div class="card-body pt-0">
						   <h5 class="text-uppercase fw-bolder mb-2">
							 <a href="<?php echo $baseurl; ?>#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
						   </h5>
						   <ul class="list-group">
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
								   <small>(305) 555-4555</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
								   <small>08wasti@gmail.com</small>
								</span>
							  </li>
							  <li class="list-group-item border-0 ps-0 pb-0">
								<span class="text-body-tertiary fw-semibold d-flex align-items-center">
								   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
								   <small>Daniel.Taylor</small>
								</span>
							  </li>
						   </ul>
						</div>
						<!-- === === -->
						<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
							<ul class="list-group list-group-horizontal">
							  <!-- === facebook === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
							  </a> 
							  <!-- === twitter === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
							  </a>
							  <!-- === in === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
							  </a>
							  <!-- === pinterest === -->
							  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-2">
								<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
							  </a>
							</ul>
							<span class="badge bg-goldren-300 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
						</div>
					  </div>
				   </div>
				 </div>
			  </div>
			</div>
		  </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>