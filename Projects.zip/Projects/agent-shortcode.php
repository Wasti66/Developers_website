<?php

	include('agent-shortcodes.php');

?>