<?php

	$baseurl = "http://localhost/PFSWD-Batch05/Projects/";

?>