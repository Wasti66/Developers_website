<?php include('header.php'); ?>
	<main>
		<!-- === sidebar-on-the-right banar === -->
		<section class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/header.jpeg);">
		  <p class="py-md-5"></p>
		</section>
		<!-- === banar form === -->
		<section class="bg-light border-bottom pt-md-3 pb-md-4 pt-0 pb-2">
		  <?php include('form.php'); ?>
		</section>
		<!-- === nav === -->
		<section class="pt-2 pb-0 bg-sky-50">
		   <div class="container-lg">
		     <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-0">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Blog</small></a>
				</li>
			   </ol>
			 </nav>
		   </div>
		</section>
		<!-- === sidebar on the right post === -->
		<section class="bg-sky-50 pt-3">
		   <div class="container-lg">
		     <div class="row">
				<div class="col-12">
				  <h3 class="text-capitalize mb-3">blog</h3>
				  <!-- === blog card-1 === -->
				  <div class="card shadow-sm border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				  </div>
				  <!-- === blog card-2 === -->
				  <div class="card shadow-sm border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/full-width2.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				  </div>
				  <!-- === blog card-3 === -->
				  <div class="card shadow-sm border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_3.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				  </div>
				  <!-- === blog card-4 === -->
				  <div class="card shadow-sm border-0 rounded-0">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/virtical_card.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				  </div>
				</div>
			 </div>
		   </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>