<?php include('header.php'); ?>
	<main>
	    <!-- === Recent Items - Properties Vertical === -->
		<section class="bg-sky-50 pt-3">
		  <div class="container-lg">
		    <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-5">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Property Shortcodes</small></a>
				</li>
			   </ol>
			</nav>
		    <div class="row justiy-content-center mt-5 g-4">
			  <h1 class="text-capitalize fw-bolder text-center mb-4">Recent Items - Properties Vertical</h1>
			    <!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
			    <!-- === featured-2 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-3 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_6.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
			</div>
		  </div>
		</section>
		<!-- === Recent Items – Properties Horizontal === -->
		<section>
		  <div class="container-lg">
		    <div class="row justify-content-center">
			   <div class="col-12">
			     <h1 class="text-capitalize fw-bolder opacity-75 text-center mb-4">Recent Items – Properties Horizontal</h1>
				 <!-- list 1 -->
				 <div class="card shadow border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/full-width2.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
							<div class="card-img-overlay">
							  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">Featured</span>
							  <p></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
							</h5>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="images/person3-120x120.jpg" class="h-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
								   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					  </div>
				 </div>
				 <!-- list 2 -->
				 <div class="card shadow border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
							<div class="card-img-overlay">
							  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">Featured</span>
							  <p></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
							</h5>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
								   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					  </div>
				 </div>
				 <a href="<?php echo $baseurl; ?>#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase">more listing</a>
			   </div>
			</div>
		  </div>
		</section>
		<!-- === slider type 1 === -->
		<section class="bg-sky-50" id="blog">
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-12">
			      <h1 class="text-capitalize fw-bolder text-center mb-4">Recent Properties Slider Type 1</h1>
			   </div>
			 </div>
			 <div class="position-relative">
			   <div class="swiper ourblog">
				  <div class="swiper-wrapper">
				    <!-- our blog-1 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<div class="card custom-shadow rounded-0 border-0 h-100">
						  <div class="card border-0 rounded-0 overflow-hidden">
							<!-- === featured images 1 === -->
							<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
							<!-- === card-img-overlay-1 === -->
							<div class="card-img-overlay">
							   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
							</div>
							<!-- === card-img-overlay-2 === -->
							<div class="card-img-overlay d-flex justify-content-end align-items-end">
							   <span class="fs-6 text-light">compare</span>
							</div>
						  </div>
						  <!-- === featured information content === -->
						  <div class="card-body">
							 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
							 <div class=" mb-3">
								<a href="#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
								<a href="#" class="text-decoration-none fs-6 text-secondary">Miami</a>
							 </div>
							 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
							 <ul class="list-group list-group-horizontal justify-content-center text-center">
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">3</span>
								 <span class="text-body-tertiary"><small>baths</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">5</span>
								 <span class="text-body-tertiary"><small>bedrooms</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
								 <span class="text-body-tertiary"><small>size</small></span>
							   </li>
							 </ul>
						  </div>
						  <!-- === === -->
						  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
								   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="#" class="text-decoration-none fa-lg">
								  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
								</a>
							 </div>
						  </div>
						</div>
					  </a>
					</div>
					<!-- our blog-2 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<div class="card custom-shadow rounded-0 border-0 h-100">
						  <div class="card border-0 rounded-0 overflow-hidden">
							<!-- === featured images 1 === -->
							<img src="<?php echo $baseurl; ?>images/card_5.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
							<!-- === card-img-overlay-1 === -->
							<div class="card-img-overlay">
							   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
							</div>
							<!-- === card-img-overlay-2 === -->
							<div class="card-img-overlay d-flex justify-content-end align-items-end">
							   <span class="fs-6 text-light">compare</span>
							</div>
						  </div>
						  <!-- === featured information content === -->
						  <div class="card-body">
							 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
							 <div class=" mb-3">
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
							 </div>
							 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
							 <ul class="list-group list-group-horizontal justify-content-center text-center">
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">3</span>
								 <span class="text-body-tertiary"><small>baths</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">5</span>
								 <span class="text-body-tertiary"><small>bedrooms</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
								 <span class="text-body-tertiary"><small>size</small></span>
							   </li>
							 </ul>
						  </div>
						  <!-- === === -->
						  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
								   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
								  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
								</a>
							 </div>
						  </div>
						</div>
					  </a>
					</div>
					<!-- our blog-3 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<div class="card custom-shadow rounded-0 border-0 h-100">
						  <div class="card border-0 rounded-0 overflow-hidden">
							<!-- === featured images 1 === -->
							<img src="<?php echo $baseurl; ?>images/card_2.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
							<!-- === card-img-overlay-1 === -->
							<div class="card-img-overlay">
							   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
							</div>
							<!-- === card-img-overlay-2 === -->
							<div class="card-img-overlay d-flex justify-content-end align-items-end">
							   <span class="fs-6 text-light">compare</span>
							</div>
						  </div>
						  <!-- === featured information content === -->
						  <div class="card-body">
							 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
							 <div class=" mb-3">
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
							 </div>
							 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
							 <ul class="list-group list-group-horizontal justify-content-center text-center">
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">3</span>
								 <span class="text-body-tertiary"><small>baths</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">5</span>
								 <span class="text-body-tertiary"><small>bedrooms</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
								 <span class="text-body-tertiary"><small>size</small></span>
							   </li>
							 </ul>
						  </div>
						  <!-- === === -->
						  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
								   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
								  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
								</a>
							 </div>
						  </div>
						</div>
					  </a>
					</div>
					<!-- our blog-4 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<div class="card custom-shadow rounded-0 border-0 h-100">
						  <div class="card border-0 rounded-0 overflow-hidden">
							<!-- === featured images 1 === -->
							<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
							<!-- === card-img-overlay-1 === -->
							<div class="card-img-overlay">
							   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
							</div>
							<!-- === card-img-overlay-2 === -->
							<div class="card-img-overlay d-flex justify-content-end align-items-end">
							   <span class="fs-6 text-light">compare</span>
							</div>
						  </div>
						  <!-- === featured information content === -->
						  <div class="card-body">
							 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
							 <div class=" mb-3">
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
							 </div>
							 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
							 <ul class="list-group list-group-horizontal justify-content-center text-center">
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">3</span>
								 <span class="text-body-tertiary"><small>baths</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">5</span>
								 <span class="text-body-tertiary"><small>bedrooms</small></span>
							   </li>
							   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
								 <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
								 <span class="text-body-tertiary"><small>size</small></span>
							   </li>
							 </ul>
						  </div>
						  <!-- === === -->
						  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
								   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
								  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
								</a>
							 </div>
						  </div>
						</div>
					  </a>
					</div>
				  </div>
			   </div>
			   <!-- next,prev btn === -->
			   <button type="button" class="btn swiper-button-next h-2 w-2 bg-goldren-300 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-right"></i>
			   </button>
			   <button type="button" class="btn swiper-button-prev h-2 w-2 bg-goldren-300 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-left"></i>
			   </button>
			   <div class="swiper-pagination"></div>
			 </div>
		   </div>
		</section>
		<!-- === slider type 2 === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center">
			   <h1 class="text-capitalize opacity-75 fw-bolder text-center mb-5">Recent Properties Slider Type 2</h1>
			 </div>
			 <!-- === Testimonials carousel start === -->
			 <div id="testimonials" class="carousel slide">
				<button class="carousel-control-prev bottom-100 left-auto justify-content-end py-3" type="button" data-bs-target="#testimonials" data-bs-slide="prev" style="right: 25px;">
					<i class="fa-solid fa-chevron-left text-dark fs-5"></i>
				</button>
				<div></div>
				<button class="carousel-control-next bottom-100 justify-content-end py-3 me-2" type="button" data-bs-target="#testimonials" data-bs-slide="next">
					<i class="fa-solid fa-chevron-right text-dark fs-5"></i>
				</button>
				<!-- === Testimonials carousel-inner === -->
				<div class="carousel-inner">
				  <!-- === Testimonials information-1 === -->
				  <div class="carousel-item active">
				    <div class="row align-items-center justify-content-between">
					   <div class="col-lg-5 mb-lg-0 mb-5">
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_1" style="background-image:url(images/card_6.jpg);"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_2" style="background-image:url(images/sider-img3.jpg); left: 225px;"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat position-relative shadow" style="background-image:url(images/card_5.jpg); width: 350px;height: 295px;top: 5px;left: 85px;"></div>
					   </div>
					   <div class="col-lg-6 mb-lg-0">
						 <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						   <h5 class="text-uppercase fw-bolder text-dark mb-2 text-goldren-300-hover transition-100">wonderful new villa</h5>
					     </a>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-3">$ 5.500.000 <span class="fs-6 fw-lighter"> \ month</span>
						 </h5>
						 <p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
					   </div>
					</div>	
				  </div>
				  <!-- === Testimonials information-2 === -->
				  <div class="carousel-item">
					<div class="row align-items-center justify-content-between">
					   <div class="col-lg-5 mb-lg-0 mb-5">
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_1" style="background-image:url(images/card_6.jpg);"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat opacity-50 shadow-sm item_2" style="background-image:url(images/sider-img3.jpg); left: 225px;"></div>
						 <div class="background-position-center background-size-cover background-repeat-no-repeat position-relative shadow" style="background-image:url(images/card_5.jpg); width: 350px;height: 295px;top: 5px;left: 85px;"></div>
					   </div>
					   <div class="col-lg-6 mb-lg-0">
						 <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						   <h5 class="text-uppercase fw-bolder text-dark mb-2 text-goldren-300-hover transition-100">wonderful new villa</h5>
					     </a>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-3">$ 5.500.000 <span class="fs-6 fw-lighter"> \ month</span>
						 </h5>
						 <p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
					   </div>
					</div>  
				  </div>
				</div>
				<!-- === Testimonials indicators === -->
				<div class="carousel-indicators position-static mt-5 mb-0 testimonials-carousel">
				   <button type="button" data-bs-target="#testimonials" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1" class="text-light"></button>
				   <button type="button" data-bs-target="#testimonials" data-bs-slide-to="1" aria-label="Slide 2" class="text-light"></button>
				</div>
			 </div>
		   </div>
		</section>
		<!-- === list card type 1 === -->
		<section class="bg-sky-50">
		   <div class="container-lg">
		     <div class="row justify-content-center g-4">
			   <h1 class="text-capitalize fw-bolder text-center mb-4">List cities and Areas Type 1</h1> 
			   <div class="col-md-3 col-6">
			      <div class="card h-100 border-0 rounded-0 shadow-sm overflow-hidden">
					<img src="<?php echo $baseurl; ?>images/recent_post2.jpeg" class="img-fluid card-transform-scale-110-hover card-transform-scale-120 transition-400">
					<div class="card-body">
					   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<h6 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">Sidebar on the Right</h6>
					   </a>
					   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
					</div>
				 </div>
			   </div>
			   <div class="col-md-3 col-6">
			      <div class="card h-100 border-0 rounded-0 shadow-sm overflow-hidden">
					<img src="<?php echo $baseurl; ?>images/miami-1-525x350.png" class="img-fluid card-transform-scale-110-hover card-transform-scale-120 transition-400">
					<div class="card-body">
					   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<h6 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">Sidebar on the Right</h6>
					   </a>
					   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
					</div>
				 </div>
			   </div>
			   <div class="col-md-3 col-6">
			      <div class="card h-100 border-0 rounded-0 shadow-sm overflow-hidden">
					<img src="images/recent_post2.jpeg" class="img-fluid card-transform-scale-110-hover card-transform-scale-120 transition-400">
					<div class="card-body">
					   <a href="#" class="text-decoration-none">
						<h6 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">Sidebar on the Right</h6>
					   </a>
					   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
					</div>
				 </div>
			   </div>
			   <div class="col-md-3 col-6">
			      <div class="card h-100 border-0 rounded-0 shadow-sm overflow-hidden">
					<img src="<?php echo $baseurl; ?>images/miami-1-525x350.png" class="img-fluid card-transform-scale-110-hover card-transform-scale-120 transition-400">
					<div class="card-body">
					   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						<h6 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">Sidebar on the Right</h6>
					   </a>
					   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
					</div>
				 </div>
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === List cities and Areas Type 2 === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center g-4">
			   <h1 class="text-capitalize opacity-75 fw-bolder text-center mb-4">List cities and Areas Type 2</h1>
			   <div class="col-md-6">
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column rounded shadow-sm" style="background-image: linear-gradient(#00000024, #0000004f),url(images/miami-1-525x350.png);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					</div>
				  </a>
			   </div>
			   <div class="col-md-6">
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column rounded shadow-sm" style="background-image: linear-gradient(#00000024, #0000004f),url(images/5.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					</div>
				  </a>
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === List Items By ID – Vertical === -->
		<section class="bg-sky-50 pt-3">
		  <div class="container-lg">
		    <div class="row justiy-content-center mt-5 g-4">
			  <h1 class="text-capitalize fw-bolder text-center mb-4">List Items By ID – Vertical</h1>
			  <!-- === featured-1 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
			    <!-- === featured-2 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
				<!-- === featured-3 === -->			   
			    <div class="col-lg-4 col-sm-6">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_6.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <ul class="list-group list-group-horizontal justify-content-center text-center">
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">3</span>
						     <span class="text-body-tertiary"><small>baths</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">5</span>
						     <span class="text-body-tertiary"><small>bedrooms</small></span>
						   </li>
						   <li class="list-group-item line-height-15 border border-top-0 border-bottom-0 border-start-0 rounded-0 py-0 px-4">
						     <span class="d-block fw-semibold text-body-tertiary">250ft<sup>2</sup></span>
						     <span class="text-body-tertiary"><small>size</small></span>
						   </li>
						 </ul>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fa-lg">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			    </div>
			</div>
			<a href="#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase mt-4">more listing</a>
		  </div>
		</section>
		<!-- === List Items By ID – Horizontal === -->
		<section>
		  <div class="container-lg">
		    <div class="row justify-content-center">
			   <div class="col-12">
			     <h1 class="text-capitalize fw-bolder opacity-75 text-center mb-5">List Items By ID – Horizontal</h1>
				 <!-- list 1 -->
				 <div class="card shadow border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/full-width2.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
							<div class="card-img-overlay">
							  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">Featured</span>
							  <p></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
							</h5>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
								   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					  </div>
				 </div>
				 <!-- list 2 -->
				 <div class="card shadow border-0 rounded-0 mb-4">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
							<div class="card-img-overlay">
							  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">Featured</span>
							  <p></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
							</h5>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
								   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					  </div>
				 </div>
				 <a href="<?php echo $baseurl; ?>#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase">more listing</a>
			   </div>
			</div>
		  </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<script>
		var swiper = new Swiper(".ourblog", {
		  spaceBetween: 20,
		  loop: true,
		  breakpoints: {
			576: {
			  slidesPerView: 1,
			  spaceBetween: 20,
			},
			768: {
			  slidesPerView: 2,
			  spaceBetween: 20,
			},
			1024: {
			  slidesPerView: 3,
			  spaceBetween: 30,
			},
		  },
		  navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		  },
		  pagination: {
			el: ".swiper-pagination",
			clickable: true,
		  },
		});
    </script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>