<!doctype html>
<?php include('header.php'); ?>
	<main>
	    <!-- === Recent Articles – Vertical === -->
		<section class="bg-sky-50 pt-3">
		  <div class="container-lg">
		    <nav aria-label="breadcrumb">
			   <ol class="breadcrumb d-flex align-items-center mb-5">
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Home</small></a>
				</li>
				<i class="fa-solid fa-angle-right text-goldren-400 mx-2 fa-xs mt-1"></i>
				<li class="breadcrumb-item">
				  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none"><small>Post Shortcodes</small></a>
				</li>
			   </ol>
			</nav>
		    <div class="row justiy-content-center mt-5 g-4">
			    <h1 class="text-capitalize fw-bolder text-center mb-4">Recent Articles – Vertical</h1>
			    <!-- === recent artical-1 === -->
				<div class="col-lg-4 col-sm-6">
				   <div class="card border-0 custom-shadow">
					 <div class="card overflow-hidden border-0 rounded-0">
						<img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
					 </div>
					 <div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					 </div>
					 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						<a href="#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						<div>
						  <a href="#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
						</div>
					 </div>
				   </div>
				</div>
				<!-- === recent artical-2 === -->
				<div class="col-lg-4 col-sm-6">
				   <div class="card border-0 custom-shadow">
					 <div class="card overflow-hidden border-0 rounded-0">
						<img src="<?php echo $baseurl; ?>images/house-interior-design.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
					 </div>
					 <div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					 </div>
					 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						<a href="#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						<div>
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
						</div>
					 </div>
				   </div>
				</div>
				<!-- === recent artical-2 === -->
				<div class="col-lg-4 col-sm-6">
				   <div class="card border-0 custom-shadow">
					 <div class="card overflow-hidden border-0 rounded-0">
						<img src="<?php echo $baseurl; ?>images/card_3.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
					 </div>
					 <div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					 </div>
					 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						<div>
						  <a href="#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
						</div>
					 </div>
				   </div>
				</div>
				<div>
				  <a href="<?php echo $baseurl; ?>#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase">more articles</a>
				</div>
			</div>
		  </div>
		</section>
		<!-- === Recent Articles – Horizontal === -->
		<section>
		  <div class="container-lg">
		    <div class="row justiy-content-center g-4">
			    <h1 class="text-capitalize fw-bolder text-center opacity-75 mb-4">Recent Articles – Horizontal</h1>
			    <!-- === recent artical Horizontal-1 === -->
				<div class="col-12">
				   <div class="card shadow-sm border-0 rounded-0">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end h-100" style="background-image:url(images/card_4.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				   </div>
				</div>
				<!-- === recent artical Horizontal-2 === -->
				<div class="col-12">
				   <div class="card shadow-sm border-0 rounded-0">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end h-100" style="background-image:url(images/full-width2.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				   </div>
				</div>
				<div>
				  <a href="<?php echo $baseurl; ?>#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase">more articles</a>
				</div>
			</div>
		  </div>
		</section>
		<!-- === Recent Articles Slider === -->
		<section class="bg-sky-50" id="blog">
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-12">
			      <h1 class="text-capitalize fw-bolder text-center mb-4">Recent Articles Slider</h1>
			   </div>
			 </div>
			 <div class="position-relative">
			   <div class="swiper ourblog">
				  <div class="swiper-wrapper">
				    <!-- Recent Articles Slider-1 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
							<img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
							</a>
							<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
							<div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- Recent Articles Slider-2 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
							<img src="<?php echo $baseurl; ?>images/card_3.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
							</a>
							<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
							<div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- Recent Articles Slider-3 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
							<img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
							</a>
							<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
							<div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- Recent Articles Slider-4 === -->
					<div class="swiper-slide">
					  <!-- === featured linked === -->
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
							<img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
							</a>
							<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
							<div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
				  </div>
			   </div>
			   <!-- next,prev btn === -->
			   <button type="button" class="btn swiper-button-next h-2 w-2 bg-goldren-300 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-right"></i>
			   </button>
			   <button type="button" class="btn swiper-button-prev h-2 w-2 bg-goldren-300 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-left"></i>
			   </button>
			   <div class="swiper-pagination"></div>
			 </div>
		   </div>
		</section>
		<!-- === Recent Articles – Vertical === -->
		<section>
		  <div class="container-lg">
		    <div class="row justiy-content-center g-4">
			    <h1 class="text-capitalize fw-bolder text-center opacity-75 mb-4">List Articles By ID – Vertical</h1>
			    <!-- === recent artical-1 === -->
				<div class="col-lg-4 col-sm-6">
				   <div class="card border-0 custom-shadow">
					 <div class="card overflow-hidden border-0 rounded-0">
						<img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
					 </div>
					 <div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					 </div>
					 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						<div>
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
						</div>
					 </div>
				   </div>
				</div>
				<!-- === recent artical-2 === -->
				<div class="col-lg-4 col-sm-6">
				   <div class="card border-0 custom-shadow">
					 <div class="card overflow-hidden border-0 rounded-0">
						<img src="<?php echo $baseurl; ?>images/house-interior-design.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
					 </div>
					 <div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					 </div>
					 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						<div>
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
						</div>
					 </div>
				   </div>
				</div>
				<!-- === recent artical-2 === -->
				<div class="col-lg-4 col-sm-6">
				   <div class="card border-0 custom-shadow">
					 <div class="card overflow-hidden border-0 rounded-0">
						<img src="<?php echo $baseurl; ?>images/card_3.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
					 </div>
					 <div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					 </div>
					 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						<a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						<div>
						  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
						</div>
					 </div>
				   </div>
				</div>
				<div>
				  <a href="<?php echo $baseurl; ?>#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase">more articles</a>
				</div>
			</div>
		  </div>
		</section>
		<!-- === List Articles By ID – Horizontal === -->
		<section class="bg-sky-50">
		  <div class="container-lg">
		    <div class="row justiy-content-center g-4">
			    <h1 class="text-capitalize fw-bolder text-center opacity-75 mb-4">RList Articles By ID – Horizontal</h1>
			    <!-- === recent artical Horizontal-1 === -->
				<div class="col-12">
				   <div class="card shadow-sm border-0 rounded-0">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end h-100" style="background-image:url(images/card_4.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				   </div>
				</div>
				<!-- === recent artical Horizontal-2 === -->
				<div class="col-12">
				   <div class="card shadow-sm border-0 rounded-0">
					  <div class="row g-0">
						<div class="col-lg-4 col-md-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end h-100" style="background-image:url(images/full-width2.jpg)">
							   <p class="py-5 my-5"></p>
							</div>
						  </div>
						</div>
						<div class="col-lg-8 col-md-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5>
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Buying a Home</a>	
							</h5>
							<p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book...<a href="#" class="text-decoration-none text-goldren-400 ms-1">[More]</a></small></p>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>by admin</small>
							 </p>
							 <p class="text-uppercase text-secondary fw-semibold mb-0">
							   <small>may, 28, 2023</small>
							 </p>
					      </div>
						</div>
					  </div>
				   </div>
				</div>
				<div>
				  <a href="<?php echo $baseurl; ?>#" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600 text-uppercase">more articles</a>
				</div>
			</div>
		  </div>
		</section>
		<!-- === Featured Article === -->
		<section>
		  <div class="container-lg">
		    <div class="row justiy-content-center g-4">
			    <h1 class="text-capitalize fw-bolder text-center mb-4">Featured Article</h1>
			    <!-- === Featured Article-1 === -->
				<div class="col-md-6">
				  <div class="card shadow border-0 rounded-0 cursor-pointer h-100">
					<div class="card border-0 rounded-0 overflow-hidden">
					  <img src="<?php echo $baseurl; ?>images/home.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
					  <div class="card-img-overlay">
						 <span class="badge bg-goldren-300 rounded-0 px-3 py-2">May, 2023</span>
					  </div>
					</div>
					<hr class="mt-0 mb-0 bg-goldren-300 pt-1 opacity-100 border-0">
					<div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					</div>
				  </div>
			    </div>
				<!-- === Featured Article-2 === -->
				<div class="col-md-6">
				  <div class="card shadow border-0 rounded-0 cursor-pointer h-100">
					<div class="card border-0 rounded-0 overflow-hidden">
					  <img src="<?php echo $baseurl; ?>images/home.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
					  <div class="card-img-overlay">
						 <span class="badge bg-goldren-300 rounded-0 px-3 py-2">May, 2023</span>
					  </div>
					</div>
					<hr class="mt-0 mb-0 bg-goldren-300 pt-1 opacity-100 border-0">
					<div class="card-body">
						<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						  <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						</a>
						<p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
					</div>
				  </div>
			    </div>
			</div>
		  </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<script>
		var swiper = new Swiper(".ourblog", {
		  spaceBetween: 20,
		  loop: true,
		  breakpoints: {
			576: {
			  slidesPerView: 1,
			  spaceBetween: 20,
			},
			768: {
			  slidesPerView: 2,
			  spaceBetween: 20,
			},
			1024: {
			  slidesPerView: 3,
			  spaceBetween: 30,
			},
		  },
		  navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		  },
		  pagination: {
			el: ".swiper-pagination",
			clickable: true,
		  },
		});
    </script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>