<?php

	include('property-list-half-map.php');

?>