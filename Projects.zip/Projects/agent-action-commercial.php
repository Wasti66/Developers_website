<?php

	include('agent_listingsres-idential.php');

?>