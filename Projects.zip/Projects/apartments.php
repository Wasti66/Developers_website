<?php include('header.php'); ?>
	<main>
		<!-- === form === -->
		<section class="bg-light border-bottom pt-md-2 pb-md-4 pt-3 pb-4">
		  <div class="container-fluid">
		    <form class="row g-3 mt-md-1 mt-0 align-items-center" action="" method="post">
			  <!-- === input field 1 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
				   <option value="">All action</option>
				   <option value="1">One</option>
				   <option value="2">Two</option>
				   <option value="3">Three</option>
				</select>
			  </div>
			  <!-- === input field 2 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
				   <option value="">All action</option>
				   <option value="1">One</option>
				   <option value="2">Two</option>
				   <option value="3">Three</option>
				</select>
			  </div>
			  <!-- === input field 3 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
				   <option value="">All action</option>
				   <option value="1">One</option>
				   <option value="2">Two</option>
				   <option value="3">Three</option>
				</select>
			  </div>
			  <!-- === input field 4 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				 <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
			  </div>
			  <!-- === input field 5 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				 <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
			  </div>
			  <!-- === input field 6 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				 <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
			  </div>
			  <!-- === input field 7 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				 <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
			  </div>
			  <!-- === input field 8 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				 <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
			  </div>
			  <!-- === input field 9 === -->
			  <div class="col-lg-2 col-md-4 col-sm-6">
				 <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
			  </div>
			</form>
		  </div>
		</section>
		<!-- === half map === -->
		<section class="pt-0 pb-0">
		   <div class="container-fluid">
		     <div class="row">
			   <div class="col-md-6 overflow-y-scroll height-400 order-5 order-md-0 bg-sky-50">
			      <h2 class="text-capitalize fw-lighter mt-2 mb-3">Properties listed in Apartments</h2>
				  <!-- === half map card-1 === -->
				  <div class="card custom-shadow border-0 rounded-0 mb-4">
					 <div class="row g-0">
						<div class="col-lg-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/google_map_card.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
						  </div>
						</div>
						<div class="col-lg-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h6 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">wonderful new villa</a>	
							</h6>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="flex-grow-1 ms-2">
							    <a href="#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							    <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					 </div>
				  </div>
				  <!-- === half map card-2 === -->
				  <div class="card custom-shadow border-0 rounded-0 mb-4">
					 <div class="row g-0">
						<div class="col-lg-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_3.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
						  </div>
						</div>
						<div class="col-lg-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h6 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">wonderful new villa</a>	
							</h6>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="flex-grow-1 ms-2">
							    <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							    <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					 </div>
				  </div>
				  <!-- === half map card-3 === -->
				  <div class="card custom-shadow border-0 rounded-0 mb-4">
					 <div class="row g-0">
						<div class="col-lg-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
						  </div>
						</div>
						<div class="col-lg-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h6 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">wonderful new villa</a>	
							</h6>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="flex-grow-1 ms-2">
							    <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
							    <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					 </div>
				  </div>
				  <nav aria-label="Page navigation example">
					<ul class="pagination">
					  <li class="page-item me-1">
						<a class="page-link rounded-0 text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#" aria-label="Previous">
						  <i class="fa-solid fa-angle-left"></i>
						</a>
					  </li>
					  <li class="page-item me-1">
					    <a class="page-link bg-goldren-300 text-light shadow-none" href="<?php echo $baseurl; ?>#">1</a>
					  </li>
					  <li class="page-item me-1">
					    <a class="page-link text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#">2</a>
					  </li>
					  <li class="page-item me-1">
					    <a class="page-link text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#">3</a>
					  </li>
					  <li class="page-item me-1">
						<a class="page-link rounded-0 text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#" aria-label="Next">
						  <i class="fa-solid fa-angle-right"></i>
						</a>
					  </li>
					</ul>
				 </nav>
			   </div>
			   <!-- === map === -->
			   <div class="col-md-6 p-md-0">
			      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.142086501079!2d90.42166437445748!3d23.81354598635085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c62fb95f16c1%3A0xb333248370356dee!2sJamuna%20Future%20Park!5e0!3m2!1sen!2sbd!4v1686242326516!5m2!1sen!2sbd" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			   </div>
			 </div>
		   </div>
		</section>
	</main>
	<footer></footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
  </body>
</html>