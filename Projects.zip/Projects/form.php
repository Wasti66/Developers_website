		  <nav class="navbar navbar-expand-md py-0">
		    <button class="navbar-toggler w-100 border-0 shadow-none text-start text-uppercase fw-bold text-light rounded-0 fs-6 py-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" id="form-banar-btn">
			  <i class="fa-solid fa-magnifying-glass"></i>
			  <span class="ms-2">Advanced Search</span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
			  <div class="container-lg">
				<form class="row mt-md-0 mt-5" action="" method="post">
				   <div class="col-lg-10 col-md-9 mb-md-0 mb-3">
					  <div class="row g-3">
						<div class="col-lg-3 col-md-4">
							<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							   <option value="">All action</option>
							   <option value="1">One</option>
							   <option value="2">Two</option>
							   <option value="3">Three</option>
							</select>
						</div>
						<div class="col-lg-3 col-md-4">
							<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							   <option value="">All action</option>
							   <option value="1">One</option>
							   <option value="2">Two</option>
							   <option value="3">Three</option>
							</select>
						</div>
						<div class="col-lg-3 col-md-4">
							<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							   <option value="">All action</option>
							   <option value="1">One</option>
							   <option value="2">Two</option>
							   <option value="3">Three</option>
							</select>
						</div>
						<div class="col-lg-3 col-md-4">
							<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							   <option value="">All action</option>
							   <option value="1">One</option>
							   <option value="2">Two</option>
							   <option value="3">Three</option>
							</select>
						</div>
						<div class="col-lg-3 col-md-4">
							<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
						</div>
						<div class="col-lg-3 col-md-4">
							<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Bedrooms No.">
						</div>
						<div class="col-lg-3 col-md-4">
							<input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
						</div>
						<div class="col-lg-3 col-md-4">
						   <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Max. Price">
						</div>
					  </div>
				   </div>
				   <div class="col-lg-2 col-md-3">
					 <input type="submit" class="form-control rounded-0 fw-bold text-white shadow-none height-6_1 bg-goldren-300 border-0 bg-hover-dark-600" type="text" value="SEARCH">
				   </div>
				</form>
			  </div>
			</div>
		  </nav>