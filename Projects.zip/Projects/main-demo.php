<?php
	include('baseurl.php');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
	<!-- Fontawesome -->
	<link rel="stylesheet"type="text/css" href="<?php echo $baseurl; ?>css/all.css">
	<!-- === Bootstrap === -->
    <link href="<?php echo $baseurl; ?>css/bootstrap.min.css" rel="stylesheet">
	<!-- === Style css === -->
    <link href="<?php echo $baseurl; ?>css/style.css" rel="stylesheet">
	<!-- === Global css === -->
    <link href="<?php echo $baseurl; ?>css/global.css" rel="stylesheet">
	<!-- swiper js css -->
	<link rel="stylesheet" href="<?php echo $baseurl; ?>css/swiper-bundle.min.css"/>
	<style>
	  .form-control-focus:focus{
		  border-color: #20c063;
		  -webkit-box-shadow: inset 0 1px 1px rgb(0 0 0 / 8%), 0 0 8px #d0ae5e!important;
	  }
	  .bg-green-400{
		  background-color:#20c063;
	  }
	  .text-green-400{
		 color:#20c063;
	  }
	  .swiper-pagination .swiper-pagination-bullet-active{
			background-color:#20c063!important;
	  }
	</style>
  </head>
  <body>
    <header class="border-bottom transition-1000" id="affix-nav">
		<!-- === nav bar === -->
		<nav class="navbar navbar-expand-lg navbar-phone custom-nav">
		  <div class="container-fluid">
			<!-- === developers company logo === -->
			<a class="navbar-brand order-5 order-sm-0" href="index.php">
			  <img src="<?php echo $baseurl; ?>images/logo3.png" class="img-fluid d-none d-sm-block">
			  <!-- === mobile device logo === -->
			  <img src="<?php echo $baseurl; ?>images/logo_mobile.png" class="d-sm-none d-block" style="height: 55px;">
			</a>
			<button class="navbar-toggler shadow-none border-0 custom-toggle" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDark">
			  <i class="fa-solid fa-bars fa-xl"></i>
			</button>
			<div class="offcanvas offcanvas-start text-bg-dark" tabindex="-1" id="offcanvasDark" aria-labelledby="offcanvasDarkLabel">
			  <!-- ==== offcanvas header === -->
			  <div class="offcanvas-header justify-content-end">
				<button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			  </div>
			  <!-- ==== offcanvas body === -->
			  <div class="offcanvas-body">
				<ul class="navbar-nav m-auto">
				  <!-- === Demos === -->
					<li class="nav-item hover-dropdown">
					  <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<small>Demos</small>
						<i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
					  </a>
					  <ul class="dropdown-menu py-0 mt-0 rounded-0 left-auto dropdown-menu-hover">
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>#">
							<small>Berlin Demo</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>#">
							<small>Miami</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>#">
							<small>Milano</small>
						  </a>
						</li>
					  </ul>
					</li>
				   <!-- ==== home === -->
				   <li class="nav-item">
					  <a class="nav-link active text-uppercase fw-semibold mx-2" href="<?php echo $baseurl; ?>index.php">
						<small>Home</small>
					  </a>
				   </li>
				   <!-- === Properties === -->
				   <li class="nav-item hover-dropdown hover-dropdown-100">
					 <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					   <small>Properties</small>
					   <i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
					 </a>
					 <div class="dropdown-menu end-0 border-0 p-0 mt-0 bg-transparent dropdown-menu-hover">
					   <div class="container bg-white border mx-auto w-75 p-3 border rounded-lg-0 rounded responsve-dropdown">
						 <div class="row gy-lg-0 gy-3">
						   <!-- === Property Page Slider Design === -->
						   <div class="col-lg-3 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>property pasge slider design</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property with subunits
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Images Slider Horizontal
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property with subunits
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Content in Tabs
								</small>
							  </a>
						   </div>
						   <!-- === Property page header type === -->
						   <div class="col-lg-3 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Property page header type</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property – Map Header
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property – Full Width Slider
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property with subunits
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property – Slider Header
								</small>
							  </a>
						   </div>
						   <!-- === Properties Lists === -->
						   <div class="col-lg-3 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Properties Lists</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Half Map List
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   List No Sidebar
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Sidebar Right List
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Properties List – List display
								</small>
							  </a>
						   </div>
						   <!-- === Properties by Type === -->
						   <div class="col-lg-3 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Properties by Type</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   City
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								    Area
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   State
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Category
								</small>
							  </a>
						   </div>
						 </div>
					   </div>
					 </div>	
				   </li>	
				   <!-- === Agents === -->
				   <li class="nav-item hover-dropdown hover-dropdown-100">
					 <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					   <small>Agents</small>
					   <i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
					 </a>
					 <div class="dropdown-menu end-0 border-0 p-0 mt-0 bg-transparent dropdown-menu-hover">
					   <div class="container bg-white border mx-auto w-75 responsve-dropdown">
						 <div class="row gy-lg-0 gy-3">
						   <!-- === Agent Page Header Type === -->
						   <div class="col-lg-4 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Agent Page</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Header Google Maps
								 </small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Header Properties Slider
								 </small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Header Rev Slider
								 </small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   No Media Header
								 </small>
							  </a>
						   </div>
						   <!-- === Agent Lists === -->
						   <div class="col-lg-4 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Properties Lists</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   List with Sidebar Left
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   List with Sidebar Right
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   No Sidebar List
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Agents Shortcode
								</small>
							  </a>
						   </div>
						   <!-- === Agents by type === -->
						   <div class="col-lg-4 col-sm-6 background-size-cover background-repeat-no-repeat background-position-right" style="background-image:url(images/a.png);">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Agents by type</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   City
								 </small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Area
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Category
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover fw-semibold" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Type
								</small>
							  </a>
						   </div>
						 </div>
					   </div>
					 </div>	
				   </li>
				   <!-- === Search Types === -->
				   <li class="nav-item hover-dropdown">
					  <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<small>Search Types</small>
						<i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
					  </a>
					  <ul class="dropdown-menu py-0 mt-0 rounded-0 left-auto dropdown-menu-hover">
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>full-width-post.php">
							<small>full width post</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>sidebar-on-the-right.php">
							<small>Sidebar Right Post</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>sidebar-on-the-left.php">
							<small>Sidebar Left Post</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>blog.php">
							<small>Blog List – No Sidebar</small>
						  </a>
						</li>
					  </ul>
				   </li>
				   <!-- === Blog === -->
				   <li class="nav-item hover-dropdown hover-dropdown-100">
					 <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					   <small>Blog</small>
					   <i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
					 </a>
					 <div class="dropdown-menu end-0 border-0 p-0 mt-0 bg-transparent dropdown-menu-hover">
					   <div class="container bg-white border mx-auto w-75 p-3 border rounded-lg-0 rounded responsve-dropdown">
						 <div class="row gy-lg-0 gy-3 align-items-center">
						   <!-- === Property Page Slider Design === -->
						   <div class="col-lg-3 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>property pasge slider design</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property with subunits
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Images Slider Horizontal
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property with subunits
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Content in Tabs
								</small>
							  </a>
						   </div>
						   <!-- === Property page header type === -->
						   <div class="col-lg-3 col-sm-6">
							  <p class="text-uppercase fw-bolder opacity-75 mb-2">
								<small>Property page header type</small>
							  </p>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								 <small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property – Map Header
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property – Full Width Slider
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property with subunits
								</small>
							  </a>
							  <a class="ps-0 d-block pb-sm-2 pb-1 text-decoration-none text-black-50 text-goldren-300-hover" href="<?php echo $baseurl; ?>#">
								<small>
								   <i class="fa-solid fa-caret-right me-1"></i>
								   Property – Slider Header
								</small>
							  </a>
						   </div>
						   <!-- === Properties Lists === -->
						   <div class="col-lg-3 col-sm-6">
						      <a href="#" class="text-decoration-none">
							    <img src="images/interior.jpg" style="height:120px;">
								<p class="mb-0 text-dark">San Francisco Real Estate</p>
							  </a>
						   </div>
						   <!-- === Properties by Type === -->
						   <div class="col-lg-3 col-sm-6">
						      <a href="#" class="text-decoration-none">
							    <img src="images/interior.jpg" style="height:120px;">
								<p class="mb-0 text-dark">San Francisco Real Estate</p>
							  </a>
						   </div>
						 </div>
					   </div>
					 </div>	
				   </li>
				   <!-- === Features === -->
				   <li class="nav-item hover-dropdown">
					  <a class="nav-link text-uppercase fw-semibold mx-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<small>Features</small>
						<i class="fa-solid fa-chevron-down fa-xs ms-1"></i>
					  </a>
					  <ul class="dropdown-menu py-0 mt-0 rounded-0 left-auto dropdown-menu-hover">
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>#">
							<small>contact us</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>#">
							<small>MLS Import Compatible</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
						<li>
						  <a class="dropdown-item text-black-50 text-goldren-300-hover fw-semibold py-2 text-capitalize" href="<?php echo $baseurl; ?>post-shortcodes.php">
							<small>post shortcodes</small>
						  </a>
						</li>
						<li><hr class="dropdown-divider m-0"></li>
					  </ul>
				   </li>
				</ul>
				<div>
				  <a href="#" class="btn text-uppercase fw-semibold text-decoration-none text-dark">Submit Property</a>
				</div>
			  </div>
			</div>
		  </div>
		</nav>
	</header>
	<main>
		<!-- === google map map === -->
		<section class="pt-0 pb-0">
		    <?php include('map.php'); ?>
		</section>
		<!-- === === -->
		<section class="bg-light pt-3 pb-3">
		  <div class="container">
		    <form class="row gx-2" action="" method="post">
			  <div class="col-md-8 mb-md-0 mb-3">
			    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
			  </div>
			  <div class="col-md-2 mb-md-0 mb-3">
			    <select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
				   <option value="">All action</option>
				   <option value="1">One</option>
				   <option value="2">Two</option>
				   <option value="3">Three</option>
				</select>
			  </div>
			  <div class="col-md-2 d-flex">
				<a class="btn bg-green-400 text-white rounded-0 me-2 bg-hover-dark-600" data-bs-toggle="collapse" href="#form" role="button" aria-expanded="false" aria-controls="collapseExample">
					<i class="fa-solid fa-list"></i>
				</a>
			    <button type="submit" class="form-control text-uppercase bg-green-400 fw-semibold text-white rounded-0 shadow-none bg-hover-dark-600">search</button>
			  </div>
			</form>
			<!-- === === -->
			<div class="collapse" id="form">
			   <form class="row mt-md-5 mb-4 g-3">
			      <!-- === 1 === -->
			      <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 2 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 3 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 4 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 5 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 6 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 7 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 8 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
				  <!-- === 9 === -->
				  <div class="col-md-4 col-sm-6">
					<select class="form-select form-select-lg rounded-0 fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/green.svg)">
					   <option value="">All action</option>
					   <option value="1">One</option>
					   <option value="2">Two</option>
					   <option value="3">Three</option>
					</select>
				  </div>
			   </form>
			</div>
		  </div>
		</section>
		<!-- === all featured === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-lg-8">
				  <h1 class="text-capitalize fw-semibold display-4 opacity-75">New Houses <span class="fw-bold text-green-400">for sale</span></h1>
				  <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories.</p>
			   </div>
			 </div>
		     <div class="row justify-content-center g-4">
				
			   <!-- === featured-1 === -->			   
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-green-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-2 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_2.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-green-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-3 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_3.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class="mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-green-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === our blog === -->
		<section class="bg-light" id="blog">
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-lg-8">
				  <h1 class="text-capitalize fw-semibold display-4 opacity-75">Apartments ready <span class="fw-bold text-green-400">for rent</span></h1>
				  <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories.</p>
			   </div>
			 </div>
			 <div class="position-relative">
			   <div class="swiper ourblog">
				  <div class="swiper-wrapper">
				    <!-- our blog-1 === -->
					<div class="swiper-slide">
					  <div class="card border-0 rounded-0 custom-shadow">
					     <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- our blog-2 === -->
					<div class="swiper-slide">
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- our blog-3 === -->
					<div class="swiper-slide">
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- our blog-4 === -->
					<div class="swiper-slide">
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
				  </div>
			   </div>
			   <!-- next,prev btn === -->
			   <button type="button" class="swiper-button-next h-2 w-2 bg-green-400 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-right"></i>
			   </button>
			   <button type="button" class="swiper-button-prev h-2 w-2 bg-green-400 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-left"></i>
			   </button>
			   <div class="swiper-pagination"></div>
			 </div>
		   </div>
		</section>
		<!-- === Most Popular Neighborhoods === -->
		<section>
			<div class="container-lg">
			   <div class="row justify-content-center text-center mb-5">
				  <div class="col-lg-8">
					<h1 class="text-capitalize fw-semibold display-4 opacity-75">Browse Listings in <span class="fw-bold text-green-400">these areas</span></h1>
					<p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories.</p>
				  </div>
			   </div>
			   <div class="row mb-3 g-3">
				  <div class="col-lg-8 col-sm-7 mb-md-0 mb-3">
				    <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/1.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-green-400 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-lg-4 col-sm-5">
				    <a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/2.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-green-400 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				</div>
				<div class="row g-3">
				  <div class="col-md-4 mb-md-0 mb-3">
				    <a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/3.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-green-400 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
					<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/4.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-green-400 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
					<a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/5.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-green-400 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				</div>
			</div>
		</section>
		<!-- === === -->
		<section class="background-size-cover background-repeat-no-repeat background-position-center background-attachment-fixed" style="background-image:url(images/new_background3.jpg);">
		   <div class="container">
		     <div class="row justify-content-center text-center pt-5 pb-5">
			    <div class="col-lg-10">
				  <img src="images/logo_white_big.png" class="mb-4">
				  <h1 class="text-light">Improve your real estate website with WPEstate!</h1>
			    </div>
			 </div>
		   </div>
		</section>
		<!-- === Agent List – Sidebar Right card === -->
		<section class="bg-light">
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-lg-8">
				  <h1 class="text-capitalize fw-semibold display-4 opacity-75">our <span class="fw-bold text-green-400">agents </span></h1>
				  <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories.</p>
			   </div>
			 </div>
			 <div class="row g-4">
			   <!-- ==== card-1 ==== -->
			   <div class="col-lg-4">
				  <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
					<div class="card border-0 rounded-0 overflow-hidden">
					  <img src="images/member_1.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
					  <div class="card-img-overlay d-flex align-items-end p-0">
						 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
						   <p class="mb-0"><small>real estate broker</small></p>
						 </div>
					  </div>
					</div>
					<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
					   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
						 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
					   </a>
					</div>
					<div class="card-body pt-0">
					   <h5 class="text-uppercase fw-bolder mb-2">
						 <a href="#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
					   </h5>
					   <ul class="list-group">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					   </ul>
					</div>
					<!-- === === -->
					<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
						<ul class="list-group list-group-horizontal">
						  <!-- === facebook === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
						  </a> 
						  <!-- === twitter === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
						  </a>
						  <!-- === in === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
						  </a>
						  <!-- === pinterest === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
						  </a>
						</ul>
						<span class="badge bg-green-400 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
					</div>
				  </div>
			   </div>
			   <!-- ==== card-2 ==== -->
			   <div class="col-lg-4">
				  <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
					<div class="card border-0 rounded-0 overflow-hidden">
					  <img src="images/person3-500x350.jpg" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
					  <div class="card-img-overlay d-flex align-items-end p-0">
						 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
						   <p class="mb-0"><small>real estate broker</small></p>
						 </div>
					  </div>
					</div>
					<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
					   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
						 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
					   </a>
					</div>
					<div class="card-body pt-0">
					   <h5 class="text-uppercase fw-bolder mb-2">
						 <a href="#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
					   </h5>
					   <ul class="list-group">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					   </ul>
					</div>
					<!-- === === -->
					<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
						<ul class="list-group list-group-horizontal">
						  <!-- === facebook === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
						  </a> 
						  <!-- === twitter === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
						  </a>
						  <!-- === in === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
						  </a>
						  <!-- === pinterest === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
						  </a>
						</ul>
						<span class="badge bg-green-400 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
					</div>
				  </div>
			   </div>
			   <!-- ==== card-3 ==== -->
			   <div class="col-lg-4">
				  <div class="card shadow-sm border-0 rounded-0 cursor-pointer">
					<div class="card border-0 rounded-0 overflow-hidden">
					  <img src="images/team_member_3.png" class="card-transform-scale-110-hover card-transform-scale-120 transition-400">
					  <div class="card-img-overlay d-flex align-items-end p-0">
						 <div class="d-flex bg-danger text-light align-items-center px-1 position-relative">
						   <p class="mb-0"><small>real estate broker</small></p>
						 </div>
					  </div>
					</div>
					<div class="card-body ms-auto z-1 pb-0" style="margin-top: -2.5rem;">
					   <a href="tel:%28305%29+555-4555" class="h-3 w-3 bg-white rounded-circle shadow d-flex text-decoration-none">
						 <i class="fa-solid fa-phone m-auto text-body-tertiary fa-lg"></i>
					   </a>
					</div>
					<div class="card-body pt-0">
					   <h5 class="text-uppercase fw-bolder mb-2">
						 <a href="#" class="nav-link text-goldren-300-hover transition-400">Daniel Taylor</a>
					   </h5>
					   <ul class="list-group">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					   </ul>
					</div>
					<!-- === === -->
					<div class="card-footer border-0 rounded-0 bg-white d-flex justify-content-between pb-3">
						<ul class="list-group list-group-horizontal">
						  <!-- === facebook === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-facebook-f fs-6 text-primary"></i>
						  </a> 
						  <!-- === twitter === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-twitter fs-6 text-info mx-2"></i>
						  </a>
						  <!-- === in === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-linkedin-in fs-6 text-primary"></i>
						  </a>
						  <!-- === pinterest === -->
						  <a href="#" class="text-decoration-none me-2">
							<i class="fa-brands fa-pinterest fs-6 text-danger mx-2"></i>
						  </a>
						</ul>
						<span class="badge bg-green-400 text-light fw-semibold rounded-0 px-3 py-1">my listings</span>
					</div>
				  </div>
			   </div>
			 </div>
		   </div>
		</section>
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-lg-8">
				  <h1 class="text-capitalize fw-semibold display-4 opacity-75">Featured  <span class="fw-bold text-green-400">properties</span></h1>
				  <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories.</p>
			   </div>
			 </div>
			 <div class="row g-4 mb-5">
			   <div class="col-md-6">
			     <h5 class="text-capitalize fw-semibold mb-4">Park Avenue Apartment  <span class="fw-bold text-green-400">the new style</span></h5>
				 <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using.</p>
				 <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories. </p>
				 <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories. </p>
			   </div>
			   <div class="col-lg-6">
				   <div class="card border-0 rounded-0 h-100 bg-transparent">
					  <div class="row g-0 align-items-start">
					    <div class="col-lg-6 col-5">
						  <div class="card overflow-hidden border-0 rounded-0 shadow">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start" style="background-image:url(images/card_3.jpg);min-height: 390px;"></div>
							<div class="card-img-overlay">
							   <span class="badge text-bg-primary text-uppercase rounded-0 px-3 py-2">Featured</span>
							</div>
						  </div>
						</div>
						<div class="col-lg-6 col-7 bg-opacity-75 bg-danger position-relative" style="height:88%; top: 5%;">
						  <div class="card-body mt-sm-5 mt-2">
							<!-- === team member name === -->
							<h5>
							  <a href="#" class="text-light text-decoration-none text-uppercase text-goldren-300-hover">Villa to be refurnished</a>	
							</h5>
							<p class="text-light"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</small></p>
							<h5 class="fw-semibold text-light">$ 5.349.000 \ <span class="text-goldren-400">sq.f</span></h5>
							<div class="text-end">
							  <i class="fa-regular fa-star display-1 text-light opacity-25"></i>
							</div>
						  </div>
						</div>
					  </div>
				   </div>
				</div>
			 </div>
			 <div class="row g-4">
			   <div class="col-lg-6">
				   <div class="card border-0 rounded-0 h-100 bg-transparent">
					  <div class="row g-0 align-items-start">
					    <div class="col-lg-6 col-5">
						  <div class="card overflow-hidden border-0 rounded-0 shadow">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start" style="background-image:url(images/card_3.jpg);min-height: 390px;"></div>
							<div class="card-img-overlay">
							   <span class="badge text-bg-primary text-uppercase rounded-0 px-3 py-2">Featured</span>
							</div>
						  </div>
						</div>
						<div class="col-lg-6 col-7 bg-opacity-75 bg-danger position-relative" style="height:88%; top: 5%;">
						  <div class="card-body mt-sm-5 mt-2">
							<!-- === team member name === -->
							<h5>
							  <a href="#" class="text-light text-decoration-none text-uppercase text-goldren-300-hover">Villa to be refurnished</a>	
							</h5>
							<p class="text-light"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</small></p>
							<h5 class="fw-semibold text-light">$ 5.349.000 \ <span class="text-goldren-400">sq.f</span></h5>
							<div class="text-end">
							  <i class="fa-regular fa-star display-1 text-light opacity-25"></i>
							</div>
						  </div>
						</div>
					  </div>
				   </div>
			   </div>
			   <div class="col-md-6">
			     <h5 class="text-capitalize fw-semibold mb-4">Park Avenue Apartment  <span class="fw-bold text-green-400">the new style</span></h5>
				 <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using.</p>
				 <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories. </p>
				 <p class="text-secondary">hese are the latest properties in the Sales category. You can create the list using the “latest listing shortcode” and show items by specific categories. </p>
			   </div>
			 </div>
		   </div>
		</section>
		<section class="bg-sky-50">
		  <div class="container-lg">
		    <div class="row justify-content-center text-center g-4">
			    <h1 class="text-capitalize fw-semibold display-4 opacity-75">Client  <span class="fw-bold text-green-400">testimonials</span></h1>
				<div class="col-lg-10 col-md-11">
				  <a href="#" class="fs-5 text-decoration-none text-dark mb-0 fw-semibold">Susan Anderson</a>
				  <p class="text-body-tertiary">Happy buyer</p>
				  <img src="images/agent1.png" class="rounded-circle mb-3" style="height:60px;">
				  <p class="text-secondary"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s.</small></p>
				</div>
			</div>
		  </div>
		</section>
	</main>
	<!-- footer start === -->
	<footer>
	   <section class="bg-dark">
	      <div class="container">
		    <div class="row gy-4">
			  <div class="col-lg-3 col-sm-6">
			    <h6 class="text-uppercase fw-bolder text-light mb-3">about us</h6>
				<p class="text-secondary mb-0 fw-semibold"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</small></p>
			  </div>
			  <div class="col-lg-3 col-sm-6">
			    <h6 class="text-uppercase fw-bolder text-light mb-3">contact</h6>
				<p class="text-secondary mb-0 fw-semibold mb-2"><small>37500 Bangladesh St SE SaleM, Corner with Sunny jojn, 03755 Commercial OR 9790302.</small></p>
				<p class="text-secondary text-capitalize fw-bolder mb-1">
				   <small>phone :<span class="ms-2 fw-normal">324 234 234</span></small>
				</p>
				<p class="text-secondary text-capitalize fw-bolder mb-1">
				   <small>email :<span class="ms-2 fw-normal">miami@wpestate.org</span></small>
				</p>
				<p class="text-secondary text-capitalize fw-bolder mb-1">
				   <small>skype :<span class="ms-2 fw-normal">wpestate</span></small>
				</p>
				<ul class="list-group list-group-horizontal mt-4">
				  <!-- facebook -->
				  <a href="#" class="text-decoration-none text-secondary opacity-75 me-3">
					<i class="fa-brands fa-facebook-f"></i>
				  </a>
				  <!-- twitter -->
				  <a href="#" class="text-decoration-none text-secondary opacity-75 me-3">
					<i class="fa-brands fa-twitter"></i>
				  </a>
				  <!-- linkedin -->
				  <a href="#" class="text-decoration-none text-secondary opacity-75 me-3">
					<i class="fa-brands fa-linkedin-in"></i>
				  </a>
				  <!-- pinterest -->
				  <a href="#" class="text-decoration-none text-secondary opacity-75 me-3">
					<i class="fa-brands fa-pinterest-p"></i>
				  </a>
				  <!-- instagram -->
				  <a href="#" class="text-decoration-none text-secondary opacity-75 me-3">
					<i class="fa-brands fa-instagram"></i>
				  </a>
				</ul>
			  </div>
			  <div class="col-lg-3 col-sm-6">
			    <h6 class="text-uppercase fw-bolder text-light mb-3">RECENT ARTICLES</h6>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 Why Live in San Francisco
				   </small>
				</a>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 San Francisco Real Estate
				   </small>
				</a>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 Buying a Home
				   </small>
				</a>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 Selling Your Home
				   </small>
				</a>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 Sidebar on the Left
				   </small>
				</a>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 Sidebar on the right
				   </small>
				</a>
				<a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
				   <small>
				     <i class="fa-solid fa-chevron-right me-1 text-green-400"></i>
					 Full Width Post
				   </small>
				</a>
			  </div>
			  <div class="col-lg-3 col-sm-6">
			    <h6 class="text-uppercase fw-bolder text-light mb-3">LATEST LISTINGS</h6>
				<div class="d-md-flex mb-3">
					<div class="flex-shrink-0">
					   <img src="images/full-widthsm3.jpg" style="height: 60px;">
					</div>
					<div class="flex-grow-1 ms-2">
					  <a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
					   <small>
						 2 Bedroom Apartment
					   </small>
					</a>
					<small class="text-green-400">$ 150 / month</small>
					</div>
				</div>
				<div class="d-md-flex mb-3">
					<div class="flex-shrink-0">
					   <img src="images/full-widthsm3.jpg" style="height: 60px;">
					</div>
					<div class="flex-grow-1 ms-2">
					  <a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
					   <small>
						 2 Bedroom Apartment
					   </small>
					</a>
					<small class="text-green-400">$ 150 / month</small>
					</div>
				</div>
				<div class="d-md-flex mb-3">
					<div class="flex-shrink-0">
					   <img src="images/full-widthsm3.jpg" style="height: 60px;">
					</div>
					<div class="flex-grow-1 ms-2">
					  <a href="#" class="text-decoration-none text-secondary text-goldren-300-hover fw-semibold nav-link">
					   <small>
						 2 Bedroom Apartment
					   </small>
					</a>
					<small class="text-green-400">$ 150 / month</small>
					</div>
				</div>
			  </div>
			</div>
		  </div>
	   </section>
	   <hr class="m-0">
	   <!-- === === -->
	   <section class="pt-3 pb-3 bg-black">
	      <div class="container">
		    <p class="mb-0 text-light">&copy;2023 all right reseved by Wazihatulla Wasti</p>
		  </div>
	   </section>
	</footer>
	<!-- Bootstrap js -->
    <script src="js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="js/swiper-bundle.min.js"></script>
	<script>
		window.onscroll = function(){
			var scroll = window.scrollY;
			if(scroll > 200){
				document.querySelector('#affix-nav').classList.add('sticky-top','shadow-sm','bg-white');
			}else{
				document.querySelector('#affix-nav').classList.remove('sticky-top','shadow-sm','bg-white');
			}
		}
	</script>
	<script>
		var swiper = new Swiper(".ourblog", {
		  spaceBetween: 20,
		  loop: true,
		  breakpoints: {
			576: {
			  slidesPerView: 1,
			  spaceBetween: 20,
			},
			768: {
			  slidesPerView: 2,
			  spaceBetween: 20,
			},
			1024: {
			  slidesPerView: 3,
			  spaceBetween: 30,
			},
		  },
		  navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		  },
		  pagination: {
			el: ".swiper-pagination",
			clickable: true,
		  },
		});
    </script>
  </body>
</html>