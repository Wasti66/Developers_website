	<ul class="list-group fixed-top top-50 right-auto">
	  <li class="list-group-item bg-transparent border-0 p-0">
		<a href="<?php echo $baseurl; ?>#" class="h-2 w-2 d-flex bg-primary text-decoration-none">
		  <i class="fa-brands fa-facebook-f m-auto text-white"></i>
		</a>
	  </li>
	  <li class="list-group-item bg-transparent border-0 p-0">
		<a href="<?php echo $baseurl; ?>#" class="h-2 w-2 d-flex bg-info text-decoration-none">
		  <i class="fa-brands fa-twitter m-auto text-white"></i>
		</a>
	  </li>
	  <li class="list-group-item bg-transparent border-0 p-0">
		<a href="<?php echo $baseurl; ?>#" class="h-2 w-2 d-flex bg-danger text-decoration-none opacity-75">
		  <i class="fa-brands fa-google-plus-g m-auto text-white"></i>
		</a>
	  </li>
	  <li class="list-group-item bg-transparent border-0 p-0">
		<a href="<?php echo $baseurl; ?>#" class="h-2 w-2 d-flex bg-danger text-decoration-none">
		  <i class="fa-brands fa-pinterest-p  m-auto text-white"></i>
		</a>
	  </li>
	</ul>