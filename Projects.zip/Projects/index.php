<?php include('header.php'); ?>
	<main>
		<!-- === home banar(video) === -->
		<section class="position-relative overflow-hidden vh-100 d-flex align-items-center">
		  <div class="position-absolute w-100 h-100 top-0 start-0 z-1 video-overlay"></div>
		  <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop" class="position-absolute top-50 w-auto h-auto translate-middle-y z-0 min-vw-100 min-vh-100">
			<source src="<?php echo $baseurl; ?>images/video.mp4" type="video/mp4">
		  </video>
		  <div class="container position-relative z-1">
			<div class="row justify-content-center">
	          <div class="col-md-10 text-center">
				<h4 class="text-light display-6 font-playfair-Display fst-italic">welcome to the new</h4>
			    <h1 class="text-light fw-bold display-1 mb-4">WP ESTATE</h1>
				<h3 class="text-light fw-normal">Your best choice to create a professional real estate website.</h3>
			  </div>
			</div>	
		  </div>	
		</section>
		<!-- === banar form === -->
		<section class="bg-light border-bottom pt-md-3 pb-md-4 pt-0 pb-2">
		  <?php include('form.php'); ?>
		</section>
		<!-- === all featured === -->
		<section>
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-10">
			      <h3 class="text-goldren-400 font-playfair-Display fst-italic mb-3">Discover Miami</h3>
				  <h1 class="text-capitalize fw-bolder display-4 opacity-75">the latest listings</h1>
			   </div>
			 </div>
		     <div class="row justify-content-center g-4">
				
			   <!-- === featured-1 === -->			   
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_1.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-2 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_2.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-3 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_3.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class="mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-4 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-5 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_5.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			   <!-- === featured-6 === -->	
			   <div class="col-lg-4 col-sm-6 col-11">
			      <!-- === featured linked === -->
			      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
				    <div class="card custom-shadow rounded-0 border-0 h-100">
					  <div class="card border-0 rounded-0 overflow-hidden">
					    <!-- === featured images 1 === -->
						<img src="<?php echo $baseurl; ?>images/card_6.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
						<!-- === card-img-overlay-1 === -->
						<div class="card-img-overlay">
						   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						</div>
						<!-- === card-img-overlay-2 === -->
						<div class="card-img-overlay d-flex justify-content-end align-items-end">
						   <span class="fs-6 text-light">compare</span>
						</div>
					  </div>
					  <!-- === featured information content === -->
					  <div class="card-body">
						 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
						 <div class=" mb-3">
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						 </div>
						 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
						 <div class="d-flex justify-content-center text-center align-items-center">
						    <div class="px-3 line-height-15 border border-top-0 border-bottom-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
							   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
						    </div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
							   <p class="mb-0 fs-6 text-secondary">baths</p>
							</div>
							<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
							   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
							   <p class="mb-0 fs-6 text-secondary">size</p>
							</div>
						 </div>
					  </div>
					  <!-- === === -->
					  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
						 <div class="d-flex align-items-center">
							<div class="flex-shrink-0">
							   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
							</div>
							<div class="flex-grow-1 ms-2">
							   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
							   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
							</div>
						 </div>
						 <div>
							<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
							  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
							</a>
						 </div>
					  </div>
					</div>
				  </a>
			   </div>
			   
			 </div>
		   </div>
		</section>
		<!-- === Most Popular Neighborhoods === -->
		<section class="bg-light">
			<div class="container-lg">
			   <div class="row justify-content-center text-center mb-5">
				  <div class="col-md-10">
					<h3 class="text-goldren-400 font-playfair-Display fst-italic mb-3">Most Popular Neighborhoods</h3>
					<h1 class="text-capitalize fw-bolder display-4 opacity-75">where do you want to live ?</h1>
				  </div>
			   </div>
			   <div class="row mb-3 g-3">
				  <div class="col-lg-8 col-sm-7 mb-md-0 mb-3">
				    <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/1.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-lg-4 col-sm-5">
				    <a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/2.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
			   </div>
			   <div class="row g-3">
				  <div class="col-md-4 mb-md-0 mb-3">
				    <a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/3.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
					<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/4.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
					<a href="#" class="text-decoration-none">
					  <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-center justify-content-center text-center height-400 flex-column" style="background-image: linear-gradient(#00000024, #0000004f),url(images/5.jpg);">
						<h5 class="text-uppercase text-light mb-2 fw-bold">south beatch</h5>
						<p class="fs-6 text-light mb-2">The beaches are always warm</p>
						<span class="badge bg-goldren-300 rounded-0 p-2">4 LISTINGS</span>
					  </div>
					</a>
				  </div>
			   </div>
			</div>
		</section>
		<!-- === team member imformation === -->
		<section>
		  <div class="container-lg">
		    <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-10">
			      <h3 class="text-goldren-400 font-playfair-Display fst-italic mb-3">Meet the team</h3>
			      <h1 class="text-capitalize fw-bolder display-4 opacity-75">dedicated Agents</h1>
			   </div>
			</div>
		    <div class="row g-4">
			  <!-- === team member imformation-1 === -->
			  <div class="col-sm-6">
			    <div class="card custom-shadow border-0 rounded-0 h-100">
				  <div class="row g-0">
					<div class="col-lg-6">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
					    <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/member_1.jpg)">
						   <p class="py-5 my-5 d-block d-lg-none"></p>
						   <a href="#" class="btn btn-sm border-0 rounded-0 text-light bg-goldren-300 bg-hover-dark-600 my-4 mx-md-4 mx-5">MY LISTINGS</a>
						</div>
					  </div>
					</div>
					<div class="col-lg-6">
					  <div class="card-body">
					    <!-- === team member name === -->
						<h5 class="mb-0">
						  <a href="#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">daniel taylor</a>	
						</h5>
						<small class="text-goldren-400">real estate broker</small>
						<!-- === team member contact info === -->
						<ul class="list-group mt-3 mb-3">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					    </ul>
						<!-- === team member social media link === -->
						<div class="row g-0">
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-facebook-f m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border border-start-0 rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-twitter m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-linkedin-in m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-pinterest-p m-auto fa-sm flex-shrink-0"></i>
						  </a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- === team member imformation-2 === -->
			  <div class="col-sm-6">
			    <div class="card custom-shadow border-0 rounded-0 h-100">
				  <div class="row g-0">
					<div class="col-lg-6">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
					    <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/person3-500x350.jpg)">
						   <p class="py-5 my-5 d-block d-lg-none"></p>
						   <a href="<?php echo $baseurl; ?>#" class="btn btn-sm border-0 rounded-0 text-light bg-goldren-300 bg-hover-dark-600 my-4 mx-md-4 mx-5">MY LISTINGS</a>
						</div>
					  </div>
					</div>
					<div class="col-lg-6">
					  <div class="card-body">
					    <!-- === team member name === -->
						<h5 class="mb-0">
						  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">daniel taylor</a>	
						</h5>
						<small class="text-goldren-400">real estate broker</small>
						<!-- === team member contact info === -->
						<ul class="list-group mt-3 mb-3">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					    </ul>
						<!-- === team member social media link === -->
						<div class="row g-0">
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-facebook-f m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border border-start-0 rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-twitter m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-linkedin-in m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-pinterest-p m-auto fa-sm flex-shrink-0"></i>
						  </a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- === team member imformation-3 === -->
			  <div class="col-sm-6">
			    <div class="card custom-shadow border-0 rounded-0 h-100">
				  <div class="row g-0">
					<div class="col-lg-6">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
					    <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/team_member_3.png)">
						   <p class="py-5 my-5 d-block d-lg-none"></p>
						   <a href="<?php echo $baseurl; ?>#" class="btn btn-sm border-0 rounded-0 text-light bg-goldren-300 bg-hover-dark-600 my-4 mx-md-4 mx-5">MY LISTINGS</a>
						</div>
					  </div>
					</div>
					<div class="col-lg-6">
					  <div class="card-body">
					    <!-- === team member name === -->
						<h5 class="mb-0">
						  <a href="#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">daniel taylor</a>	
						</h5>
						<small class="text-goldren-400">real estate broker</small>
						<!-- === team member contact info === -->
						<ul class="list-group mt-3 mb-3">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					    </ul>
						<!-- === team member social media link === -->
						<div class="row g-0">
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-facebook-f m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border border-start-0 rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-twitter m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-linkedin-in m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-pinterest-p m-auto fa-sm flex-shrink-0"></i>
						  </a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- === team member imformation-4 === -->
			  <div class="col-sm-6">
			    <div class="card custom-shadow border-0 rounded-0 h-100">
				  <div class="row g-0">
					<div class="col-lg-6">
					  <div class="card overflow-hidden border-0 rounded-0 h-100">
					    <div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-start card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/team_member_4.jpg)">
						   <p class="py-5 my-5 d-block d-lg-none"></p>
						   <a href="<?php echo $baseurl; ?>#" class="btn btn-sm border-0 rounded-0 text-light bg-goldren-300 bg-hover-dark-600 my-4 mx-md-4 mx-5">MY LISTINGS</a>
						</div>
					  </div>
					</div>
					<div class="col-lg-6">
					  <div class="card-body">
					    <!-- === team member name === -->
						<h5 class="mb-0">
						  <a href="#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">daniel taylor</a>	
						</h5>
						<small class="text-goldren-400">real estate broker</small>
						<!-- === team member contact info === -->
						<ul class="list-group mt-3 mb-3">
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-phone fa-xs me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-solid fa-mobile-screen-button me-2 flex-shrink-0"></i>
							   <small>(305) 555-4555</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-regular fa-envelope me-2 flex-shrink-0"></i>
							   <small>08wasti@gmail.com</small>
							</span>
						  </li>
						  <li class="list-group-item border-0 ps-0 pb-0">
							<span class="text-body-tertiary fw-semibold d-flex align-items-center">
							   <i class="fa-brands fa-skype me-2 flex-shrink-0"></i>
							   <small>Daniel.Taylor</small>
							</span>
						  </li>
					    </ul>
						<!-- === team member social media link === -->
						<div class="row g-0">
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-facebook-f m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border border-start-0 rounded-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-twitter m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-linkedin-in m-auto fa-sm flex-shrink-0"></i>
						  </a>
						  <a href="<?php echo $baseurl; ?>#" class="h-2 w-2 border rounded-0 border-start-0 text-muted opacity-50 d-flex text-decoration-none text-goldren-300-hover">
						    <i class="fa-brands fa-pinterest-p m-auto fa-sm flex-shrink-0"></i>
						  </a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		<!-- === our blog === -->
		<section class="bg-light" id="blog">
		   <div class="container-lg">
		     <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-10">
			      <h3 class="text-goldren-400 font-playfair-Display fst-italic mb-3">Some useful information</h3>
			      <h1 class="text-capitalize fw-bolder display-4 opacity-75">our blog</h1>
			   </div>
			 </div>
			 <div class="position-relative">
			   <div class="swiper ourblog">
				  <div class="swiper-wrapper">
				    <!-- our blog-1 === -->
					<div class="swiper-slide">
					  <div class="card border-0 rounded-0 custom-shadow">
					     <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- our blog-2 === -->
					<div class="swiper-slide">
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- our blog-3 === -->
					<div class="swiper-slide">
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
					<!-- our blog-4 === -->
					<div class="swiper-slide">
					  <div class="card border-0 custom-shadow">
						 <div class="card overflow-hidden border-0 rounded-0">
						    <img src="<?php echo $baseurl; ?>images/blog_1.jpg" class="img-top card-transform-scale-110-hover card-transform-scale-120 transition-400">
						 </div>
						 <div class="card-body">
						    <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
						      <h5 class="text-uppercase fw-bolder text-dark mb-3 text-goldren-300-hover transition-400">buying a home</h5>
						    </a>
						    <p class="fs-6 text-muted">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used.text commonly used.<span class="text-goldren-400">[More]</span></p>
						 </div>
						 <div class="card-footer justify-content-between d-flex border-0 rounded-0 bg-white">
						    <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>by admin</small></a>
						    <div>
							  <a href="<?php echo $baseurl; ?>#" class="text-uppercase text-muted text-decoration-none"><small>May 28,2023</small></a>
							</div>
						 </div>
					  </div>
					</div>
				  </div>
			   </div>
			   <!-- next,prev btn === -->
			   <button type="button" class="btn swiper-button-next h-2 w-2 bg-goldren-300 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-right"></i>
			   </button>
			   <button type="button" class="btn swiper-button-prev h-2 w-2 bg-goldren-300 text-white rounded-0 border-0 top-n3">
			     <i class="fa-solid fa-angle-left"></i>
			   </button>
			   <div class="swiper-pagination"></div>
			 </div>
		   </div>
		</section>
		<!-- === Testimonials === -->
		<section class="bg-light-500 pb-sm-0">
		   <div class="container-lg">
		      <div class="row justify-content-center text-center mb-5">
			   <div class="col-md-10">
			      <h3 class="text-goldren-400 font-playfair-Display fst-italic mb-3">what people say</h3>
			      <h1 class="text-capitalize fw-bolder display-4 opacity-75">testimonials</h1>
			   </div>
			  </div>
			 <!-- === Testimonials carousel start === -->
			 <div id="testimonials" class="carousel slide">
				  <button class="carousel-control-prev bottom-100 left-auto justify-content-end py-3 mt-5" type="button" data-bs-target="#testimonials" data-bs-slide="prev" style="right: 25px;">
					<i class="fa-solid fa-chevron-left text-dark fs-5 opacity-50"></i>
				  </button>
				  <button class="carousel-control-next bottom-100 justify-content-end py-3 mt-5 me-2" type="button" data-bs-target="#testimonials" data-bs-slide="next">
					<i class="fa-solid fa-chevron-right text-dark fs-5 opacity-50"></i>
				  </button>
				  <!-- === Testimonials carousel-inner === -->
				  <div class="carousel-inner mt-5">
				    <!-- === Testimonials information-1 === -->
					<div class="carousel-item active">
					  <div class="col-12">
						<div class="card border-0 rounded-0 bg-light mt-5">
						  <div class="row g-0 align-items-center">
							<div class="col-md-4 col-5">
							  <div class="background-size-cover background-repeat-no-repeat background-position-center position-relative custom-shadow" style="background-image:url(images/home.jpg);
							  height:300px; top:-30px;left:-30px;"></div>
							</div>
							<div class="col-md-8 col-7">
							  <span class="opacity-50"><i class="fa-solid fa-quote-left fa-3x"></i></span>
							  <p class="text-muted fw-semibold opacity-75 mt-3"><small>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</small></p>
							  <h6 class="fs-6 text-uppercase fw-bold mb-0">john moxley</h6>
							  <p class="text-muted fw-semibold opacity-75"><small>real estate developer</small></p>
							</div>
						  </div>
						</div>
					  </div>
					</div>
					<!-- === Testimonials information-2 === -->
					<div class="carousel-item">
					  <div class="col-12">
						<div class="card border-0 rounded-0 bg-light mt-5">
						  <div class="row g-0 align-items-center">
							<div class="col-md-4 col-5">
							  <div class="background-size-cover background-repeat-no-repeat background-position-center position-relative custom-shadow" style="background-image:url(images/card_4.jpg);
							  height:300px; top:-30px;left:-30px;"></div>
							</div>
							<div class="col-md-8 col-7">
							  <span class="opacity-50"><i class="fa-solid fa-quote-left fa-3x"></i></span>
							  <p class="text-muted fw-semibold opacity-75 mt-3"><small>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</small></p>
							  <h6 class="fs-6 text-uppercase fw-bold mb-0">john moxley</h6>
							  <p class="text-muted fw-semibold opacity-75"><small>real estate developer</small></p>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === Testimonials indicators === -->
				  <div class="carousel-indicators position-static mt-5 mb-0 testimonials-carousel">
					<button type="button" data-bs-target="#testimonials" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1" class="text-light"></button>
					<button type="button" data-bs-target="#testimonials" data-bs-slide-to="1" aria-label="Slide 2" class="text-light"></button>
				  </div>
			 </div>
			 <!-- === === -->
			  <div class="row justify-content-center text-center bg-white shadow-sm pt-5 pb-5 position-relative subscribe">
				<div class="col-lg-6 col-md-10">
					 <h3 class="text-goldren-400 font-playfair-Display fst-italic mb-2 mt-5">Sign up for our special offers</h3>
					 <h1 class="text-capitalize fw-bolder display-4 mb-4">Get the News</h1>
					 <!-- === sing up form === -->
					 <form action="" method="post" class="mb-5">
						<div class="input-group input-group-lg">
						  <input type="text" name="" class="form-control shadow-none rounded-0 form-control-focus">
						  <button type="submit" name="" class="input-group-text btn bg-goldren-300 text-light fw-semibold rounded-0">Subscribe</button>
						</div>
					 </form>
				</div>	  
			  </div>
		   </div>
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pb-5" id="footer">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<script>
		var swiper = new Swiper(".ourblog", {
		  spaceBetween: 20,
		  loop: true,
		  breakpoints: {
			576: {
			  slidesPerView: 1,
			  spaceBetween: 20,
			},
			768: {
			  slidesPerView: 2,
			  spaceBetween: 20,
			},
			1024: {
			  slidesPerView: 3,
			  spaceBetween: 30,
			},
		  },
		  navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
		  },
		  pagination: {
			el: ".swiper-pagination",
			clickable: true,
		  },
		});
    </script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>