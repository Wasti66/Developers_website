<?php include('header.php'); ?>
	<main>
	   <section class="pt-0 pb-0">
		    <?php include('map.php'); ?>
		</section>
	    <!-- === Standard – No Sidebar right form  === -->
		<section class="bg-light border-bottom pt-md-3 pb-md-4 pt-0 pb-2">
		  <?php include('form.php'); ?>
		</section>
		<!-- === Standard – No Properties right List === -->
		<section class="bg-sky-50 pt-4 pb-2">
		  <div class="container-lg">
		    <div class="row g-4">
			  <!-- === === -->
			  <div class="col-lg-3 col-md-4 mt-md-5 order-5 order-md-0">
			    <div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Change Your Currency</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						 <option value="">$</option>
						 <option value="1">EUR</option>
					  </select>
				   </form>
				</div>
				<!-- === advance search === -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">advanced search</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Search">
				   </form>
				</div>
				<!-- ===  Mortgage Calculator === -->
				<div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Mortgage Calculator</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Sale Price</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10000">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Percent Down</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Term (Years)</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="30">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Interest Rate in %</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="5">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Calculate">
				   </form>
				</div>
				<!-- ===  Spacious Office Space === -->
				<?php include('spacious-ofice.php'); ?>
			  </div>
			  <!-- === === -->
			  <div class="col-lg-9 col-md-8 order-0 order-md-5">
			     <nav aria-label="breadcrumb mb-0">
				   <ol class="breadcrumb mb-0">
					<li class="breadcrumb-item">
					  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none fw-semibold"><small>Home</small></a>
					</li>
					<li class="breadcrumb-item ps-1">
					  <a href="<?php echo $baseurl; ?>#" class="text-goldren-400 text-decoration-none fw-semibold"><small>Property List with Sidebar</small></a>
					</li>
				   </ol>
				 </nav>
				 <h1 class="text-capitalize fw-lighter mb-4">Property List with Sidebar</h1>
				 <!-- === list and grid form === -->
				 <div class="row align-items-end mb-5">
				   <div class="col-md-9">
					 <div class="row g-2">
					   <!-- === 1 === -->
					   <div class="col-md-auto">
						 <select class="form-select form-select-lg rounded-0 border-0 shadow fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							  <option value="">All action</option>
							  <option value="1">One</option>
							  <option value="2">Two</option>
							  <option value="3">Three</option>
						 </select>
					   </div>
					   <!-- === 2 === -->
					   <div class="col-md-auto">
						 <select class="form-select form-select-lg rounded-0 border-0 shadow fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							  <option value="">All action</option>
							  <option value="1">One</option>
							  <option value="2">Two</option>
							  <option value="3">Three</option>
						 </select>
					   </div>
					   <!-- === 3 === -->
					   <div class="col-md-auto">
						 <select class="form-select form-select-lg rounded-0 border-0 shadow fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							  <option value="">All action</option>
							  <option value="1">One</option>
							  <option value="2">Two</option>
							  <option value="3">Three</option>
						 </select>
					   </div>
					   <!-- === 4 === -->
					   <div class="col-md-auto">
						 <select class="form-select form-select-lg rounded-0 border-0 shadow fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							  <option value="">All action</option>
							  <option value="1">One</option>
							  <option value="2">Two</option>
							  <option value="3">Three</option>
						 </select>
					   </div>
					   <!-- === 5 === -->
					   <div class="col-md-auto">
						 <select class="form-select form-select-lg rounded-0 border-0 shadow fs-6 text-secondary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
							  <option value="">Defult</option>
							  <option value="1">One</option>
							  <option value="2">Two</option>
							  <option value="3">Three</option>
						 </select>
					   </div>
					 </div>
				   </div>
				   <!-- === list and grid action btn === -->
				   <div class="col-md-3 col-md-2 links d-md-block d-none">
					 <ul class="list-group list-group-horizontal justify-content-end py-0 cursor-pointer">
						<li data-view="list-view" class="li-list list-group-item bg-transparent p-0 border-0 text-goldren-300-hover text-dark active">
						   <i class="fa-solid fa-list fa-xl me-3"></i>
						</li>
						<li data-view="grid-view" class="li-grid list-group-item bg-transparent p-0 border-0 text-goldren-300-hover text-dark">
						   <i class="fa-solid fa-table-cells-large fa-xl"></i>
						</li>
					 </ul>
				   </div>
				 </div>
				 <!-- === list view === -->
				 <div class="list-view view_wrap" style="display: block;">
					<div class="row">
					  <div class="col-12">
						<!-- list 1 -->
						<div class="card shadow-sm border-0 rounded-0 mb-4">
						  <div class="row g-0">
							<div class="col-lg-4 col-md-5">
							  <div class="card overflow-hidden border-0 rounded-0 h-100">
								<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
								   <p class="py-5 my-5"></p>
								   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
								</div>
								<div class="card-img-overlay">
								  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
								  <p></p>
								</div>
							  </div>
							</div>
							<div class="col-lg-8 col-md-7">
							  <div class="card-body">
								<!-- === Serviced Business Apartment === -->
								<h5 class="mb-0">
								  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
								</h5>
								<div class="mb-3">
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								</div>
								<div class="d-flex align-items-center mb-3">
								  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
								  <span class="mx-1 text-goldren-400">/</span>
								  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
								</div>
								<ul class="list-group list-group-horizontal text-center">
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
								  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
								</ul>
							  </div>
							  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
									   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
									  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </div>
						</div>
						<!-- list 2 -->
						<div class="card shadow-sm border-0 rounded-0 mb-4">
						  <div class="row g-0">
							<div class="col-lg-4 col-md-5">
							  <div class="card overflow-hidden border-0 rounded-0 h-100">
								<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
								   <p class="py-5 my-5"></p>
								   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
								</div>
								<div class="card-img-overlay">
								  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
								  <p></p>
								</div>
							  </div>
							</div>
							<div class="col-lg-8 col-md-7">
							  <div class="card-body">
								<!-- === Serviced Business Apartment === -->
								<h5 class="mb-0">
								  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
								</h5>
								<div class="mb-3">
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								</div>
								<div class="d-flex align-items-center mb-3">
								  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
								  <span class="mx-1 text-goldren-400">/</span>
								  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
								</div>
								<ul class="list-group list-group-horizontal text-center">
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
								  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
								</ul>
							  </div>
							  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
									   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
									  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </div>
						</div>
						<!-- list 3 -->
						<div class="card shadow-sm border-0 rounded-0 mb-4">
						  <div class="row g-0">
							<div class="col-lg-4 col-md-5">
							  <div class="card overflow-hidden border-0 rounded-0 h-100">
								<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
								   <p class="py-5 my-5"></p>
								   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
								</div>
								<div class="card-img-overlay">
								  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
								  <p></p>
								</div>
							  </div>
							</div>
							<div class="col-lg-8 col-md-7">
							  <div class="card-body">
								<!-- === Serviced Business Apartment === -->
								<h5 class="mb-0">
								  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
								</h5>
								<div class="mb-3">
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								</div>
								<div class="d-flex align-items-center mb-3">
								  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
								  <span class="mx-1 text-goldren-400">/</span>
								  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
								</div>
								<ul class="list-group list-group-horizontal text-center">
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
								  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
								</ul>
							  </div>
							  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
									   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
									  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </div>
						</div>
						<!-- list 4 -->
						<div class="card shadow-sm border-0 rounded-0 mb-4">
						  <div class="row g-0">
							<div class="col-lg-4 col-md-5">
							  <div class="card overflow-hidden border-0 rounded-0 h-100">
								<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
								   <p class="py-5 my-5"></p>
								   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
								</div>
								<div class="card-img-overlay">
								  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
								  <p></p>
								</div>
							  </div>
							</div>
							<div class="col-lg-8 col-md-7">
							  <div class="card-body">
								<!-- === Serviced Business Apartment === -->
								<h5 class="mb-0">
								  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
								</h5>
								<div class=" mb-3">
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								</div>
								<div class="d-flex align-items-center mb-3">
								  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
								  <span class="mx-1 text-goldren-400">/</span>
								  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
								</div>
								<ul class="list-group list-group-horizontal text-center">
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
								  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
								</ul>
							  </div>
							  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
									   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
									  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </div>
						</div>
						<!-- list 5 -->
						<div class="card shadow-sm border-0 rounded-0 mb-3">
						  <div class="row g-0">
							<div class="col-lg-4 col-md-5">
							  <div class="card overflow-hidden border-0 rounded-0 h-100">
								<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_4.jpg)">
								   <p class="py-5 my-5"></p>
								   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
								</div>
								<div class="card-img-overlay">
								  <span class="badge text-bg-danger text-capitalize rounded-0 px-3 py-2 opacity-75">open house</span>
								  <p></p>
								</div>
							  </div>
							</div>
							<div class="col-lg-8 col-md-7">
							  <div class="card-body">
								<!-- === Serviced Business Apartment === -->
								<h5 class="mb-0">
								  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
								</h5>
								<div class=" mb-3">
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
								   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								</div>
								<div class="d-flex align-items-center mb-3">
								  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
								  <span class="mx-1 text-goldren-400">/</span>
								  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
								</div>
								<ul class="list-group list-group-horizontal text-center">
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
								  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
								  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
								</ul>
							  </div>
							  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
									   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
									  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </div>
						</div>
					  </div>
					  <!-- === Pagination === -->
					  <nav aria-label="Page navigation example">
						<ul class="pagination">
						  <li class="page-item me-1">
							<a class="page-link rounded-0 text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#" aria-label="Previous">
							  <i class="fa-solid fa-angle-left"></i>
							</a>
						  </li>
						  <li class="page-item me-1">
							<a class="page-link bg-goldren-300 text-light shadow-none" href="<?php echo $baseurl; ?>#">1</a>
						  </li>
						  <li class="page-item me-1">
							<a class="page-link text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#">2</a>
						  </li>
						  <li class="page-item me-1">
							<a class="page-link text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#">3</a>
						  </li>
						  <li class="page-item me-1">
							<a class="page-link rounded-0 text-goldren-400 shadow-none" href="<?php echo $baseurl; ?>#" aria-label="Next">
							  <i class="fa-solid fa-angle-right"></i>
							</a>
						  </li>
						</ul>
					  </nav>
					</div>
				 </div>
				 <!-- === grid view === -->
				 <div class="view_wrap grid-view" style="display: none;">
					<div class="row g-4">
					   <!-- === grid 1 === -->	
					   <div class="col-md-6">
						  <!-- === featured linked === -->
						  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							<div class="card custom-shadow rounded-0 border-0 h-100">
							  <div class="card border-0 rounded-0 overflow-hidden">
								<!-- === featured images 1 === -->
								<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
								<!-- === card-img-overlay-1 === -->
								<div class="card-img-overlay">
								   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
								</div>
								<!-- === card-img-overlay-2 === -->
								<div class="card-img-overlay d-flex justify-content-end align-items-end">
								   <span class="fs-6 text-light">compare</span>
								</div>
							  </div>
							  <!-- === featured information content === -->
							  <div class="card-body">
								 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
								 <div class=" mb-3">
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								 </div>
								 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
								 <div class="d-flex justify-content-center text-center align-items-center">
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
									   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
									   <p class="mb-0 fs-6 text-secondary">baths</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
									   <p class="mb-0 fs-6 text-secondary">size</p>
									</div>
								 </div>
							  </div>
							  <!-- === === -->
							  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?><?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?><?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
									   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
									  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </a>
					   </div>
					   <!-- === grid 2 === -->	
					   <div class="col-md-6">
						  <!-- === featured linked === -->
						  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							<div class="card custom-shadow rounded-0 border-0 h-100">
							  <div class="card border-0 rounded-0 overflow-hidden">
								<!-- === featured images 1 === -->
								<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
								<!-- === card-img-overlay-1 === -->
								<div class="card-img-overlay">
								   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
								</div>
								<!-- === card-img-overlay-2 === -->
								<div class="card-img-overlay d-flex justify-content-end align-items-end">
								   <span class="fs-6 text-light">compare</span>
								</div>
							  </div>
							  <!-- === featured information content === -->
							  <div class="card-body">
								 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
								 <div class="mb-3">
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								 </div>
								 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
								 <div class="d-flex justify-content-center text-center align-items-center">
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
									   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
									   <p class="mb-0 fs-6 text-secondary">baths</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
									   <p class="mb-0 fs-6 text-secondary">size</p>
									</div>
								 </div>
							  </div>
							  <!-- === === -->
							  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
									   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
									  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </a>
					   </div>
					   <!-- === grid 3 === -->	
					   <div class="col-md-6">
						  <!-- === featured linked === -->
						  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
							<div class="card custom-shadow rounded-0 border-0 h-100">
							  <div class="card border-0 rounded-0 overflow-hidden">
								<!-- === featured images 1 === -->
								<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
								<!-- === card-img-overlay-1 === -->
								<div class="card-img-overlay">
								   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
								</div>
								<!-- === card-img-overlay-2 === -->
								<div class="card-img-overlay d-flex justify-content-end align-items-end">
								   <span class="fs-6 text-light">compare</span>
								</div>
							  </div>
							  <!-- === featured information content === -->
							  <div class="card-body">
								 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
								 <div class="mb-3">
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								 </div>
								 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
								 <div class="d-flex justify-content-center text-center align-items-center">
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
									   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
									   <p class="mb-0 fs-6 text-secondary">baths</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
									   <p class="mb-0 fs-6 text-secondary">size</p>
									</div>
								 </div>
							  </div>
							  <!-- === === -->
							  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
									   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
									  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </a>
					   </div>
					   <!-- === grid 4 === -->	
					   <div class="col-md-6">
						  <!-- === featured linked === -->
						  <a href="#" class="text-decoration-none">
							<div class="card custom-shadow rounded-0 border-0 h-100">
							  <div class="card border-0 rounded-0 overflow-hidden">
								<!-- === featured images 1 === -->
								<img src="<?php echo $baseurl; ?>images/card_4.jpg" class="card-img-top rounded-0 card-transform-scale-110-hover card-transform-scale-120 transition-400">
								<!-- === card-img-overlay-1 === -->
								<div class="card-img-overlay">
								   <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
								</div>
								<!-- === card-img-overlay-2 === -->
								<div class="card-img-overlay d-flex justify-content-end align-items-end">
								   <span class="fs-6 text-light">compare</span>
								</div>
							  </div>
							  <!-- === featured information content === -->
							  <div class="card-body">
								 <h5 class="text-uppercase fw-bolder text-dark mb-1 text-goldren-300-hover transition-100">wonderful new villa</h5>
								 <div class="mb-3">
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Edgewater, </a>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
								 </div>
								 <h5 class="text-uppercase fw-bolder text-goldren-400 mb-4">$ 5.500.000</h5>
								 <div class="d-flex justify-content-center text-center align-items-center">
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
									   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
									   <p class="mb-0 fs-6 text-secondary">baths</p>
									</div>
									<div class="px-3 line-height-15 border border-top-0 border-bottom-0 border-start-0">
									   <p class="mb-0 fs-6 text-secondary fw-semibold">250ft<sup>2</sup></p>
									   <p class="mb-0 fs-6 text-secondary">size</p>
									</div>
								 </div>
							  </div>
							  <!-- === === -->
							  <div class="card-footer border-0 bg-white mt-3 mb-3 d-flex align-items-center justify-content-between">
								 <div class="d-flex align-items-center">
									<div class="flex-shrink-0">
									   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 w-3 rounded-circle border">
									</div>
									<div class="flex-grow-1 ms-2">
									   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-secondary">Susan Anderson</a>
									   <p class="fs-6 text-secondary mb-0"><small>May 27, 2023</small></p>
									</div>
								 </div>
								 <div>
									<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-3">
									  <i class="fa-solid fa-heart text-secondary opacity-25"></i>
									</a>
								 </div>
							  </div>
							</div>
						  </a>
					   </div>
					</div>
				 </div>
			  </div>
			</div>
		  </div>
		</section>
		
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<script>
		var li_links = document.querySelectorAll(".links ul li");
		var view_wraps = document.querySelectorAll(".view_wrap");
		var list_view = document.querySelector(".list-view");
		var grid_view = document.querySelector(".grid-view");

		li_links.forEach(function(link){
			link.addEventListener("click", function(){
				li_links.forEach(function(link){
					link.classList.remove("active");
				})

				link.classList.add("active");

				var li_view = link.getAttribute("data-view");

				view_wraps.forEach(function(view){
					view.style.display = "none";
				})

				if(li_view == "list-view"){
					list_view.style.display = "block";
				}
				else{
					grid_view.style.display = "block";
				}
			})
		})

	</script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>