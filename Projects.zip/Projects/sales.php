<?php

	include('apartments.php');

?>