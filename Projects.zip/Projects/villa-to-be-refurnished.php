<?php include('header.php'); ?>
	<main>
	    
		<!-- === google map fixed social media link === -->
	    <section class="pt-0 pb-0 d-none d-lg-block">
			<?php include('social-medialink.php'); ?>
		</section>
		<!-- === google map map === -->
		<section class="pt-0 pb-0">
		    <?php include('map.php'); ?>
		</section>
		<!-- === google map form === -->
		<section class="bg-light border-bottom pt-md-3 pb-md-4 pt-0 pb-2">
		   <?php include('form.php'); ?>
		</section>
		<!-- === Villa to be refurnished  === -->
		<section class="border-bottom pt-4 pb-md-3 pb-5">
		   <div class="container-lg">
		     <div class="row align-items-center mb-4">
			   <div class="col-lg-9 col-md-8 mb-md-0 mb-3">
			     <!-- Spacious Office Space information -->
			     <nav aria-label="breadcrumb mb-0">
				   <ol class="breadcrumb mb-0">
					<li class="breadcrumb-item">
					  <a href="<?php echo $baseurl; ?>#" class="text-body-tertiary text-decoration-none fw-semibold"><small>villas</small></a>
					</li>
					<li class="breadcrumb-item ps-1">
					  <a href="<?php echo $baseurl; ?>#" class="text-body-tertiary text-decoration-none fw-semibold"><small>sales</small></a>
					</li>
				   </ol>
				 </nav>
				 <h1 class="text-capitalize display-4 fw-lighter mb-0">Villa to be refurnished</h1>
				 <div class="">
				   <a href="#" class="text-decoration-none fs-6 text-secondary text-goldren-400">NW 7th St,</a>
				   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary text-goldren-400">Miami,</a>
				   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary text-goldren-400">Brickwell</a>
				 </div>	
			   </div>
			   <div class="col-lg-3 col-md-4 mb-md-0 mb-3 text-md-end">
			     <div class="d-flex align-items-center justify-content-md-end">
				   <h1 class="text-goldren-400 fw-bold mb-0">$ 100</h1>
				   <span class="mx-1 text-goldren-400">/</span>
				  <p class="mb-0 text-goldren-400 fw-semibold">sq. ft.</p>
				 </div>
				 <a href="<?php echo $baseurl; ?>#" class="btn text-decoration-none border-goldren-1 text-goldren-400 py-0 rounded-0"><small>add to favorites</small></a>
				 <a href="<?php echo $baseurl; ?>#" class="btn text-decoration-none border-goldren-1 text-goldren-400 py-0 rounded-0"><small>print</small></a>
			   </div>
			 </div>
			 <!-- === no header background image  === -->
			 <div class="row bg-light g-2">
			   <!-- === no header bg img 1 === -->
			   <div class="col-md-8 cursor-pointer">
			     <!-- === no header modal btn 1 === -->
			     <a data-bs-toggle="modal" data-bs-target="#sider-gallery1">
				    <div class="background-size-cover background-repeat-no-repeat background-position-center card border-0 rounded-0" style="background-image:url(images/map-house-1.jpg); min-height: 320px;">
					  <!-- === card img overlay use === -->
					  <div class="card-img-overlay bg-green-50 card-img-overlay-hover rounded-0"></div>
					</div>
				 </a>
			   </div>
			   <!-- no header modal 1 -->
			   <div class="modal fade" id="sider-gallery1" data-bs-backdrop="static" tabindex="-1">
				  <div class="modal-dialog modal-dialog-centered modal-xl">
					<div class="modal-content shadow rounded-0 border-0">
					  <div class="modal-header justify-content-end p-0">
						<button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none d-lg-none d-block" data-bs-dismiss="modal" aria-label="Close">
						  <i class="fa-solid fa-xmark fa-2x text-white"></i>
						</button>
					  </div>
					  <div class="modal-body p-0">
						<!-- === === -->
						<div class="row">
						  <!-- === no header modal images === -->
						  <div class="col-lg-8 mb-lg-0 mb-3">
							<div id="sliderModalImg_1" class="carousel slide">
							  <div class="carousel-inner">
								<div class="carousel-item active">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-1.jpg); height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-3.jpg); min-height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/slider-img-5.jpg); min-height: 623px;"></div>
								</div>
							  </div>
							  <button class="carousel-control-prev w-auto ms-3 opacity-100" type="button" data-bs-target="#sliderModalImg_1" data-bs-slide="prev">
								<i class="fa-solid fa-chevron-left fa-3x text-white"></i>
							  </button>
							  <button class="carousel-control-next w-auto me-3 opacity-100" type="button" data-bs-target="#sliderModalImg_1" data-bs-slide="next">
								<i class="fa-solid fa-chevron-right fa-3x text-white"></i>
							  </button>
							</div>
						  </div>
						  <!-- === modal no header gallery form === -->
						  <div class="col-lg-4 col-md-5 mb-lg-0 mb-4">
						    <!-- === modal close btn responsive device show === -->
						    <div class="text-end position-absolute end-0 d-lg-block d-none">
							   <button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none" data-bs-dismiss="modal" aria-label="Close">
						         <i class="fa-solid fa-xmark fa-2x text-white"></i>
						       </button>
							</div>
						    <h6 class="fs-6 text-capitalize fw-semibold mb-3 px-md-4 px-2 mt-md-5">property enquiry</h6>
						    <form action="" method="post" class="px-lg-4 px-2">
						      <!-- === name === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="name" placeholder="Your Name">
						      </div>
						      <!-- === email === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="email" placeholder="Your Email">
						      </div>
						      <!-- === phone === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="number" name="phone" placeholder="Your Phone">
						      </div>
						      <!-- === text-box === -->
						      <div class="mb-4">
							    <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="msg" placeholder="I'm interested in  [ Spacious Office Space ] " rows="4"></textarea>
						      </div>
						      <!-- === action input btn === -->
						      <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
						    </form>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
			   </div>
			   <!-- === no header bg img 2 === -->
			   <div class="col-md-4 cursor-pointer">
				 <!-- === slider gallery modal btn 2 === -->
			     <a data-bs-toggle="modal" data-bs-target="#sider-gallery2">
				    <div class="background-size-cover background-repeat-no-repeat background-position-center mb-2 card border-0 rounded-0" style="background-image:url(images/no-header-2.jpg); min-height: 160px;">
					  <!-- === card img overlay use === -->
					  <div class="card-img-overlay bg-green-50 card-img-overlay-hover rounded-0"></div>
					</div>
				 </a>
				 <!-- no header modal 2 -->
			     <div class="modal fade" id="sider-gallery2" data-bs-backdrop="static" tabindex="-1">
				  <div class="modal-dialog modal-dialog-centered modal-xl">
					<div class="modal-content shadow rounded-0 border-0">
					  <div class="modal-header justify-content-end p-0">
						<button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none d-lg-none d-block" data-bs-dismiss="modal" aria-label="Close">
						  <i class="fa-solid fa-xmark fa-2x text-white"></i>
						</button>
					  </div>
					  <div class="modal-body p-0">
						<!-- === === -->
						<div class="row">
						  <!-- === no header modal images === -->
						  <div class="col-lg-8 mb-lg-0 mb-3">
							<div id="sliderModalImg_2" class="carousel slide">
							  <div class="carousel-inner">
								<div class="carousel-item active">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-3.jpg); height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/sider-img2.jpg); min-height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-1.jpg); min-height: 623px;"></div>
								</div>
							  </div>
							  <button class="carousel-control-prev w-auto ms-3 opacity-100" type="button" data-bs-target="#sliderModalImg_2" data-bs-slide="prev">
								<i class="fa-solid fa-chevron-left fa-3x text-white"></i>
							  </button>
							  <button class="carousel-control-next w-auto me-3 opacity-100" type="button" data-bs-target="#sliderModalImg_2" data-bs-slide="next">
								<i class="fa-solid fa-chevron-right fa-3x text-white"></i>
							  </button>
							</div>
						  </div>
						  <!-- === no header gallery form === -->
						  <div class="col-lg-4 col-md-5 mb-lg-0 mb-4">
						    <!-- === modal close btn responsive device show === -->
						    <div class="text-end position-absolute end-0 d-lg-block d-none">
							   <button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none" data-bs-dismiss="modal" aria-label="Close">
						         <i class="fa-solid fa-xmark fa-2x text-white"></i>
						       </button>
							</div>
						    <h6 class="fs-6 text-capitalize fw-semibold mb-3 px-md-4 px-2 mt-md-5">property enquiry</h6>
						    <form action="" method="post" class="px-lg-4 px-2">
						      <!-- === name === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="name" placeholder="Your Name">
						      </div>
						      <!-- === email === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="email" placeholder="Your Email">
						      </div>
						      <!-- === phone === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="number" name="phone" placeholder="Your Phone">
						      </div>
						      <!-- === text-box === -->
						      <div class="mb-4">
							    <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="msg" placeholder="I'm interested in  [ Spacious Office Space ] " rows="4"></textarea>
						      </div>
						      <!-- === action input btn === -->
						      <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
						    </form>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
			     </div>
				 <!-- === no header bg img 3 === -->
				 <!-- === no header modal btn 3 === -->
			     <a data-bs-toggle="modal" data-bs-target="#sider-gallery3">
				    <div class="background-size-cover background-repeat-no-repeat background-position-center mb-2 card border-0 rounded-0" style="background-image:url(images/no-header-3.jpg); min-height: 160px;">
					  <!-- === card img overlay use === -->
					  <div class="card-img-overlay bg-green-50 card-img-overlay-hover rounded-0"></div>
					</div>
				 </a>
				 <!-- no header modal 3 -->
			     <div class="modal fade" id="sider-gallery3" data-bs-backdrop="static" tabindex="-1">
				  <div class="modal-dialog modal-dialog-centered modal-xl">
					<div class="modal-content shadow rounded-0 border-0">
					  <div class="modal-header justify-content-end p-0">
						<button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none d-lg-none d-block" data-bs-dismiss="modal" aria-label="Close">
						  <i class="fa-solid fa-xmark fa-2x text-white"></i>
						</button>
					  </div>
					  <div class="modal-body p-0">
						<!-- === === -->
						<div class="row">
						  <!-- === no header modal images === -->
						  <div class="col-lg-8 mb-lg-0 mb-3">
							<div id="sliderModalImg_3" class="carousel slide">
							  <div class="carousel-inner">
								<div class="carousel-item active">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/card_5.jpg); height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/sider-img2.jpg); min-height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/slider-img-5.jpg); min-height: 623px;"></div>
								</div>
							  </div>
							  <button class="carousel-control-prev w-auto ms-3 opacity-100" type="button" data-bs-target="#sliderModalImg_3" data-bs-slide="prev">
								<i class="fa-solid fa-chevron-left fa-3x text-white"></i>
							  </button>
							  <button class="carousel-control-next w-auto me-3 opacity-100" type="button" data-bs-target="#sliderModalImg_3" data-bs-slide="next">
								<i class="fa-solid fa-chevron-right fa-3x text-white"></i>
							  </button>
							</div>
						  </div>
						  <!-- === no header gallery form === -->
						  <div class="col-lg-4 col-md-5 mb-lg-0 mb-4">
						    <!-- === modal close btn responsive device show === -->
						    <div class="text-end position-absolute end-0 d-lg-block d-none">
							   <button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none" data-bs-dismiss="modal" aria-label="Close">
						         <i class="fa-solid fa-xmark fa-2x text-white"></i>
						       </button>
							</div>
						    <h6 class="fs-6 text-capitalize fw-semibold mb-3 px-md-4 px-2 mt-md-5">property enquiry</h6>
						    <form action="" method="post" class="px-lg-4 px-2">
						      <!-- === name === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="name" placeholder="Your Name">
						      </div>
						      <!-- === email === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="email" placeholder="Your Email">
						      </div>
						      <!-- === phone === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="number" name="phone" placeholder="Your Phone">
						      </div>
						      <!-- === text-box === -->
						      <div class="mb-4">
							    <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="msg" placeholder="I'm interested in  [ Spacious Office Space ] " rows="4"></textarea>
						      </div>
						      <!-- === action input btn === -->
						      <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
						    </form>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
			     </div>
			   </div>	
			 </div>
			 <div class="row bg-light g-2">
			   <!-- === no header bg img 4 === -->
			   <div class="col-md-4 cursor-pointer">
			     <!-- === slider gallery modal btn 4 === -->
			     <a data-bs-toggle="modal" data-bs-target="#sider-gallery4">
				    <div class="background-size-cover background-repeat-no-repeat background-position-center mb-2 card border-0 rounded-0" style="background-image:url(images/map-house-2.jpg); min-height: 160px;">
					  <!-- === card img overlay use === -->
					  <div class="card-img-overlay bg-green-50 card-img-overlay-hover rounded-0"></div>
					</div>
				 </a>
				 <!-- no header modal 4 -->
			     <div class="modal fade" id="sider-gallery4" data-bs-backdrop="static" tabindex="-1">
				  <div class="modal-dialog modal-dialog-centered modal-xl">
					<div class="modal-content shadow rounded-0 border-0">
					  <div class="modal-header justify-content-end p-0">
						<button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none d-lg-none d-block" data-bs-dismiss="modal" aria-label="Close">
						  <i class="fa-solid fa-xmark fa-2x text-white"></i>
						</button>
					  </div>
					  <div class="modal-body p-0">
						<!-- === === -->
						<div class="row">
						  <!-- === no header modal images === -->
						  <div class="col-lg-8 mb-lg-0 mb-3">
							<div id="sliderModalImg_4" class="carousel slide">
							  <div class="carousel-inner">
								<div class="carousel-item active">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-1.jpg); height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-2.jpg); min-height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-3.jpg); min-height: 623px;"></div>
								</div>
							  </div>
							  <button class="carousel-control-prev w-auto ms-3 opacity-100" type="button" data-bs-target="#sliderModalImg_4" data-bs-slide="prev">
								<i class="fa-solid fa-chevron-left fa-3x text-white"></i>
							  </button>
							  <button class="carousel-control-next w-auto me-3 opacity-100" type="button" data-bs-target="#sliderModalImg_4" data-bs-slide="next">
								<i class="fa-solid fa-chevron-right fa-3x text-white"></i>
							  </button>
							</div>
						  </div>
						  <!-- === no header gallery form === -->
						  <div class="col-lg-4 col-md-5 mb-lg-0 mb-4">
						    <!-- === modal close btn responsive device show === -->
						    <div class="text-end position-absolute end-0 d-lg-block d-none">
							   <button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none" data-bs-dismiss="modal" aria-label="Close">
						         <i class="fa-solid fa-xmark fa-2x text-white"></i>
						       </button>
							</div>
						    <h6 class="fs-6 text-capitalize fw-semibold mb-3 px-md-4 px-2 mt-md-5">property enquiry</h6>
						    <form action="" method="post" class="px-lg-4 px-2">
						      <!-- === name === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="name" placeholder="Your Name">
						      </div>
						      <!-- === email === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="email" placeholder="Your Email">
						      </div>
						      <!-- === phone === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="number" name="phone" placeholder="Your Phone">
						      </div>
						      <!-- === text-box === -->
						      <div class="mb-4">
							    <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="msg" placeholder="I'm interested in  [ Spacious Office Space ] " rows="4"></textarea>
						      </div>
						      <!-- === action input btn === -->
						      <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
						    </form>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
			     </div>
			   </div>
			   <!-- === no header bg img 5 === -->
			   <div class="col-md-4 cursor-pointer">
			     <!-- === no header modal btn 5 === -->
			     <a data-bs-toggle="modal" data-bs-target="#sider-gallery5">
				    <div class="background-size-cover background-repeat-no-repeat background-position-center mb-2 card border-0 rounded-0" style="background-image:url(images/map-house-3.jpg); min-height: 160px;">
					  <!-- === card img overlay use === -->
					  <div class="card-img-overlay bg-green-50 card-img-overlay-hover rounded-0"></div>
					</div>
				 </a>
				 <!-- no header modal 5 -->
			     <div class="modal fade" id="sider-gallery5" data-bs-backdrop="static" tabindex="-1">
				  <div class="modal-dialog modal-dialog-centered modal-xl">
					<div class="modal-content shadow rounded-0 border-0">
					  <div class="modal-header justify-content-end p-0">
						<button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none d-lg-none d-block" data-bs-dismiss="modal" aria-label="Close">
						  <i class="fa-solid fa-xmark fa-2x text-white"></i>
						</button>
					  </div>
					  <div class="modal-body p-0">
						<!-- === === -->
						<div class="row">
						  <!-- === no header modal images === -->
						  <div class="col-lg-8 mb-lg-0 mb-3">
							<div id="sliderModalImg_5" class="carousel slide">
							  <div class="carousel-inner">
								<div class="carousel-item active">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-3.jpg); height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-2.jpg); min-height: 623px;"></div>
								</div>
								<div class="carousel-item">
								  <div class="background-size-cover background-repeat-no-repeat background-position-center" style="background-image:url(images/map-house-1.jpg); min-height: 623px;"></div>
								</div>
							  </div>
							  <button class="carousel-control-prev w-auto ms-3 opacity-100" type="button" data-bs-target="#sliderModalImg_5" data-bs-slide="prev">
								<i class="fa-solid fa-chevron-left fa-3x text-white"></i>
							  </button>
							  <button class="carousel-control-next w-auto me-3 opacity-100" type="button" data-bs-target="#sliderModalImg_5" data-bs-slide="next">
								<i class="fa-solid fa-chevron-right fa-3x text-white"></i>
							  </button>
							</div>
						  </div>
						  <!-- === no header gallery form === -->
						  <div class="col-lg-4 col-md-5 mb-lg-0 mb-4">
						    <!-- === modal close btn responsive device show === -->
						    <div class="text-end position-absolute end-0 d-lg-block d-none">
							   <button type="button" class="btn h-3 w-3 bg-goldren-300 rounded-0 opacity-100 shadow-none" data-bs-dismiss="modal" aria-label="Close">
						         <i class="fa-solid fa-xmark fa-2x text-white"></i>
						       </button>
							</div>
						    <h6 class="fs-6 text-capitalize fw-semibold mb-3 px-md-4 px-2 mt-md-5">property enquiry</h6>
						    <form action="" method="post" class="px-lg-4 px-2">
						      <!-- === name === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="name" placeholder="Your Name">
						      </div>
						      <!-- === email === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="email" placeholder="Your Email">
						      </div>
						      <!-- === phone === -->
						      <div class="mb-4">
							    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="number" name="phone" placeholder="Your Phone">
						      </div>
						      <!-- === text-box === -->
						      <div class="mb-4">
							    <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="msg" placeholder="I'm interested in  [ Spacious Office Space ] " rows="4"></textarea>
						      </div>
						      <!-- === action input btn === -->
						      <input type="submit" class="btn rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
						    </form>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
			     </div>
			   </div>	
			 </div>
			 <!-- === google nav  === -->
			 <div class="row d-none d-lg-block mt-3">
			   <div class="col-10">
			      <ul class="list-group list-group-horizontal">
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#property">
					  Description
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#address">
					  Address
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Details
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Features
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Map
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Video
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Floor Plans
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Yelp
				    </a>
				    <a class="nav-link text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold me-4" href="<?php echo $baseurl; ?>#">
					  Similar Listings
				    </a>
				  </ul>
			   </div>
			 </div>
		   </div>
		</section>
		<!-- === google map sections discreption === -->
		<section class="bg-light pt-0">
		   <div class="container-lg pt-4">
			 <div class="row">
			   <div class="col-lg-9 col-md-7">
			      <!-- === PROPERTY DESCRIPTION === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <h5 class="fs-6 text-uppercase fw-semibold mb-3" id="property">property enquiry</h5>
					<p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</small></p>
				  </div>
				  <!-- === PROPERTY ADDRESS === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <div class="accordion">
					  <div class="accordion-item rounded-0 border-0">
						<h2 class="accordion-header">
						  <button class="accordion-button shadow-none bg-transparent px-0 py-0 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#property-address" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
							<a href="<?php echo $baseurl; ?>#" class="text-capitalize fw-bold text-dark text-decoration-none fs-6 text-goldren-300-hover transition-100" id="address">PROPERTY ADDRESS</a>
						  </button>
						</h2>
						<div id="property-address" class="accordion-collapse collapse show">
						  <div class="accordion-body px-0 py-0">
							<div class="row">
							  <div class="col-md-4 col-sm-6 mb-mb-0 mb-1">
							    <p class="text-body-tertiary text-capitalize fw-bold mb-0">
								   <small>Address :<span class="ms-2 fw-semibold">NW 7th St</span></small>
								</p>
								<p class="text-body-tertiary text-capitalize fw-semibold mb-0">
								   <small>State/County: FL</small>
								</p>
							  </div>
							  <div class="col-md-4 col-sm-6 mb-mb-0 mb-1">
							    <p class="text-body-tertiary text-capitalize fw-bold mb-0">
								   <small>Address :<span class="ms-2 fw-semibold">NW 7th St</span></small>
								</p>
								<p class="text-body-tertiary text-capitalize fw-semibold mb-0">
								   <small>State/County: FL</small>
								</p>
							  </div>
							  <div class="col-md-4 col-sm-6 mb-mb-0 mb-1">
							    <p class="text-body-tertiary text-capitalize fw-bold mb-0">
								   <small>Address :<span class="ms-2 fw-semibold">NW 7th St</span></small>
								</p>
								<p class="text-body-tertiary text-capitalize fw-semibold mb-0">
								   <small>State/County: FL</small>
								</p>
							  </div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === PROPERTY DETAILS === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3" id="property">
				    <div class="accordion">
					  <div class="accordion-item rounded-0 border-0">
						<h2 class="accordion-header">
						  <button class="accordion-button shadow-none bg-transparent px-0 py-0 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#property-details" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
							<a href="<?php echo $baseurl; ?>#" class="text-capitalize fw-bold text-dark text-decoration-none fs-6 text-goldren-300-hover transition-100">PROPERTY DETAILS</a>
						  </button>
						</h2>
						<div id="property-details" class="accordion-collapse collapse show">
						  <div class="accordion-body px-0 py-0">
							<div class="row">
							  <!-- === PROPERTY DETAILS-1 === -->
							  <div class="col-md-4 col-sm-6 mb-md-0 mb-2">
							    <ul class="list-group">
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Property Id :</span>150</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Property Lot Size :</span> 400 ft2</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Bathrooms :</span>2</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Garage Size :</span>3 cars</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary">
								    <small><span class="fw-semibold me-1">External Construction :</span>New</small>
								  </li>
								</ul>
							  </div>
							  <!-- === PROPERTY DETAILS-2 === -->
							  <div class="col-md-4 col-sm-6 mb-md-0 mb-2">
							    <ul class="list-group">
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Price :</span>$ 16.000 / month</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Rooms :</span> 10</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Year Built :</span>2017-07-31</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Available From :</span>2018-01-27</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary">
								    <small><span class="fw-semibold me-1">External Construction :</span>New</small>
								  </li>
								</ul>
							  </div>
							  <!-- === PROPERTY DETAILS-3 === -->
							  <div class="col-md-4 col-sm-6 mb-md-0 mb-2">
							    <ul class="list-group">
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Property Size :</span>150 ft2</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Bedrooms :</span>0</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <small><span class="fw-semibold me-1">Garages :</span>Yes</small>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary">
								    <small><span class="fw-semibold me-1">Basement :</span>No</small>
								  </li>
								</ul>
							  </div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === PROPERTY FEATURES === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <div class="accordion">
					  <div class="accordion-item rounded-0 border-0">
						<h2 class="accordion-header">
						  <button class="accordion-button shadow-none bg-transparent px-0 py-0 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#property-featuers" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
							<a href="<?php echo $baseurl; ?>#" class="text-capitalize fw-bold text-dark text-decoration-none fs-6 text-goldren-300-hover transition-100">PROPERTY FEATURES</a>
						  </button>
						</h2>
						<div id="property-featuers" class="accordion-collapse collapse show">
						  <div class="accordion-body px-0 py-0">
							<div class="row">
							  <!-- === PROPERTY FEATURES-1 === -->
							  <div class="col-md-4 col-sm-6 mb-md-0 mb-2">
							    <ul class="list-group">
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>attic</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>gym</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>balcony</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>doorman</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>roof deck</span>
								  </li>
								</ul>
							  </div>
							  <!-- === PROPERTY FEATURES-2 === -->
							  <div class="col-md-4 col-sm-6 mb-md-0 mb-2">
							    <ul class="list-group">
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>gas heat</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>sprinklers</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>laundry</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>storage</span>
								  </li>
								</ul>
							  </div>
							  <!-- === PROPERTY FEATURES-3 === -->
							  <div class="col-md-4 col-sm-6 mb-md-0 mb-2">
							    <ul class="list-group">
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>ocean view</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>washer and dryer</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>concierge</span>
								  </li>
								  <li class="list-group-item border-0 px-0 py-0 text-body-tertiary mb-1">
								    <span><small><i class="fa-solid fa-check me-2"></i></small>recreation</span>
								  </li>
								</ul>
							  </div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === map === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <div class="accordion">
					  <div class="accordion-item rounded-0 border-0">
						<h2 class="accordion-header">
						  <button class="accordion-button shadow-none bg-transparent px-0 py-0 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#map" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-dark text-decoration-none fs-6 text-goldren-300-hover transition-100">map</a>
						  </button>
						</h2>
						<div id="map" class="accordion-collapse collapse show">
						  <div class="accordion-body px-0 py-0">
							<div class="card border-0 rounded-0">
							  <!-- === map code === -->
							  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3637.6798650591945!2d89.90795568885495!3d24.252973200000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fdfbee68046313%3A0xdf0ecf4915c1a7cf!2sTangail%20Stadium!5e0!3m2!1sen!2sbd!4v1684432810734!5m2!1sen!2sbd" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
							  <!-- === map card === -->
							  <div class="card-img-overlay p-0 rounded-0 h-50">
							    <div class="row justify-content-md-end justify-content-center">
								  <div class="col-lg-6 col-md-7 col-6">
								    <!-- === map card contant === -->
								    <div class="card border-0 rounded-0">
									  <div class="row g-0">
										<div class="col-lg-5 background-position-center background-size-cover background-repeat-no-repeat" style="background-image:url(images/map_img.jpg)">
										  <p class="py-5"></p>
										</div>
										<div class="col-lg-7">
										  <div class="card-body">
											<a href="<?php echo $baseurl; ?>#" class="text-decoration-none">
											 <h6 class="text-uppercase fw-bolder text-dark mb-0 text-goldren-300-hover transition-100">wonderful new villa</h6>
											 </a>
											<p class="mb-2 text-body-tertiary"><small>condos  in  rentals</small></p>
											<div class="d-flex align-items-center mb-3">
											  <h5 class="text-goldren-400 fw-bold mb-0">$16.000</h5>
											  <span class="mx-1 text-goldren-400">/</span>
											  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
											</div>
											<div class="d-flex justify-content-center text-center align-items-center">
												<div class="px-3 line-height-15">
												   <p class="mb-0 fs-6 text-secondary fw-semibold">5</p>
												   <p class="mb-0 fs-6 text-secondary">bedrooms</p>
												</div>
												<div class="px-3 line-height-15">
												   <p class="mb-0 fs-6 text-secondary fw-semibold">3</p>
												   <p class="mb-0 fs-6 text-secondary">baths</p>
												</div>
											 </div>
										  </div>
										</div>
									  </div>
									</div>
								  </div>
								</div>
							  </div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === floor plans === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-3">
				    <div class="accordion">
					  <div class="accordion-item rounded-0 border-0">
						<h2 class="accordion-header">
						  <button class="accordion-button shadow-none bg-transparent px-0 py-0 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#floor-plans" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-dark text-decoration-none fs-6 text-goldren-300-hover transition-100">floor plans</a>
						  </button>
						</h2>
						<div id="floor-plans" class="accordion-collapse collapse show">
						  <div class="accordion-body px-0 py-0">
						    <!-- === floor plans navs &tabs using === -->
							<ul class="nav nav-tabs mt-md-4" id="myTab" role="tablist">
							  <li class="nav-item" role="presentation">
								<button class="nav-link active text-dark position-relative" data-bs-toggle="tab" data-bs-target="#flor-plan-d" type="button" role="tab" aria-selected="true">Flor Plan D</button>
							  </li>
							  <li class="nav-item" role="presentation">
								<button class="nav-link text-dark position-relative" data-bs-toggle="tab" data-bs-target="#flor-plan-e" type="button" aria-selected="false" tabindex="-1" role="tab">Flor Plan E</button>
							  </li>
							</ul>
							<div class="tab-content border border-top-0" id="myTabContent">
							  <!-- === floor plan -1 === --> 
							  <div class="tab-pane fade px-3 py-4 show active" id="flor-plan-d" role="tabpanel">
							    <h6 class="fs-6 text-uppercase mb-2">floor plan d</h6>
								<ul class="list-group list-group-horizontal">
								  <li class="list-group-item border-0 ps-0 fw-semibold">
								    <small>Size :<span class="text-goldren-400 ms-1">500 ft2</span></small>
								  </li>
								  <li class="list-group-item border-0 fw-semibold">
								    <small>rooms :<span class="text-goldren-400 ms-1">6</span></small>
								  </li>
								  <li class="list-group-item border-0 fw-semibold">
								    <small>baths :<span class="text-goldren-400 ms-1">2</span></small>
								  </li>
								  <li class="list-group-item border-0 fw-semibold">
								    <small>price :<span class="text-goldren-400 ms-1">$ 150</span></small>
								  </li>
								</ul>
								<p class="text-body-tertiary mb-3"><small>This is floor plan c</small></p>
								<img src="<?php echo $baseurl; ?>images/no-header-floor.jpg" class="img-fluid">
							  </div>
							  <!-- === floor plan -2 === --> 
							  <div class="tab-pane fade px-3 py-4" id="flor-plan-e" role="tabpanel">
							    <h6 class="fs-6 text-uppercase mb-2">floor plan e</h6>
								<ul class="list-group list-group-horizontal">
								  <li class="list-group-item border-0 ps-0 fw-semibold">
								    <small>Size :<span class="text-goldren-400 ms-1">4500 ft2</span></small>
								  </li>
								  <li class="list-group-item border-0 fw-semibold">
								    <small>rooms :<span class="text-goldren-400 ms-1">6</span></small>
								  </li>
								  <li class="list-group-item border-0 fw-semibold">
								    <small>baths :<span class="text-goldren-400 ms-1">2</span></small>
								  </li>
								  <li class="list-group-item border-0 fw-semibold">
								    <small>price :<span class="text-goldren-400 ms-1">$ 500</span></small>
								  </li>
								</ul>
								<p class="text-body-tertiary mb-3"><small>This is floor plan e</small></p>
								<img src="images/floor-plan-1-2.jpg" class="img-fluid">
							  </div>
							</div> 
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === What's Nearby === -->
				  <div class="card card-body shadow-sm border-0 rounded-0 py-md-4 mb-5">
				    <div class="accordion">
					  <div class="accordion-item rounded-0 border-0">
						<h2 class="accordion-header">
						  <button class="accordion-button shadow-none bg-transparent px-0 py-0 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#whats-Nearby" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
							<a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bold text-dark text-decoration-none fs-6 text-goldren-300-hover transition-100">what's nearby</a>
						  </button>
						</h2>
						<div id="whats-Nearby" class="accordion-collapse collapse show">
						  <div class="accordion-body px-0 py-0">
						    <!-- === real estate === -->
						    <div class="d-flex align-items-center mt-4 mb-3">
							  <div class="flex-shrink-0 d-flex text-light bg-danger text-light px-1 py-1 d-flex">
								<i class="fa-regular fa-building" style="font-size: 15px;"></i>
							  </div>
							  <div class="flex-grow-1 ms-2">
								<h6 class="text-uppercase mb-0 fw-bold"><small>real estate</small></h6>
							  </div>
							</div>
							<!-- === remex city view === -->
							<div class="d-sm-flex justify-content-sm-between align-items-sm-center mb-sm-0 mb-2">
							  <h6 class="text-capitalize mb-0">
							  <small>
							     remex city view<span class="text-body-tertiary">(11.52 miles)</span>
							  </small>
							  </h6>
							  <img src="<?php echo $baseurl; ?>images/small_5.png" style="height: 14px;">
							</div>
							<!-- === Brickell Rent === -->
							<div class="d-sm-flex justify-content-sm-between align-items-sm-center mb-sm-0 mb-2">
							  <h6 class="text-capitalize mb-0">
							  <small>
							     Brickell Rent<span class="text-body-tertiary"> (11.45 miles)</span>
							  </small>
							  </h6>
							  <img src="<?php echo $baseurl; ?>images/small_5.png" style="height: 14px;">
							</div>
							<!-- === Restaurants === -->
						    <div class="d-flex align-items-center mt-4 mb-3">
							  <div class="flex-shrink-0 d-flex text-light bg-danger text-light px-1 py-1 d-flex">
								<i class="fa-regular fa-building" style="font-size: 15px;"></i>
							  </div>
							  <div class="flex-grow-1 ms-2">
								<h6 class="text-uppercase mb-0 fw-bold"><small>resturants</small></h6>
							  </div>
							</div>
							<!-- === Old's Havana Cuban Bar & Cocina  === -->
							<div class="d-sm-flex justify-content-sm-between align-items-sm-center mb-sm-0 mb-2">
							  <h6 class="text-capitalize mb-0">
							  <small>
							     Old's Havana Cuban Bar &amp; Cocina<span class="text-body-tertiary"> (11.45 miles)</span>
							  </small>
							  </h6>
							  <img src="<?php echo $baseurl; ?>images/small_5.png" style="height: 14px;">
							</div>
							<!-- === Crazy About You  === -->
							<div class="d-sm-flex justify-content-sm-between align-items-sm-center mb-sm-0 mb-2">
							  <h6 class="text-capitalize mb-0">
							  <small>
							     Crazy About You<span class="text-body-tertiary"> (11.45 miles)</span>
							  </small>
							  </h6>
							  <img src="<?php echo $baseurl; ?>images/small_5.png" style="height: 14px;">
							</div>
							<!-- === shoping === -->
						    <div class="d-flex align-items-center mt-4 mb-3">
							  <div class="flex-shrink-0 d-flex text-light bg-success text-light px-2 py-2 d-flex">
								<i class="fa-solid fa-cart-shopping" style="font-size: 15px;"></i>
							  </div>
							  <div class="flex-grow-1 ms-2">
								<h6 class="text-uppercase mb-0 fw-bold"><small>shoping</small></h6>
							  </div>
							</div>
							<!-- === Brickell City Centre  === -->
							<div class="d-sm-flex justify-content-sm-between align-items-sm-center mb-sm-0 mb-2">
							  <h6 class="text-capitalize mb-0">
							  <small>
							     Brickell City Centre<span class="text-body-tertiary"> (11.45 miles)</span>
							  </small>
							  </h6>
							  <img src="<?php echo $baseurl; ?>images/small_5.png" style="height: 14px;">
							</div>
							<!-- === Crazy About You  === -->
							<div class="d-sm-flex justify-content-sm-between align-items-sm-center mb-sm-0 mb-2">
							  <h6 class="text-capitalize mb-0">
							  <small>
							     Dolphin Mall<span class="text-body-tertiary"> (11.45 miles)</span>
							  </small>
							  </h6>
							  <img src="<?php echo $baseurl; ?>images/small_3_half.png" style="height: 14px;">
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				  <!-- === Similar Listings card === -->
				  <h3 class="text-uppercase">Similar Listings</h3>
				  <!-- === Similar Listings card - 1 === -->
				  <div class="card shadow-sm border-0 rounded-0 mb-3">
					  <div class="row g-0">
						<div class="col-lg-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/google_map_card.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
							<div class="card-img-overlay">
						      <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						    </div>
						  </div>
						</div>
						<div class="col-lg-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5 class="mb-0">
							  <a href="<?php echo $baseurl; ?>#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
							</h5>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="images/person3-120x120.jpg" class="h-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
								   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					  </div>
				  </div>
				  <!-- === Similar Listings card - 2 === -->
				  <div class="card shadow-sm border-0 rounded-0">
					  <div class="row g-0">
						<div class="col-lg-5">
						  <div class="card overflow-hidden border-0 rounded-0 h-100">
							<div class="background-position-center background-size-cover background-repeat-no-repeat d-flex align-items-end justify-content-end card-transform-scale-110-hover card-transform-scale-120 transition-400 h-100" style="background-image:url(images/card_3.jpg)">
							   <p class="py-5 my-5"></p>
							   <a href="<?php echo $baseurl; ?>#" class="my-4 mx-md-4 mx-5 text-decoration-none text-light fw-semibold"><small>compare</small></a>
							</div>
							<div class="card-img-overlay">
						      <span class="badge text-bg-danger text-uppercase rounded-0 px-3 py-2 opacity-75">Featured</span>
						    </div>
						  </div>
						</div>
						<div class="col-lg-7">
						  <div class="card-body">
							<!-- === Serviced Business Apartment === -->
							<h5 class="mb-0">
							  <a href="#" class="text-dark text-decoration-none text-uppercase text-goldren-300-hover">Serviced Business Apartment</a>	
							</h5>
							<div class=" mb-3">
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Coconut Grove,</a>
							   <a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-6 text-secondary">Miami</a>
						    </div>
							<div class="d-flex align-items-center mb-3">
							  <h5 class="text-goldren-400 fw-bold mb-0">$ 2.000</h5>
							  <span class="mx-1 text-goldren-400">/</span>
							  <p class="mb-0 text-goldren-400 fw-semibold">month</p>
							</div>
							<ul class="list-group list-group-horizontal text-center">
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2 <small>bedrooms</small></li>
							  <li class="list-group-item border-0 ps-0 text-body-tertiary fw-semibold">2.5 <small>baths</small></li>
							  <li class="list-group-item border-0 text-body-tertiary fw-semibold">250 ft<sup>2</sup><small> size</small></li>
						    </ul>
						  </div>
						  <div class="card-footer border-0 bg-white d-flex align-items-center justify-content-between">
							 <div class="d-flex align-items-center">
								<div class="flex-shrink-0">
								   <img src="<?php echo $baseurl; ?>images/person3-120x120.jpg" class="h-3 rounded-circle border">
								</div>
								<div class="flex-grow-1 ms-2">
								   <a href="<?php echo $baseurl; ?>#" class="fs-6 text-decoration-none text-body-tertiary mb-0 fw-semibold">Susan Anderson</a>
								   <p class="fs-6 text-body-tertiary mb-0 line-height-15"><small>May 27, 2023</small></p>
								</div>
							 </div>
							 <div>
								<a href="<?php echo $baseurl; ?>#" class="text-decoration-none fs-4">
								  <i class="fa-solid fa-heart text-body-tertiary opacity-25"></i>
								</a>
							 </div>
					      </div>
						</div>
					  </div>
				  </div>
			   </div>
			   <!-- === vartical slider sections discreption part-2 === -->
			   <div class="col-lg-3 col-md-5 mb-md-0">
			     <!-- CHARLES MILLER card-1 === -->
				 <div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				    <img src="<?php echo $baseurl; ?>images/team_member_3.png" class="img-fluid mb-3">
				    <a href="<?php echo $baseurl; ?>#" class="text-uppercase fw-bolder text-dark text-decoration-none fs-5 text-goldren-300-hover transition-100">Charles Miller</a>
				    <p class="text-secondary mb-0 line-height-15 mt-1">
				      <small><span class="fw-semibold">Phone : </span>(305)555-4555</small>
				    </p>
				    <p class="text-secondary mb-0 line-height-15 mt-1">
				      <small><span class="fw-semibold">Email : </span>linda@wpestatetheme.org</small>
				    </p>
				    <!-- === social media link === -->
				    <ul class="list-group list-group-horizontal mt-md-5 mt-4">
				      <!-- === facebook === -->
				      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
				        <i class="fa-brands fa-facebook-f fs-5 text-body-tertiary opacity-75"></i>
				      </a> 
				      <!-- === twitter === -->
				      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
				        <i class="fa-brands fa-twitter fs-5 text-body-tertiary opacity-75"></i>
				      </a>
				      <!-- === in === -->
				      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
				        <i class="fa-brands fa-linkedin-in fs-5 text-body-tertiary opacity-75"></i>
				      </a>
				      <!-- === pinterest === -->
				      <a href="<?php echo $baseurl; ?>#" class="text-decoration-none me-3">
					    <i class="fa-brands fa-pinterest fs-5 text-body-tertiary opacity-75"></i>
				      </a>
				    </ul>
					<h6 class="fs-6 text-capitalize fw-semibold mb-2">property enquiry</h6>
				    <!-- ==== full width form ===== -->
				    <form action="" method="post">
				      <!-- === name === -->
				      <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="name" placeholder="Your Name">
				      </div>
				      <!-- === email === -->
				      <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="email" placeholder="Your Email">
				      </div>
				      <!-- === phone === -->
				      <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="number" name="phone" placeholder="Your Phone">
				      </div>
				      <!-- === text-box === -->
				      <div class="mb-2">
					    <textarea class="form-control form-control-lg fs-6 text-secondary rounded-0 shadow-none form-control-focus" type="text" name="msg" placeholder="I'm interested in  [ Spacious Office Space ] " rows="4"></textarea>
				      </div>
				      <!-- === action input btn === -->
				      <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="SEND MESSAGE">
				   </form>
				 </div>
				 <!-- ==== CHANGE YOUR CURRENCY card-2 ===== -->
			     <div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Change Your Currency</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						 <option value="">$</option>
						 <option value="1">EUR</option>
					  </select>
				   </form>
				 </div>
				 <!-- === advance search card - 3 === -->
				 <div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">advanced search</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
				      <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <select class="form-select form-select-lg rounded-0 fs-6 text-body-tertiary cursor-pointer shadow-none form-control-focus mb-2" style="background-image:url(images/caret-down-fill-svgrepo-com.svg)">
						  <option value="">All action</option>
						  <option value="1">One</option>
						  <option value="2">Two</option>
						  <option value="3">Three</option>
					  </select>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <div class="mb-2">
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="Type Min. Price">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Search">
				   </form>
				 </div>
				 <!-- ===  Mortgage Calculator card-4 === -->
				 <div class="card card-body border-0 rounded-0 shadow-sm mb-4">
				   <h6 class="text-uppercase fw-bold">Mortgage Calculator</h6>
				   <hr class="mt-0 border border-2 opacity-50 rounded">
				   <!-- === form === -->
				   <form action="" method="post">
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Sale Price</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10000">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Percent Down</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="10">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Term (Years)</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="30">
					  </div>
					  <div class="mb-2">
					    <label class="text-body-tertiary"><small>Interest Rate in %</small></label>
					    <input class="form-control form-control-lg fs-6 text-body-tertiary rounded-0 shadow-none form-control-focus" type="text" placeholder="5">
					  </div>
					  <input type="submit" class="form-control rounded-0 fw-semibold text-white shadow-none bg-goldren-300 border-0 bg-hover-dark-600" value="Calculate">
				   </form>
				 </div>
				 <!-- ===  Spacious Office Space card-5 === -->
				 <?php include('spacious-ofice.php'); ?>
			   </div>
			 </div>	
		   </div>	
		</section>
	</main>
	<!-- === footer === -->
	<footer class="bg-light pt-5 pb-5">
	   <!-- === footer content === -->
	   <?php include('footer-content.php'); ?>
	</footer>
	<!-- Bootstrap js -->
    <script src="<?php echo $baseurl; ?>js/bootstrap.bundle.min.js"></script>
	<!-- swiper js -->
	<script src="<?php echo $baseurl; ?>js/swiper-bundle.min.js"></script>
	<?php include('affixjs-nav.php'); ?>
	<?php include('scroll-btn.php'); ?>
  </body>
</html>