<?php
	include('baseurl.php');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
	<!-- Fontawesome -->
	<link rel="stylesheet"type="text/css" href="<?php echo $baseurl; ?>css/all.css">
	<!-- === Bootstrap === -->
    <link href="<?php echo $baseurl; ?>css/bootstrap.min.css" rel="stylesheet">
	<!-- === Style css === -->
    <link href="<?php echo $baseurl; ?>css/style.css" rel="stylesheet">
	<!-- === Global css === -->
    <link href="<?php echo $baseurl; ?>css/global.css" rel="stylesheet">
	<!-- swiper js css -->
	<link rel="stylesheet" href="<?php echo $baseurl; ?>css/swiper-bundle.min.css"/>
  </head>
  <body>
    <!-- === sticky top === -->
    <header class="border-bottom transition-1000" id="affix-nav">
		<!-- === nav bar === -->
		<?php include('main-nav.php'); ?>
	</header>
	