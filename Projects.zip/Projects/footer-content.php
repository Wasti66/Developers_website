<div class="container-lg">
	<div class="row pb-md-4">
	  <!-- === footer logo === --> 
	  <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
		<img src="<?php echo $baseurl; ?>images/footer_logo.png" class="img-fluid mb-3">
		<p class="text-secondary mb-0"><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</small></p>
	  </div>
	  <!-- === footer link === --> 
	  <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
		<h6 class="text-uppercase fw-bolder text-dark mb-3 opacity-75">QUICK LINKS</h6>
		<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold">
		   <small>About</small>
		</a><br>
		<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold">
		  <small>Site Map</small>
		</a><br>
		<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold">
		  <small>Support Center</small>
		</a><br>
		<a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary text-goldren-300-hover fw-semibold">
		  <small>Terms & <br> Conditions</small>
		</a>
	  </div>
	  <!-- === footer contact === --> 
	  <div class="col-lg-3 col-sm-6 mb-lg-0 mb-4">
		<h6 class="text-uppercase fw-bolder text-dark mb-3 opacity-75">CONTACT</h6>
		<p class="text-body-tertiary mb-1"><small>No 23 Miami road</small></p>
		<p class="text-body-tertiary text-capitalize fw-bolder mb-1">
		   <small>phone :<span class="ms-2 fw-normal">324 234 234</span></small>
		</p>
		<p class="text-body-tertiary text-capitalize fw-bolder mb-1">
		   <small>email :<span class="ms-2 fw-normal">miami@wpestate.org</span></small>
		</p>
		<p class="text-body-tertiary text-capitalize fw-bolder mb-1">
		   <small>skype :<span class="ms-2 fw-normal">wpestate</span></small>
		</p>
		<ul class="list-group list-group-horizontal mt-4">
		  <!-- facebook -->
		  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary opacity-75 me-3">
			<i class="fa-brands fa-facebook-f"></i>
		  </a>
		  <!-- twitter -->
		  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary opacity-75 me-3">
			<i class="fa-brands fa-twitter"></i>
		  </a>
		  <!-- linkedin -->
		  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary opacity-75 me-3">
			<i class="fa-brands fa-linkedin-in"></i>
		  </a>
		  <!-- pinterest -->
		  <a href="<?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary opacity-75 me-3">
			<i class="fa-brands fa-pinterest-p"></i>
		  </a>
		  <!-- instagram -->
		  <a href="<?php echo $baseurl; ?><?php echo $baseurl; ?>#" class="text-decoration-none text-body-tertiary opacity-75 me-3">
			<i class="fa-brands fa-instagram"></i>
		  </a>
		</ul>
	  </div>
	  <!-- === footer social link === --> 
	  <div class="col-lg-3 col-sm-6">
		<h6 class="text-uppercase fw-bolder text-dark mb-4 opacity-75">SOCIAL LINKS:</h6>
		<ul class="list-group list-group-horizontal">
		  <a href="<?php echo $baseurl; ?>#" class="nav-link h-3 w-3 text-primary bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
			<i class="fa-brands fa-facebook-f m-auto fa-lg"></i>
		  </a>
		  <a href="<?php echo $baseurl; ?>#" class="nav-link h-3 w-3 text-info bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
			<i class="fa-brands fa-twitter m-auto fa-lg"></i>
		  </a>
		  <a href="<?php echo $baseurl; ?>#" class="nav-link h-3 w-3 text-primary bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
			<i class="fa-brands fa-linkedin-in m-auto fa-lg"></i>
		  </a>
		  <a href="<?php echo $baseurl; ?>#" class="nav-link h-3 w-3 text-danger bg-white shadow-sm d-flex me-lg-2 me-1 rounded">
			<i class="fa-brands fa-pinterest-p m-auto fa-lg"></i>
		  </a>
		</ul>
	  </div>
	</div>
</div>
<div class="fixed-bottom btn btn-secondary left-auto shadow-lg m-3 scrollToTopBtn">
  <i class="fas fa-level-up-alt text-white fa-sm"></i>
</div>

